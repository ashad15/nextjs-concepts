# Assisted Chat Architecture

How the OI Assistant works: the chat panel in the Opportunity Indicator workflow that answers questions about a peer analysis and operates the set-up form on the user's behalf.

This document covers the shape of the system and the reasoning behind it. Where a decision looks odd, the reason is written down, because most of them are odd for a reason and the alternative was tried first.

## What it does

Three capabilities, in the order they were built:

1. **Answers questions about the run.** Why a peer set was selected, what a peer scored on each comparability criterion and what evidence backs it, the raw figures behind two or three peers as a table, which candidates were turned down and why, which pages were read.
2. **Knows which screen you are on.** The same question gets a different answer on the set-up step and the peer step, and "this peer" resolves to whichever one is open or hovered.
3. **Operates the workflow.** Names the target company, sets the peer set breadth, ticks comparability criteria, and starts the analysis after an explicit confirmation.

## Topology

Four processes. Two already existed; the assistant adds two.

```
browser
  │
  ├─ Vite dev server                    :5173   SPA, proxies /api/copilotkit -> :4000
  │    │
  │    ├─ /api/*          ──────────────────►   peers API            :8000   (pre-existing)
  │    └─ /api/copilotkit ──────────────────►   CopilotKit runtime   :4000   (Node)
  │                                                  │
  │                                                  └──► chat agent :8123   (Python, AG-UI/SSE)
```

| Port | Process | Repo path | Purpose |
| --- | --- | --- | --- |
| 8000 | Peers API | `oi3-backend/app` | Peer recommendations. Untouched by this work. |
| 8123 | Chat agent | `oi3-backend/chat_agent` | LangGraph agent speaking AG-UI over SSE. |
| 4000 | CopilotKit runtime | `opportunity-indicator-frontend/server/runtime.ts` | Thread state, tool multiplexing. |
| 5173 | Vite | `opportunity-indicator-frontend` | The SPA. |

`./start-dev.sh` at the repo root starts all four and skips the API if it is already listening. Ctrl-C stops everything.

### Why the runtime is a separate hop

The CopilotKit runtime is a server-side component and the frontend is a Vite SPA with no API routes to host it in, so it runs as its own Node process. It is not a proxy. It holds thread state across turns, collects the frontend's tool declarations and merges them into each run, and keeps the agent's address and the model key off the browser. A browser talking straight to the agent would have to solve all three in client code.

It lives inside the frontend repo rather than in a package of its own purely so there is one `node_modules` to install. Nothing in `server/` reaches the bundle: Vite only follows imports out of `src/`.

### Why SSE and not WebSocket

Self-hosted CopilotKit streams over SSE. WebSocket transport exists only in CopilotKit's managed Intelligence cloud, which is a hosted dependency and requires an account. SSE streams token by token identically; the difference is the socket, not the experience. If durable threads across restarts are ever wanted, Intelligence is the switch, and the runtime construction in `server/runtime.ts` is the only file that changes.

### Why the chat agent is a separate service with its own venv

This is the least obvious decision in the system and the most deliberate.

`ag-ui-langgraph` requires langgraph 1.x, langchain-core 1.x and pydantic 2.13. `copilotkit` requires fastapi >= 0.141. The main API is pinned to langgraph 0.6.11, pydantic 2.10.5 and fastapi 0.115.6, and `langchain-openai 0.3.35` cannot coexist with langchain-core 1.x at all.

Installing the agent into the shared venv therefore means upgrading all of it, and the code that upgrade lands on is `agents/search_peers.py` and `app/schemas.py`, which is the working peer recommendation pipeline the client sees. Two venvs is the cheaper of the two costs. The agent reads `OPENAI_API_KEY` from the main backend's `.env`, so there is no second copy of the key.

## State: the 200KB problem

A peer recommendation is roughly 200KB, about 100KB of ranked peers and 90KB of retrieved page text. That is far too much to put in a prompt, and re-fetching slices of it mid-conversation would be slow.

The resolution is that **the whole run lives in the agent's state, and none of it enters the prompt**. The model receives a roughly 1KB outline and a set of tools, and calls a tool for the part it needs.

### State is written by the browser, not read from the cache

Every field in agent state is written by the frontend and none by the agent. The browser made the recommendation call, owns the activity log, and knows which screen is open. Mirroring that rather than re-reading the backend cache is what makes it impossible for the assistant to answer about a different run from the one on screen.

| State key | Contents |
| --- | --- |
| `recommendation` | The full peer recommendation, in the camelCase shape `services/peerApi.ts` produces. Null before a run. |
| `page` | `{ route, focusedPeer }`. Drives the per-screen prompt and resolves "this peer". |
| `setup` | Target, breadth, ticked criteria, and every criterion the form offers. |
| `activityLog` | The Log tab, oldest first, with the actor on each entry. |
| `companies` | The selectable company universe, for resolving an `@` mention to a cap id. |
| `tools` | Frontend tool declarations. Written per run by `ag_ui_langgraph`, never carried forward. See below. |

### State, not context

`useAgentContext` serialises its value into the model's prompt on every run. That is right for small things and catastrophic for a 200KB payload, so the recommendation goes through `agent.setState` instead, where it is carried alongside the prompt and read only by tools.

### The sync is defensive, not fire-and-forget

`src/copilot/useAgentSync.ts` does not write once and remember doing so. It writes a token into state and re-checks that the token survived, because two things can silently undo a write:

- The chat panel mounts with an explicit `threadId`, which makes CopilotChat call `connectAgent`, which loads that thread's state from the runtime and replaces local state wholesale.
- `useAgent` returns a provisional stand-in agent until the runtime's `/info` sync resolves, then swaps in the real one and changes the reference.

Either will leave the agent with empty state for the rest of the session if the sync assumes its last write is still there. The symptom is the assistant telling the user no analysis has been run while they are looking at one.

## Prompt assembly

`chat_agent/prompts.py` rebuilds the system prompt on every turn, because the user moves between steps mid-conversation and a static prompt would pin the assistant to whichever screen was open when the thread started.

Three things are folded in, all small:

- **The standing brief.** Who the user is (a Bain consultant or partner, not an engineer), how to talk about provenance, the routes a peer can arrive down, the score bands, and the rule that a tool call is never mentioned.
- **Where the user is.** Per-route notes. The peer screen note explains the radar plot, and states that the set-up is closed and cannot be changed from there.
- **An outline of the run.** `slices.run_overview`, about 1KB: target, best peer, peer names, and counts. Enough to know what can be asked for, never enough to answer from.

## Tools

### Backend tools, in `chat_agent/agent.py`

Ten, all reading from state via `InjectedState`, all returning data rather than prose. Wording is the model's job; these decide what is true.

| Tool | Answers |
| --- | --- |
| `list_peers` | The roster, one line per peer. |
| `get_peer_detail` | Everything held on one peer, including how each figure was arrived at. |
| `explain_comparability` | Per-criterion scores, bands, and the evidence sentence and source behind each. This is the radar chart answer. |
| `compare_peers` | Two or more peers as aligned rows, ready to lay out as a table. |
| `list_excluded` | Candidates assessed and turned down, with reasons. |
| `get_target` | The target's own figures. |
| `list_sources` | Pages read, optionally narrowed to one peer. |
| `read_source` | The retrieved text of one page, for quoting. |
| `get_activity_log` | What has happened so far, and who did it. |
| `list_companies` | The selectable universe, for resolving a name to a cap id. |

`slices.py` holds the logic behind these as pure dict-in/dict-out functions and imports nothing from langchain, so it can be tested without a model or a graph.

### Frontend tools, in `src/copilot/useWorkflowTools.tsx`

Declared in the browser, executed there. They arrive at the agent per run in `state["tools"]` and are bound to the model by `CopilotKitMiddleware`.

| Tool | Effect |
| --- | --- |
| `select_target_company` | Names the target, exactly as picking it from the card would. |
| `set_peer_set_breadth` | Tight, Standard or Broad. |
| `set_comparability_criteria` | Replaces the ticked set. Valid values are an enum in the schema, not prose. |
| `go_to_step` | Moves between the set-up and peer steps. |

### The one action that goes through the user

`run_peer_analysis` is a `useHumanInTheLoop` tool registered in `src/pages/OISetup.tsx`. Calling it does not start anything: it renders a confirmation card in the chat with the current settings, and the user decides there. **Calling the tool is the asking.** The prompt says so explicitly, because a brief that reads "always confirm before starting" produces two confirmations, one in prose and one on the card.

Everything else the assistant does is cheap and reversible with a click. This one spends money, takes several minutes of live search, and discards whatever peer set is on screen.

## Per-screen behaviour

The set-up tools stay registered on every screen and **refuse** once the set-up step has closed, returning a message explaining that changing an input means re-running the analysis, and offering to go back.

Unregistering them on the peer step was the first approach and it is worse. It does prevent the change, but it does so silently: the model finds no tool, has no result to relay, and fills the gap by narrating the change it meant to make. In testing it twice told the user the target had been switched while the screen still showed the original. A refusal is something true to say.

A stage banner pinned at the top of the chat states which step is in progress and what is now fixed. It is a banner rather than a rule drawn between messages because CopilotKit resolves custom message renderers as each message renders, so a marker recorded when the step changes never appears against messages already on screen. A banner also does not scroll out of view, while the fact it states stays true for the whole step.

## Activity log attribution

Every action the assistant can also perform takes an actor and logs accordingly, so the Log tab reads "You" when the user clicked and "Agent" when the assistant did it. Someone reviewing the analysis afterwards can tell which decisions were theirs. `resolveTarget` in the workflow layout and `handleProceedToPeers` in the set-up page both take this parameter; the frontend tools always pass `agent`.

## The @ mention

Typing `@` in the chat opens a filtering list of selectable companies. Choosing one writes the name back with its `@` marker intact, which is what tells the assistant the name was picked from the list rather than typed from memory.

It is implemented as CopilotKit's `input` **slot** (`src/copilot/MentionChatInput.tsx`) wrapping `CopilotChatInput`, not as a replacement for it, so send, stop, attachments and keyboard handling all still come from CopilotKit. This has to be done at the slot: `CopilotChat` accepts `inputValue` and `onInputChange` props but overwrites both with its own internal state before passing them down, so controlling the input from outside is silently ignored.

## Lifecycle of one turn

1. The user sends a message. `useAgentSync` has already mirrored the screen into agent state.
2. CopilotChat posts to `/api/copilotkit`, proxied by Vite to the runtime on :4000.
3. The runtime merges the frontend's tool declarations into the run and forwards to the agent on :8123 as an AG-UI request carrying messages, state and tools.
4. `ag_ui_langgraph` writes the tools into `state["tools"]`; `CopilotKitMiddleware` binds them alongside the ten backend tools.
5. `dynamic_prompt` rebuilds the system prompt from `page`, `setup` and the run outline.
6. The model answers, or calls a tool. Backend tools execute in the agent and return a slice of state. Frontend tools are routed back to the browser to execute there.
7. Events stream back as SSE: `TEXT_MESSAGE_CONTENT` deltas, `TOOL_CALL_*`, `STATE_SNAPSHOT`, `RUN_FINISHED`.

## Traps

These cost real time and are commented at each site. They are listed together because each one fails quietly rather than loudly.

**`useFrontendTool` and `useHumanInTheLoop` take a second `deps` argument.** Without it the tool is registered once with its mount-time closure, so anything reading changing state acts on the values the page loaded with. The confirmation card reported no target and the default criteria, then read its own stale values as "nothing to run" and answered itself, so the buttons never appeared.

**Never carry `state.tools` forward.** The agent server merges `[*run_tools, *state_tools]`, so a tool that is no longer registered is resurrected from state on every subsequent turn.

**Use `ag_ui_langgraph.LangGraphAgent`, not `copilotkit.LangGraphAGUIAgent`.** The endpoint clones the agent per request and passes `enable_legacy_on_interrupt_event`, which copilotkit 0.1.95's subclass does not accept. Every run 500s on the clone.

**Keep `workers=1` in the chat agent.** The shared `.env` sets `WEB_CONCURRENCY=2` for the main API and uvicorn reads that variable itself. Threads live in process memory, so a second worker answers half the turns with no memory of the conversation.

**`useAgent({ agentId, threadId })` is a different mode.** It registers a private proxied agent rather than resolving the shared one, and throws without a `runtimeAgentId`. Passing `agentId` alone is what returns the same agent CopilotChat resolves.

**Markdown tables need their own CSS.** CopilotKit renders markdown through streamdown but ships only `cpk:`-prefixed utilities, so the unprefixed `overflow-x-auto` and `w-full` classes in its output resolve to nothing in a project that does not compile Tailwind. `data-streamdown="table-wrapper"` is on the `<table>` itself with the scroller as its **parent**, and the table's display roles have to be asserted or the header and body compute independent column widths. All of this is in `src/styles/AssistantChat.css`.

**`showDevConsole` defaults to on for any localhost origin** and floats a CopilotKit badge and product announcements over the workspace. It is explicitly off.

## File map

### Frontend

| File | Role |
| --- | --- |
| `src/App.tsx` | Mounts the `CopilotKit` provider above the router. |
| `src/copilot/agent.ts` | Agent id, per-page-load thread id, shared context types. |
| `src/copilot/useAgentSync.ts` | Mirrors the screen into agent state, defensively. |
| `src/copilot/useWorkflowTools.tsx` | The set-up and navigation tools. |
| `src/copilot/MentionChatInput.tsx` | The `input` slot, with `@` mentions. |
| `src/copilot/mentions.ts` | Mention parsing and matching. Pure functions. |
| `src/copilot/CompanyMentionMenu.tsx` | The mention list. |
| `src/copilot/ConfirmRunCard.tsx` | The run confirmation card. |
| `src/copilot/StageBanner.tsx` | The pinned stage banner. |
| `src/components/OISetup/AssistantChatTab.tsx` | The Chat tab: `CopilotChat` plus per-screen suggestions. |
| `src/styles/AssistantChat.css` | Chat-scoped styling, including the table rules. |
| `server/runtime.ts` | The CopilotKit runtime process. |

### Backend

| File | Role |
| --- | --- |
| `chat_agent/main.py` | FastAPI app, mounts the AG-UI endpoint at `/`. |
| `chat_agent/agent.py` | State schema, the ten tools, the compiled graph. |
| `chat_agent/slices.py` | Cuts the recommendation into prompt-sized pieces. Pure functions. |
| `chat_agent/prompts.py` | The standing brief and the per-screen notes. |
| `chat_agent/requirements.txt` | Pinned, and separate for the reasons above. |

## Running it

```bash
./start-dev.sh                  # all four, from the repo root
```

Or individually:

```bash
cd oi3-backend         && .venv/bin/python -m uvicorn app.main:app --port 8000
cd oi3-backend/chat_agent && .venv/bin/python main.py      # :8123
cd opportunity-indicator-frontend && npm run runtime       # :4000
cd opportunity-indicator-frontend && npm run dev           # :5173
```

Health checks:

```bash
curl -s localhost:8123/health                      # {"status":"ok","agent":{"name":"oi_assistant"}}
curl -s localhost:4000/api/copilotkit/info | jq .  # agents.oi_assistant, mode "sse"
```

If `/info` lists the agent, the whole chain is connected.

A fresh clone needs the agent's venv created, since it is not in version control:

```bash
cd oi3-backend/chat_agent && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
```

The frontend and runtime hot-reload. **The chat agent does not**, so restart it after editing anything under `chat_agent/`.

### Running without spending on a live analysis

A live run takes 3.5 to 4 minutes of web search and model calls. One combination answers from the on-disk cache instead, in about 20 seconds:

> Target **Celyad Oncology**, peer set **Standard**, every criterion **except Product mix**.

That reproduces cache entry `d725f0b32ff68470b6c4498252b04bb0.json` exactly. Any other combination is a real run.

## Known gaps

- **No peer manipulation.** The peer step offers questions and navigation only. Adding, selecting and deselecting peers exist in `PeerSelection.tsx` but are not exposed as tools.
- **Threads are in memory.** They live as long as the runtime process and reset on page refresh, which is deliberate while there is no session management elsewhere in the app.
- **The chat chrome is CopilotKit's default look**, not the client mock in `bain-intelligence/frontend-html/02_peers.html`. The mention menu, confirmation card, stage banner and tables are styled; message bubbles, per-message timestamps, suggestion pills and the input row are not.
- **Untested against a live uncached run.** Everything verified so far went through the ~20 second cached path.
