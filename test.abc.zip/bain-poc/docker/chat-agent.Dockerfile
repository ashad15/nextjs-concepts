# syntax=docker/dockerfile:1
# Chat agent (LangGraph over AG-UI). Build context: oi3-backend/chat_agent.
# Python 3.12 to match the local venv; its dependency set is kept apart from the
# peers API on purpose (see chat_agent/requirements.txt).
FROM python:3.12-slim

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY *.py ./

EXPOSE 8123
HEALTHCHECK --interval=30s --timeout=5s --start-period=20s --retries=3 \
    CMD python -c "import urllib.request,sys;sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8123/health',timeout=4).status==200 else 1)"

# main.py binds 0.0.0.0:8123 with a single worker. OPENAI_API_KEY arrives via
# env_file (oi3-backend/.env), the same key the peers API uses.
CMD ["python", "main.py"]
