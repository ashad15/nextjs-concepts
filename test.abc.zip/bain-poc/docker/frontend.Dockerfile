# syntax=docker/dockerfile:1
# Vite SPA (:5173) + CopilotKit runtime (:4000) in one container, as start-dev.sh
# runs them. They share a container because vite.config.ts proxies
# /api/copilotkit to 127.0.0.1:4000. Build context: opportunity-indicator-frontend.
FROM node:24-slim

WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

COPY . .

EXPOSE 5173 4000

# Either process exiting stops the container; SIGTERM takes both down.
CMD ["bash", "-c", "trap 'kill 0' TERM INT; node_modules/.bin/tsx server/runtime.ts & node_modules/.bin/vite --host 0.0.0.0 --port 5173 --strictPort & wait -n; exit $?"]
