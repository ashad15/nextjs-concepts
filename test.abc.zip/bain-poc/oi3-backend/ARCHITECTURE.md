# Peer recommendation: current architecture

A description of what the PoC actually does today, written to be handed to a diagramming or image generation model. No code, no file names, components named by role.

## How this differs from the original concept sketch

The early hand-drawn concept had a service orchestrating a web search agent, a bank of concurrent per-peer agents, a VCC data store and an agent reranker. Most of that held. Four things moved:

| Concept | Current state |
| --- | --- |
| "Peer 1..5 WSA" as independent agents | Real and concurrent, but worker threads inside one process. The work is almost entirely waiting on HTTP, so threads are the right primitive. No agent protocol, no separate services. |
| "Agent Reranker" | A single structured prompt, not an agent loop. It reasons once over everything it is given. |
| VCC as a service | A local columnar snapshot of seven companies, built at startup from a curated sheet. |
| One discovery route | Two interchangeable engines returning the same contract, plus a search provider layer and a source evidence layer the sketch had no room for. |

## Components, grouped as bands

### Band 1: Client

**Target Company UI.** Sends a target, which is either an internal company id for a company held in the curated universe or a bare company name for one that is not. Also sends the comparability criteria to judge on, a maximum peer count, and a toggle choosing the discovery engine. Receives a ranked peer set with sources.

### Band 2: Service and cache

**Orchestrating API.** Owns the sequence, merges the two peer lists, and shapes the response.

**Durable response cache.** Sits in front of the service as a gate, not beside it as a store. Keyed on the whole request. A hit returns a previously recorded answer immediately with no searches and no model calls, which makes a rehearsed run instant and repeatable. A miss runs everything below. Deliberately does not serve a stale answer when a live call fails, because a wrong but plausible answer is worse than a visible error.

### Band 3: Internal data

**Startup ingestion.** Reads the curated company sheet, transposes it so companies become rows and metrics become columns, keeps only the configured metric set, and writes a columnar snapshot.

**VCC universe.** That snapshot: seven companies with full Capital IQ figures. Given a company id, the service takes that row as the target and every other row becomes a candidate peer with complete metrics. Given only a name, there is no internal universe to draw on and this band is skipped.

These rows arrive complete in figures and empty in evidence, which is the mirror image of what the discovery route produces. Band 7 fills the gap.

### Band 4: Peer discovery, two engines, one contract

**Search agent engine (default).** A reasoning loop with a single web search tool. It researches what the target actually does, then runs a separate scoring pass that rates every candidate from 0 to 100 on each caller-supplied criterion, with one sentence of concrete evidence and a source URL for each rating. It returns peers and judgements but deliberately no financial figures.

**Single-prompt engine.** The service runs the searches itself, assembles the retrieved text with every snippet glued to the URL it came from, and one prompt returns peers already carrying figures with a citation each.

Both return the same shape, so the response does not change form with the toggle.

### Band 5: Search providers (cross-cutting)

Every search in the system goes through one path.

- Exa answers first. Tavily takes over if it fails. Both are normalised to an identical hit shape, so nothing downstream knows which one answered.
- Both accept a domain restriction, so a restriction survives the fallback instead of silently widening to the open web.
- A search that fails returns empty rather than raising, so one bad query cannot take down a batch.
- Failures are recorded only once every provider has failed, because a fallback that worked is not an outage. A run whose searches all failed aborts with an upstream error rather than returning a confident answer with nothing behind it.
- Searches count against separate health budgets according to what they are for. Passes that merely enrich an answer are budgeted apart from the ones the answer is built from, so an enrichment pass that happened to succeed can never make a run look healthy when the research behind its conclusions has entirely failed. The outage check reads one budget at a time. This matters only because passes now run concurrently and therefore share a time window.

### Band 6: Source evidence (cross-cutting)

A per-request registry records the title and a trimmed extract of every page retrieved. Search already returns page text, so attaching that evidence to citations later is a join on the URL rather than a second fetch or an extra model call. URLs are normalised before joining, because a citation drifts from the retrieved URL by a trailing slash, a fragment or host casing.

Every source returned to the UI therefore carries: the URL, a publisher name, the page title, a short extract of the real retrieved text, and the list of things that page was used for. Sources appear both per peer and run-wide. A null extract means the model cited a page the system did not retrieve itself, which is reported honestly rather than filled in.

A source also carries what was actually taken from it. Each page lists the figures read off it, with the value, the period and the unit, and the comparability judgements it supported, with the rating and the sentence written to justify each one. So a citation is not a claim that a page was consulted; it is a record of what was found there, which is what lets the interface open a source and show the readings behind it rather than only its address.

Both peer routes now write here, so a page read to judge an internal peer is recorded on the same terms as one read to price a discovered peer, and the run-wide list is folded together on the URL. A page that served both says so once.

Extracts keep the line structure of the page. Financial pages arrive as tables, and a table survives only while its rows sit on separate lines, so an extract that collapsed whitespace would destroy the very content that made the page worth citing.

### Band 7: Per-peer research (the concurrent fan-out)

This is the "Peer 1..5" box from the sketch, and it is the newest part of the system. Two passes live here, one per peer list, and they answer different questions because the two lists arrive with different gaps.

Discovered peers need **figures**, because the system holds none for them. Internal peers need **evidence**, because it already holds better figures for them than any web page carries, and nothing at all to say why the company is comparable. Running either pass over the wrong list would make the answer worse, not better: researching an internal peer's revenue would replace an audited figure with a scraped one, and rescoring a discovered peer's comparability would only repeat what its own discovery loop already decided.

The two passes run concurrently with each other and with discovery itself.

**Figures for discovered peers.** Only peers that survived discovery are researched, so nothing is spent on candidates that were dropped. Peers run concurrently, one worker each.

Each worker runs two widening rounds:

1. **Trusted round.** Four themed searches, covering income statement, balance sheet, cash flow and leverage, and market data. Restricted to a curated list of regulators, exchanges and financial data aggregators. One extraction call then pulls figures out of the retrieved text, each carrying a source URL, the period it refers to, and the currency exactly as the page stated it.
2. **Open round.** The same themes, unrestricted, run only for the figures the first round did not find. Queries name only the outstanding items rather than repeating the whole search.
3. **Document lookup.** One further search per peer, restricted to that company's own investor relations domain plus the filing registries, keeping only URLs that look like a primary document. These are returned beside the peer for display and are explicitly marked as not used for any figure.

A measured finding shaped this. Company investor relations sites supplied comparability evidence for every peer in a full run and not one figure. They publish PDFs and narrative press releases rather than tables an extractor can read, and they never carry market capitalisation, share price or beta at all. So they were removed from the figure rounds and given their own job: surfacing the primary documents, which is what they are genuinely best at. Aggregators do the numeric work, which is the reverse of the intuitive ordering and is worth stating explicitly to anyone reviewing the design.

Then a pure arithmetic step with no model involved. The metrics split three ways:

| Origin | Roughly | What it means |
| --- | --- | --- |
| Searched | a third | Published somewhere: revenue, cost of sales, capital expenditure, receivables, payables, EBITDA, EBIT, earnings per share, share price, market capitalisation |
| Computed | about a dozen | Arithmetic on the searched figures: every margin, turnover days, the cash conversion cycle, growth restatements, leverage ratios |
| Modelled | one | Cost of equity, which no page publishes, from a stated CAPM with a floored beta. Every input is shown, so the figure can be recomputed and the assumption argued with |

The point of the split is that a margin computed from a cited revenue and a cited cost of sales cannot contradict its own inputs. Turnover ratios beyond a sanity ceiling are dropped rather than reported, because past that point they are arithmetic on mismatched bases rather than a real cycle. A peer whose research fails keeps an empty metric set rather than an invented one, because a gap the reranker can see is worth more than a number it cannot check.

Every computed figure travels with the arithmetic behind it: the expression in words, the same expression as typeset mathematics, and the named figures it was calculated from. A reader is therefore never asked to accept a derived number on the strength of the label above it, and a partner who disputes a margin can see in one line which two figures produced it and go and check both.

A second modelled rate was withdrawn rather than corrected. A weighted average cost of capital was being produced by scaling cost of equity by a ratio taken from three rows of the seed sheet, with no debt weight, no cost of debt and no tax shield behind it. That is a curve fitted to three points wearing the name of a standard calculation, and presenting it beside sourced figures invites exactly the challenge the whole provenance split exists to survive. It remains switched off, and returns only when there is a real weighting behind it.

A legacy invented-figures generator still exists as a demo fallback, switched off by default. It draws each field independently, so peers came back with impossible combinations that the reranker correctly read as a data quality failure.

**Evidence for internal peers.** One search per internal peer, all of them issued at once, then a single scoring call that rates every one of them against the target on the same criteria the discovery engine uses, with a sentence of concrete evidence and a source URL behind each rating. It is a small fraction of the pass above: one search per peer and one shared model call, against roughly nine searches and two extraction calls for each discovered peer.

Its position in the sequence is the point. It runs alongside discovery rather than after it, because nothing else touches the internal list while the discovery engine works through its search loop. The searches and the scoring call fit inside that window, so the pass costs the user almost no additional wall clock. Run afterwards, it would cost the whole of it.

It grounds the judgement only. The internal figures are never researched and never revised, and the pass is told plainly that they are trustworthy and are not to be second-guessed against a web page. A peer it cannot reach keeps no scores rather than invented ones. A failure anywhere in the pass degrades the run to how every run behaved before it existed, rather than taking the ranking down, which is why it sits outside the outage check that guards the discovery route.

This closes an asymmetry that was visible on screen. Every peer tile carries the same radar plot, but a discovered peer's scores came from cited pages while an internal peer's were the reranker's own unsourced judgement, and nothing in the interface distinguished the two. Internal peers are also the ones most likely to rank first, so the strongest recommendation in a run was the one with the least evidence under it. That is the first thing a reviewer would have pulled on.

### Band 8: Reranker

One model call receives the target, the internal peer list, the discovered peer list, the comparability criteria, the unit conventions, a data dictionary explaining house column meanings, and the full source list including the retrieved extracts.

It merges both lists into a single ranking and returns, for each peer: ranked reasons, concerns, criteria scores for the radar plot, four display-formatted headline metrics, estimated business segments, and a confidence breakdown across data completeness, adjustments required, sources cross-checked and business-model comparability. A company found independently by both routes is treated as stronger evidence of comparability than either route alone.

Everything it ranks and rejects comes back. A candidate that did not make the cut is returned with its identifier, the route that produced it, the score it reached and the reason it was left out, so the interface can show what was considered and why rather than only what survived. Silently dropping a candidate is the one outcome the contract forbids.

Criteria scores are reused, not re-derived. Both lists now arrive carrying scores that came from reading pages, so the reranker fills a factor in itself only where one is genuinely missing, and is required to say so in that peer's concerns when it had to score most of them unaided. Previously it scored every factor for every internal peer this way, silently.

The service, not the model, derives which engine each peer came from and re-attaches each peer's own sources. Asking the model to repeat them would invite invented URLs. Both routes are re-attached from the same index, so an internal peer can arrive carrying sources and still no figures, which is exactly what its two gaps and one filled gap look like.

The service also decides the both-routes case rather than trusting the ranking to notice it. Candidates are matched on identifiers, so a company returned twice, once per list, collapses into one entry, and a company ranked under one route while the internal universe held it too is corrected to both. Two entries from the same list are the model repeating itself and are collapsed without claiming anything about provenance. This is deliberate: agreement between a curated shortlist and an unconstrained search is the strongest evidence a peer carries, and it should not depend on a model spotting a duplicate.

## End-to-end flow

1. UI sends the target and criteria to the service. The cache is checked first; a hit short-circuits everything below.
2. **2a** The target is resolved against the internal snapshot. **2b** Every other row returns as a candidate peer with complete figures.
3. **3a** The service invokes the discovery engine with the target and criteria, and at the same moment starts the comparability pass over the internal peers. **3b** Both search the web through the provider layer, and every retrieved page is recorded in the source registry. **3c** The engine returns scored peers with citations and, on the agent route, no figures. The comparability pass returns the internal peers carrying sourced criteria scores, and finishes well inside the discovery window.
4. **4a** The service fans out one research worker per surviving discovered peer, concurrently. **4b** Each worker searches trusted domains first, extracts figures, then widens to the open web only for what is still missing. **4c** Derived metrics are computed, modelled rates are added, and the figures' sources are merged into that peer's source block.
5. **5a** Both peer lists, each now carrying evidence for its own scores, plus the folded run-wide source list, go to the reranker. **5b** A single merged ranking comes back.
6. The service returns the target, the best peer, the ranked peers, the rejected candidates with their routes, scores and reasons, the counts per route, and the run-wide source list to the UI.

## Supporting endpoints

- A mock peer list in the same shape as the real one, for building the UI before a real universe is loaded. No model calls, so it answers immediately.
- A direct view of the internal universe: treat one company as the target and return every other as its peer.
- A single company's internal row on its own. The previous entry answers "who are this company's peers" and returns the whole universe to do it, which is the wrong question for a company the interface already knows about and needs the figures for. A candidate the ranking assessed and turned down comes back carrying only its identifier, route, score and reason, so without this its figures are unreachable short of running another recommendation. No search and no model call behind it.

  Worth stating plainly, because the shape of the response suggests otherwise: a rejected candidate is not one that went unresearched. Research runs before the ranking exists, so a discovered candidate is fully researched and then has that payload dropped when it fails to make the cut. The rejected list carries a reason, not a gap. Deciding earlier which candidates deserve research would need a cheaper screen ahead of the reranker, which is a real design option and is not what happens today.

## Notes for whoever draws this

- Draw the fan-out band as genuinely parallel, with the two-round widening as concentric rings or as a retry arrow that carries only "still missing".
- Draw Exa and Tavily as a stacked pair with a fallback arrow between them, feeding every search arrow in the diagram rather than sitting on one branch.
- Draw the cache as a gate in front of the service, not as a store beside it.
- Draw the source registry as a cross-cutting rail that every search writes to and the reranker reads from.
- Mark the three metric origins distinctly. Searched, computed and modelled is the distinction the whole design turns on, and it is what makes the output defensible.
- The two discovery engines should read as interchangeable, converging on one contract, not as two different pipelines.
- Draw the comparability pass over the internal peers as starting at the same moment as discovery, not after it. Its position on the timeline is the design decision rather than an implementation detail: the pass is close to free only because it occupies a window that was otherwise idle, and a diagram that stacks it after discovery describes a slower system than the one that exists.
- Keep the two jobs in the fan-out band visually distinct. Figures flow to the discovered peers and evidence flows to the internal ones, in opposite directions, and the reason is that each list already holds what the other is missing.
