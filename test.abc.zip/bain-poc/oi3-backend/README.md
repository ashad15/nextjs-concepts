# OI 3.0 — Peers & Search API

FastAPI backend for steps 01–02 of the OI 3.0 flow, modelled on the prototypes in
[`data/01_target.html`](../data/01_target.html) and [`data/02_peers.html`](../data/02_peers.html).

- **Peers** — the proposed peer set for a target, with comparability scoring across the six
  selection criteria, the agent's rationale, sell-side cross-check, business units, a
  source-level audit trail, and select / narrow / confirm actions.
- **Search** — the company universe behind the "Add a peer" spotlight, plus the agent's
  suggested candidates and longlist.

## Run

```bash
# Docker (from the repo root)
docker compose up --build            # http://localhost:8000
docker compose --profile dev up api-dev   # hot reload on http://localhost:8001

# Local
python3 -m venv .venv && .venv/bin/pip install -r requirements-dev.txt
.venv/bin/uvicorn app.main:app --reload
```

Interactive docs at `/docs`, schema at `/openapi.json`, liveness at `/health`.

## Endpoints

All under `/api/v1`.

### Peers

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/targets/{target_id}/peers` | The peer set. `scope=tight\|standard\|full`, `selected_only`, `flagged_only` |
| `GET` | `/targets/{target_id}/peers/{peer_id}` | Full tile detail: why included, criteria scores, analyst view, business units, sources, metrics, confidence |
| `GET` | `/targets/{target_id}/peers/{peer_id}/sources` | Source audit trail — reported figure → adjustment → figure used |
| `POST` | `/targets/{target_id}/peers` | Add a peer by `company_id` or free-form `name` |
| `PATCH` | `/targets/{target_id}/peers/{peer_id}` | Select / deselect, or narrow to one business unit |
| `DELETE` | `/targets/{target_id}/peers/{peer_id}` | Drop a peer from the set |
| `POST` | `/targets/{target_id}/peers/confirm` | Lock the selection; returns warnings |

### Search

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/search/companies?q=` | Ranked search over name, ticker, brand aliases, sector |
| `GET` | `/search/suggest?q=` | Typeahead completions |
| `GET` | `/search/candidates?target_id=` | Agent suggestions + longlist, with data gates |

### Targets

`GET /targets`, `GET /targets/{id}`, `POST /targets/{id}/reset` (drops peer-set state back to
the seeded proposal).

## Examples

```bash
# The standard set (6 closest comparables)
curl 'localhost:8000/api/v1/targets/nike/peers?scope=standard'

# Why VF Corp is flagged, and what could be isolated instead
curl localhost:8000/api/v1/targets/nike/peers/vfcorp

# "Use Vans segment only"
curl -X PATCH localhost:8000/api/v1/targets/nike/peers/vfcorp \
  -H 'content-type: application/json' -d '{"isolate_business_unit":"Vans"}'

# Search the spotlight — brand aliases resolve to their parent
curl 'localhost:8000/api/v1/search/companies?q=hoka&target_id=nike'

# Add a longlist candidate; its rationale and data gate carry over
curl -X POST localhost:8000/api/v1/targets/nike/peers \
  -H 'content-type: application/json' -d '{"company_id":"asics"}'

# Confirm
curl -X POST localhost:8000/api/v1/targets/nike/peers/confirm
```

## How it works

**Comparability** is a weighted mean of the six selection criteria (business model, revenue
scale, regional exposure, end market, product mix, growth) at `strong=3 / partial=2 / weak=1`,
bucketed into High (≥2.5) / Medium (≥1.9) / Lower. Weights come from the target's
`criteria_weights`, so a case that cares most about business model and scale scores its peers
accordingly. Each response also carries per-factor 0–1 values for the radar plot.

**Search ranking** is deterministic and explainable: exact ticker or name (1.0) → prefix →
token prefix → substring → fuzzy (`difflib`, ≥0.68 ratio). Sector hits are capped so they
never outrank a name. Every result reports `matched_on` and `matched_text`, so the UI can show
why a row is there — `q=vans` returns VF Corp on an alias match.

**Adding a peer** mirrors the prototype: candidates on the agent's longlist keep their
rationale, "why not included" note, and data gate; anything else is enriched with source stubs
(statutory filings for private companies, a JGAAP restatement check for Tokyo listings, and the
Bain-experience cross-check) and a pending confidence score that resolves once benchmarking runs.

## Configuration

Environment variables, all prefixed `OI3_`:

| Variable | Default | Notes |
| --- | --- | --- |
| `OI3_CORS_ORIGINS` | `*` | Comma-separated origins |
| `OI3_API_PREFIX` | `/api/v1` | Route prefix |
| `OI3_ROOT_PATH` | *(empty)* | Set when served behind a path-rewriting proxy |
| `OI3_SEARCH_MIN_SCORE` | `0.35` | Fuzzy-match cutoff |
| `OI3_DEBUG` | `false` | |
| `PORT` / `WEB_CONCURRENCY` | `8000` / `2` | Read by the container entrypoint |

## Data & persistence

Seed data lives in [`app/data/`](app/data/) — targets, the proposed peer sets, the agent's
candidate longlist, and the searchable company universe, all extracted from the prototype.

Peer-set state (selection, manual additions, business-unit isolation, confirmation) is held **in
memory**, so a restart returns every target to its proposed set and a multi-replica deployment
will not share state. Swapping in a database means reimplementing `Store` in
[`app/store.py`](app/store.py) — routers and services only talk to that interface.

## Tests

```bash
.venv/bin/pytest        # 39 tests
.venv/bin/ruff check app tests
```
