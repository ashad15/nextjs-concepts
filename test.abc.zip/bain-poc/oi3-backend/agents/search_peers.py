import argparse
import logging
import os
from typing import Optional

from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition
from pydantic import BaseModel, Field

from app.config import get_settings
from app.services.sources import SourceRegistry
from app.services.tools.webtools import web_search

logger = logging.getLogger(__name__)

# Intentionally empty: comparability is judged only on the criteria the caller
# supplies, never on a house default. Put entries here to reinstate factors that
# apply to every run regardless of what was asked for.
CRITERIA: dict = {}

# What a 0-100 score means. Anchoring the bands keeps the numbers comparable
# between peers and between runs, rather than each score being a fresh opinion.
SCORE_BANDS = """  90-100  near-identical on this factor
  70-89   close match, differences are minor
  40-69   partial match, differences are material
  10-39   weak match, comparable only loosely
  0-9     not comparable on this factor"""

# Where a peer's mean score lands. The UI shows this next to the radar plot.
BUCKETS = ((70, "High"), (45, "Medium"), (0, "Lower"))


class CriterionScore(BaseModel):
    """How one peer rates against one criterion."""

    criterion: str = Field(description="The criterion key being rated.")
    score: int = Field(
        ge=0, le=100,
        description="0-100, where 100 is a near-identical match on this factor.")
    evidence: str = Field(
        description="One concrete sentence, specific to this "
        "company, justifying the score."
    )
    source_url: Optional[str] = Field(
        default=None,
        description="URL from the search results supporting this. "
        "Null if the rating came from judgement alone.",
    )


class Peer(BaseModel):
    """One comparable company, rated across every criterion."""

    company_name: str
    ticker: Optional[str] = Field(default=None, description="Never guess a ticker.")
    scores: list[CriterionScore] = Field(
        description="One entry per criterion, in the order the criteria were given."
    )
    summary: str = Field(description="One line on why this company is a peer.")


class PeerSet(BaseModel):
    """The agent's final answer."""

    target: str = Field(description="The target company, as identified.")
    target_profile: str = Field(
        description="What the target actually does — segments, scale, geography, "
        "end markets. This is what the peers are being matched against."
    )
    peers: list[Peer]


def criterion_key(text: str, index: int) -> str:
    """A short JSON-safe key for a caller-supplied criterion.

    "REVENUE" stays "revenue" and "DTC revenue share above 25%" becomes
    "dtc_revenue_share_above_25", so the radar plot has a readable axis label
    instead of custom_1. Anything unusable falls back to the position.
    """
    slug = "".join(c if c.isalnum() else "_" for c in text.lower()).strip("_")
    while "__" in slug:
        slug = slug.replace("__", "_")
    return "_".join(slug.split("_")[:6]) or f"custom_{index}"


def criteria_map(custom_criteria: Optional[list[str]] = None) -> dict:
    """{key: description} for every criterion this run scores on.

    The single source of truth: the agent scores these, and the rerank pass
    fills the same keys in for peers it did not research. CRITERIA is empty by
    design, so in practice these are the caller's own metrics.
    """
    criteria = dict(CRITERIA)

    for index, text in enumerate(custom_criteria or [], 1):
        key = criterion_key(text, index)
        # Never let one criterion silently overwrite another.
        while key in criteria:
            key = f"{key}_{index}"
        criteria[key] = text

    return criteria


def criteria_block(custom_criteria: Optional[list[str]] = None) -> str:
    """Render the criteria as the prompt sees them."""
    return "\n".join(
        f"- {key}: {description}"
        for key, description in criteria_map(custom_criteria).items()
    )


def system_prompt(custom_criteria: Optional[list[str]] = None) -> str:
    return f"""You find comparable public companies (peers) for a target company.

Search before you answer — never list peers from memory. Work in two passes:
first establish what the target actually does, then search for companies that
match it on the criteria below.

COMPARABILITY CRITERIA — the only basis on which peers are selected and scored:

{criteria_block(custom_criteria)}

These are the criteria the caller asked for, and they are the whole basis for
the score. Do not score on any factor outside this list, however relevant it
might seem, and do not drop one because it is hard to research — say plainly in
the evidence when the searches do not settle it.

Judge economic and business comparability, not surface similarity. Same sector
is not a reason on its own. Avoid companies that are materially different in
size or stage unless there is a specific reason to include them.

Find 5-8 peers. Score every peer on every criterion above from 0 to 100, with
one concrete sentence of evidence and the source URL you took it from.

Use the full scale:

{SCORE_BANDS}

Spread the scores — a peer that is genuinely weaker on a factor must score
lower on it. Do not cluster everything in the 70s to be safe, and do not
inflate a score to make a peer look better. A low score is a useful answer,
and a candidate the searches do not support should be dropped entirely.

Never invent a company name, a ticker, or a source URL."""


def make_search_tool(registry: Optional[SourceRegistry] = None):
    """The agent's one tool, bound to this run's source registry.

    Built per run rather than once at import, because the registry has to be
    per request: two runs in flight would otherwise record into each other and
    a peer would come back citing a page retrieved for a different company.
    """

    @tool
    def search_web(query: str) -> str:
        """
        Search the web for information about companies, their competitors,
        segments, financials, and industry classification.

        Returns numbered results, each with its source URL.
        """
        hits = web_search(query)

        # Recorded before the early return, so a query that found nothing still
        # leaves the pages from earlier queries intact.
        if registry is not None:
            registry.record(hits)

        if not hits:
            return "No results."
        return "\n\n".join(
            f"[{i}] {hit['title']}\nURL: {hit['url']}\n{hit['content'][:800]}"
            for i, hit in enumerate(hits, 1)
        )

    return search_web


def enable_langsmith() -> bool:
    """Turn on LangSmith tracing, if a key is configured.

    LangSmith is driven entirely by environment variables, and config.py has
    already pushed .env into the real environment by the time this runs. All
    this does is default the switches and say out loud whether tracing is on,
    so a run is never silently untraced.
    """
    if not os.getenv("LANGSMITH_API_KEY"):
        logger.warning(
            "LANGSMITH_API_KEY is not set — running untraced. Add it to .env "
            "with LANGSMITH_TRACING=true to see runs in LangSmith."
        )
        os.environ["LANGSMITH_TRACING"] = "false"
        return False

    os.environ.setdefault("LANGSMITH_TRACING", "true")
    os.environ.setdefault("LANGSMITH_PROJECT", "oi3-peers")

    if os.environ["LANGSMITH_TRACING"].lower() not in ("true", "1"):
        logger.info("LANGSMITH_TRACING is off — running untraced.")
        return False

    logger.info("LangSmith tracing on, project %r", os.environ["LANGSMITH_PROJECT"])
    return True


def build_agent(
    custom_criteria: Optional[list[str]] = None,
    registry: Optional[SourceRegistry] = None,
):
    """Compile the graph.

    `tools_condition` is the routing decision: tool calls on the last message
    mean run them, anything else means research is done and it is time to score.

    Raises if there is nothing to score on: with CRITERIA empty, a run without
    `custom_criteria` has no basis for comparability at all, and would return
    peers with an empty `scores` list.
    """
    criteria = criteria_map(custom_criteria)
    if not criteria:
        raise ValueError(
            "No comparability criteria supplied. Pass custom_criteria — "
            "CRITERIA is empty by design, so there is no default to fall back on."
        )

    settings = get_settings()

    llm = ChatOpenAI(
        model=settings.openai_model,
        # gpt-5 rejects max_tokens, and reasoning tokens count against this
        # budget too — same handling as app/services/openai.py.
        max_completion_tokens=settings.openai_max_tokens,
        reasoning_effort=settings.openai_effort,
        timeout=settings.openai_timeout_seconds,
    )

    system = system_prompt(custom_criteria)
    tools = [make_search_tool(registry)]
    researcher = llm.bind_tools(tools)
    scorer = llm.with_structured_output(PeerSet)

    def call_model(state: MessagesState) -> dict:
        """One research turn: either a tool call or a finished write-up."""
        return {
            "messages": [researcher.invoke([("system", system), *state["messages"]])]
        }

    def score_peers(state: MessagesState) -> dict:
        """Turn the research into rated peers.

        Structured output goes in its own node so the model researches freely
        first and only has to fit a schema once, at the end.
        """
        keys = list(criteria)
        instruction = (
            "Now return the peer set from the research above. Score every peer "
            "from 0 to 100 on each of these criteria, all of them, using exactly "
            f"these keys: {', '.join(keys)}."
        )
        peer_set = scorer.invoke(
            [("system", system), *state["messages"], ("user", instruction)]
        )
        return {
            "messages": [("assistant", peer_set.model_dump_json())],
            "peer_set": peer_set,
        }

    class State(MessagesState):
        peer_set: Optional[PeerSet]

    builder = StateGraph(State)
    builder.add_node("agent", call_model)
    builder.add_node("tools", ToolNode(tools))
    builder.add_node("score", score_peers)

    builder.add_edge(START, "agent")
    builder.add_conditional_edges(
        "agent", tools_condition, {"tools": "tools", END: "score"}
    )
    builder.add_edge("tools", "agent")
    builder.add_edge("score", END)

    return builder.compile()


def radar_values(peer: Peer) -> dict:
    """{criterion: score} — the shape the radar plot wants."""
    return {s.criterion: s.score for s in peer.scores}


def comparability_of(scores: dict) -> tuple[float, str]:
    """Mean of a {criterion: 0-100} map, and the bucket it falls in.

    Computed here rather than asked of the model: the model judges each
    criterion, arithmetic is the caller's job. Takes the plain dict so both
    recommendation paths score identically.
    """
    if not scores:
        return 0.0, "Unrated"

    mean = sum(scores.values()) / len(scores)
    return round(mean, 1), next(label for floor, label in BUCKETS if mean >= floor)


def comparability(peer: Peer) -> tuple[float, str]:
    """Mean criterion score out of 100, and the bucket it falls in."""
    return comparability_of(radar_values(peer))


def find_peers(
    company: str,
    custom_criteria: Optional[list[str]] = None,
    recursion_limit: int = 16,
    registry: Optional[SourceRegistry] = None,
) -> PeerSet:
    """Research peers for `company` and return them rated on every criterion.

    `custom_criteria` are the bases for comparability, and they are required:
    CRITERIA is empty, so nothing is scored unless the caller says what matters.

    `recursion_limit` caps the search cycles, so an agent that will not
    converge fails instead of spending credits indefinitely.

    Pass a `registry` to keep what the searches retrieved. The agent cites URLs
    but never repeats what a page said, so this is the only chance to capture it
    without fetching the page a second time.
    """
    enable_langsmith()

    agent = build_agent(custom_criteria, registry)
    result = agent.invoke(
        {"messages": [("user", f"Find the comparable public peers for: {company}")]},
        config={"recursion_limit": recursion_limit},
    )
    return result["peer_set"]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("company", nargs="+", help="Target company name or ticker")
    parser.add_argument(
        "-c",
        "--criterion",
        action="append",
        dest="custom",
        metavar="TEXT",
        required=True,
        help="A comparability criterion to score on (repeatable). Required: "
        "there are no default criteria.",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s:     %(message)s")

    peer_set = find_peers(" ".join(args.company), args.custom)

    print(f"\nTARGET: {peer_set.target}")
    print(f"{peer_set.target_profile}\n")

    ranked = sorted(peer_set.peers, key=lambda p: comparability(p)[0], reverse=True)
    for peer in ranked:
        mean, bucket = comparability(peer)
        ticker = f" ({peer.ticker})" if peer.ticker else ""
        print(f"{peer.company_name}{ticker} — {bucket} comparability, {mean}/100")
        print(f"  {peer.summary}")
        for score in peer.scores:
            source = f"  {score.source_url}" if score.source_url else ""
            print(
                f"    {score.criterion:<20} {score.score:>3}  {score.evidence}{source}"
            )
        print()


if __name__ == "__main__":
    main()
