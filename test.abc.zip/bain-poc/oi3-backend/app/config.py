"""Application settings, read from the environment."""

from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

# Put .env into the real environment, so SDKs that read their own keys
# (ANTHROPIC_API_KEY, TAVILY_API_KEY) find them without a manual `source .env`.
load_dotenv(Path(__file__).parent.parent / ".env")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="OI3_", env_file=".env", extra="ignore"
    )

    app_name: str = "OI 3.0 Peers API"
    version: str = "1.0.0"
    root_path: str = ""
    api_prefix: str = "/api/v1"
    debug: bool = False

    # Comma-separated list, e.g. "http://localhost:3000,http://localhost:5173"
    cors_origins: str = "*"

    data_dir: Path = Path(__file__).parent / "data"

    # Ingestion: source workbook/sheet read at start, parquet written back to data_dir
    source_file: str = "peersdata.csv"
    parquet_file: str = "company.db"
    target_row: str = "SELF_ID"
    peer_prefix: str = "PEER_"

    # Identifier columns carried through ingestion untouched (never scored).
    text_columns: list[str] = [
        "Cap_id",
        "INDUSTRY",
        "INDUSTRY_GROUP",
        "Name",
        "SECTOR",
        "Ticker",
    ]

    # Metric columns kept and scored. Anything not listed is dropped at ingestion.
    keep_metrics: list[str] = [
        "ACCOUNTS_PAYABLE",
        "REVENUE",
        "FCF_SALES_2YR",
        "FCF_SALES_3YR",
        "ACCOUNTS_RECEIVABLE",
        "TOTAL_REVENUE",
        "MARKET_CAP",
        "CAPITAL_EMPLOYED",
        "ACTUAL_EPS",
        "ADJUSTED_STOCK_PRICE",
        "LTM_EPS",
        "NET_DEBT_EBITDA_1YR",
        "CCC_ADJ",
        "ADJUSTED_EBIT_MARGIN",
        "ADJUSTED_EBIT",
        "GROSS_MARGIN",
        "ADJUSTED_CCC",
        "EBIT_MARGIN",
        "EBITDA_MARGIN",
        "CCC",
        "DSO",
        "COGS",
        "REVENUE_GROWTH_1YR",
        "WACC",
        "COST_OF_EQUITY",
        "CAPEX",
        "REVENUE_CAGR_1YR",
        "DPO",
        "ADJUSTED_EBITDA",
    ]

    # Unit convention for the metric columns. The source data records none of
    # this, so it is declared here — the figures are Capital IQ style.
    metric_currency: str = "USD"
    metric_currency_symbol: str = "$"
    metric_scale: str = "millions"

    # Amounts of money, in `metric_scale` of `metric_currency`.
    monetary_metrics: list[str] = [
        "REVENUE",
        "TOTAL_REVENUE",
        "COGS",
        "CAPEX",
        "MARKET_CAP",
        "CAPITAL_EMPLOYED",
        "ACCOUNTS_RECEIVABLE",
        "ACCOUNTS_PAYABLE",
        "ADJUSTED_EBITDA",
        "ADJUSTED_EBIT",
    ]

    # Money per share: same currency, but never scaled.
    per_share_metrics: list[str] = [
        "LTM_EPS",
        "ACTUAL_EPS",
        "ADJUSTED_STOCK_PRICE",
    ]

    # Counts of days rather than money or ratios.
    day_count_metrics: list[str] = [
        "DSO",
        "DPO",
        "CCC",
        "CCC_ADJ",
        "ADJUSTED_CCC",
    ]

    # Confidence score weights (completeness vs. non-zero rate), must sum to 1.0
    completeness_weight: float = 0.5
    non_zero_weight: float = 0.5

    # Claude. The SDK reads ANTHROPIC_API_KEY from the environment itself.
    claude_model: str = "claude-sonnet-5"
    claude_max_tokens: int = 4000
    claude_effort: str = "medium"  # low | medium | high | xhigh | max
    claude_timeout_seconds: float = 10.0  # abort the API call once this elapses

    # OpenAI. The SDK reads OPENAI_API_KEY from the environment itself.
    openai_model: str = "gpt-5.2"
    openai_max_tokens: int = 32000  # reasoning tokens count against this too
    openai_effort: str = "none"  # none | low | medium | high
    openai_timeout_seconds: float = 300.0

    # Exa web search, tried first. Called over its REST API rather than through
    # exa-py, which pins pydantic>=2.10.6 against the 2.10.5 held here.
    exa_max_results: int = 5
    exa_search_type: str = "auto"  # auto | neural | keyword
    exa_text_max_characters: int = 2000
    exa_timeout_seconds: float = 20.0

    # Tavily web search, the fallback when Exa fails.
    # The SDK reads TAVILY_API_KEY from the environment itself.
    tavily_max_results: int = 5
    tavily_search_depth: str = "basic"  # basic | advanced
    tavily_max_workers: int = 16  # searches run concurrently, one thread each
    tavily_metrics_per_query: int = 4  # metrics batched into each search query

    # What names a company in a search query, most identifying first.
    search_name_columns: list[str] = [
        "Name",
        "Ticker",
        "SECTOR",
        "INDUSTRY",
        "INDUSTRY_GROUP",
    ]

    # How much of a retrieved page to keep as its summary, in characters.
    # Roomy enough that a financials table survives with usable rows, since the
    # table is usually the reason the page was cited, and still small enough
    # that two dozen of them in the rerank prompt stay cheap.
    source_summary_max_chars: int = 1000

    # Where a model peer's figures come from. The single switch for this:
    #   research  research the primitives, compute the rest
    #   mock      invent them from mock_data_generator (demo fallback)
    #   none      leave them out, so the UI shows criteria scores only
    # "mock" produces figures that cannot survive the rerank's own consistency
    # check, because each field is drawn independently. Keep it for a fallback,
    # not for anything a client sees.
    peer_metrics: str = "research"

    # Whether our own peers get a qualitative web pass before the rerank.
    #
    # They arrive with audited figures and no evidence of comparability, so
    # without this the rerank scores every selection criterion for them out of
    # its own judgement, unsourced, while an agent peer's identical-looking
    # radar came from cited pages. One search per peer and one scoring call, run
    # alongside the agent rather than after it, so it costs almost no wall clock.
    #
    # This grounds the JUDGEMENT only. Their figures stay internal: researching
    # a revenue we already hold audited would replace it with a worse number.
    vcc_grounding: bool = True

    # Searched first, before falling back to an unrestricted search.
    #
    # Deliberately not seeded with the peer's own investor relations domain.
    # Measured over a full run, IR sites supplied comparability evidence for
    # every peer and not one figure: they publish PDFs and narrative press
    # releases rather than tables an extractor can read, and they never carry
    # market cap, share price or beta at all. They are used for filing_domains
    # below instead.
    #
    # Yahoo and Morningstar are here because they actually produced figures in
    # the open round, so reaching them in round one saves a search and a model
    # call per peer.
    trusted_domains: list[str] = [
        "sec.gov",
        "euronext.com",
        "nasdaq.com",
        "londonstockexchange.com",
        "annualreports.com",
        "stockanalysis.com",
        "marketscreener.com",
        "investing.com",
        "reuters.com",
        "finance.yahoo.com",
        "morningstar.com",
        "macrotrends.net",
        "stocktitan.net",
    ]

    # Where a company's primary documents live. Searched once per peer to
    # surface annual reports and filings for display. These are reference
    # material shown alongside a peer, never a source of figures.
    filing_domains: list[str] = ["sec.gov", "annualreports.com"]

    # URL markers that identify a primary document rather than a web page.
    filing_markers: list[str] = [
        ".pdf",
        "annual-report",
        "annualreport",
        "10-k",
        "20-f",
        "6-k",
        "financial-statements",
        "/archives/edgar",
    ]

    # A search or browse page can carry a marker in its query string without
    # being a document. EDGAR's full-text search is the usual offender.
    filing_exclude_markers: list[str] = [
        "cgi-bin",
        "action=getcompany",
        "/search",
        "?query=",
    ]

    # Peers researched at once. Each one is its own searches plus one
    # extraction call, and the work is all waiting on I/O.
    peer_research_max_workers: int = 6

    # Above this many days a turnover ratio is arithmetic on mismatched bases
    # rather than a real cycle, so it is dropped instead of reported.
    working_capital_max_days: float = 730.0

    # Cost of equity is a textbook CAPM: every input is stated, so a reader can
    # disagree with the risk-free rate or the premium and recompute it.
    model_cost_of_equity: bool = True

    # WACC is not. It was Ke x 0.9170, where that ratio is the mean of WACC/Ke
    # across three rows of the seed sheet. That is a curve fitted to three
    # points, not a weighted average cost of capital: it uses no debt weight,
    # no cost of debt and no tax shield. Presenting it beside sourced figures
    # invites exactly the challenge the audit view exists to survive, so it is
    # off. Turn it on only with a real weighting behind it.
    model_wacc: bool = False

    # CAPM inputs for the rates nobody publishes. The floor and the peer beta
    # are the lowest and median betas implied by the Capital IQ rates already
    # sitting in peersdata.csv, so modelled rates land in that band.
    capm_risk_free_rate: float = 0.0420
    capm_equity_risk_premium: float = 0.0550
    capm_beta_floor: float = 0.70
    capm_peer_beta: float = 0.758
    # CYAD, FARN and PRQR sit at 0.919, 0.910 and 0.922 of their cost of equity.
    wacc_to_cost_of_equity: float = 0.9170

    # Search tuning
    search_default_limit: int = 10
    search_max_limit: int = 50
    search_min_score: float = 0.35

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
