"""Fill the zero cells in peersdata.csv with real / derived / modelled figures.

Shape is preserved exactly: same rows, same columns, same order, same text rows.
Only cells that are currently 0 are touched. Nothing non-zero is overwritten.
"""

import csv
from pathlib import Path

SRC = Path("/Users/dipesh/Local-Projects/bain-poc/oi3-backend/app/data/peersdata.csv")

# Column index by ticker (0 = metric name column)
COL = {"ZLNA": 1, "CYAD": 2, "DBV": 3, "FARN": 4, "PRQR": 5, "CVAC": 6, "LKFT": 7}

# FX. Each company converts at the rate implied by its own LTM window.
EUR_2025 = 1.1733   # back-solved from CVAC: 83.000117 / 70.74 EUR
EUR_JUN26 = 1.2149  # back-solved from LKFT: 1203.449786 / 990.55 EUR
NOK = 0.10          # USD/NOK 10.0

# CAPM inputs for the modelled cost of equity / WACC
RF = 0.0420          # US 10Y, Aug 2026
ERP = 0.0550
BETA_FLOOR = 0.70    # lowest beta implied by the file's own populated Ke cells
BETA_PEER = 0.758    # median beta implied by CYAD / FARN / PRQR Ke cells
# The file's three populated rows all sit at WACC = 0.917 x Ke
WACC_RATIO = (0.1049 / 0.1141 + 0.0749 / 0.0823 + 0.0772 / 0.0837) / 3


def ke(beta):
    # 4dp, the precision the file already states its rates to
    return round(RF + beta * ERP, 4)


def wacc(cost_of_equity):
    return round(cost_of_equity * WACC_RATIO, 4)


KE_FLOORED = ke(BETA_FLOOR)   # DBV (beta -0.24), LKFT (beta 0.11)
KE_PEER = ke(BETA_PEER)       # CVAC, ZLNA (no listed beta available)
WACC_FLOORED = wacc(KE_FLOORED)
WACC_PEER = wacc(KE_PEER)

# ---------------------------------------------------------------- ZLNA
# Zelluna ASA, NOK m, LTM Mar-2026 + market data 2026-08-17.
# Pre-revenue, so every margin and every working-capital ratio is undefined
# by construction and is deliberately left at 0.
zlna_ebitda = -125.53 * NOK
zlna_netdebt = -48.99 * NOK
ZLNA = {
    "CAPEX": -0.02 * NOK,
    "LTM_EPS": -5.42 * NOK,
    "ADJUSTED_STOCK_PRICE": 22.50 * NOK,
    "COST_OF_EQUITY": KE_PEER,
    "CAPITAL_EMPLOYED": (75.84 - 8.80) * NOK,
    "WACC": WACC_PEER,
    "MARKET_CAP": 617.69 * NOK,
    "ACCOUNTS_RECEIVABLE": 7.70 * NOK,
    "FCF_SALES_2YR": zlna_netdebt,
    "FCF_SALES_3YR": zlna_ebitda,
    "NET_DEBT_EBITDA_1YR": zlna_netdebt / zlna_ebitda,
    "ADJUSTED_EBITDA": zlna_ebitda,
    "ADJUSTED_EBIT": -129.30 * NOK,
    "ACTUAL_EPS": -5.42 * NOK,
}

# ---------------------------------------------------------------- CYAD
# Celyad reports no cost of sales, so COGS stays nil and gross margin is 1.0.
# No adjusted measures are disclosed, so adjusted == reported.
cyad_rev = 3.566522
CYAD = {
    "GROSS_MARGIN": 1.0,
    "ADJUSTED_EBITDA": -35.80261,              # = EBITDA (FCF_SALES_3YR)
    "ADJUSTED_EBITDA_MARGIN": -10.03852212,    # = EBITDA_MARGIN
    "ADJUSTED_EBIT": -10.39614672 * cyad_rev,  # = EBIT_MARGIN x REVENUE
    "ADJUSTED_EBIT_MARGIN": -10.39614672,
}

# ---------------------------------------------------------------- DBV
# Already reports in USD. DSO is taken on total revenue, which is the same
# base CVAC and LKFT use (their REVENUE cell is their total revenue).
dbv_dso = 0.252014 / 5.268884 * 365
DBV = {
    "CAPEX": -0.53,             # FY2025
    "COST_OF_EQUITY": KE_FLOORED,
    "WACC": WACC_FLOORED,
    "REVENUE_GROWTH_1YR": 0.3577,
    "REVENUE_CAGR_1YR": 0.3577,
    "DSO": dbv_dso,
    "CCC": dbv_dso,             # no inventory, DPO not meaningful
    "CCC_ADJ": dbv_dso,
    "ADJUSTED_CCC": dbv_dso,
}

# ---------------------------------------------------------------- FARN
farn_rev = 1.004961
FARN = {
    "CAPEX": -0.222 * EUR_2025,   # FY2025 EUR 222k
    "GROSS_MARGIN": 1.0,          # no cost of materials reported
    "ADJUSTED_EBITDA": -10.160456,
    "ADJUSTED_EBITDA_MARGIN": -10.11029881,
    "ADJUSTED_EBIT": -10.19223134 * farn_rev,
    "ADJUSTED_EBIT_MARGIN": -10.19223134,
}

# ---------------------------------------------------------------- PRQR
# REVENUE stays 0 (CapIQ books it all as total revenue), so every margin uses
# TOTAL_REVENUE as the denominator. EBIT is backed out of the file's own EBITDA
# less sourced D&A, which keeps the row internally consistent.
prqr_total_rev = 3.462395
prqr_ebitda = -28.805865
prqr_da = 2.70 * EUR_2025
prqr_ebit = prqr_ebitda - prqr_da
PRQR = {
    "EBITDA_MARGIN": prqr_ebitda / prqr_total_rev,
    "GROSS_MARGIN": 1.0,
    "EBIT_MARGIN": prqr_ebit / prqr_total_rev,
    "ACCOUNTS_RECEIVABLE": 5.09 * EUR_2025,
    "ADJUSTED_EBITDA": prqr_ebitda,
    "ADJUSTED_EBITDA_MARGIN": prqr_ebitda / prqr_total_rev,
    "ADJUSTED_EBIT": prqr_ebit,
    "ADJUSTED_EBIT_MARGIN": prqr_ebit / prqr_total_rev,
}

# ---------------------------------------------------------------- CVAC
# LTM Sep-2025, the last window before the BioNTech deal closed on 2026-01-06.
# Market data is the final Nasdaq close and the shares acquired in the offer.
cvac_rev = 83.000117
cvac_ebit = 182.08 * EUR_2025
cvac_da = 16.75 * EUR_2025
cvac_ebitda = cvac_ebit + cvac_da
cvac_netdebt = -381.02 * EUR_2025
cvac_adj_ebitda = -207.868122 + cvac_da
cvac_shares = 195_341_219 / 0.8675 / 1e6
CVAC = {
    "EBITDA_MARGIN": cvac_ebitda / cvac_rev,
    "CAPEX": -3.99 * EUR_2025,
    "LTM_EPS": 0.80 * EUR_2025,
    "ACTUAL_EPS": 0.80 * EUR_2025,
    "ADJUSTED_STOCK_PRICE": 4.66,
    "COST_OF_EQUITY": KE_PEER,
    "CAPITAL_EMPLOYED": (1139.0 - 236.17) * EUR_2025,
    "WACC": WACC_PEER,
    "MARKET_CAP": cvac_shares * 4.66,
    "REVENUE_GROWTH_1YR": -0.8698,
    "REVENUE_CAGR_1YR": -0.8698,
    "EBIT_MARGIN": cvac_ebit / cvac_rev,
    "NET_DEBT_EBITDA_1YR": cvac_netdebt / cvac_ebitda,
    "FCF_SALES_2YR": cvac_netdebt,
    "FCF_SALES_3YR": cvac_ebitda,
    "ADJUSTED_EBITDA": cvac_adj_ebitda,
    "ADJUSTED_EBITDA_MARGIN": cvac_adj_ebitda / cvac_rev,
    "TOTAL_REVENUE": cvac_rev,
}

# ---------------------------------------------------------------- LKFT
# Galapagos NV, renamed Lakefront Biotherapeutics in May 2026. LTM Jun-2026.
lkft_rev = 1203.449786
lkft_ebitda = 750.15
lkft_mcap = 1820.0
lkft_netdebt = -3440.0          # EV -1620 = mcap 1820 + net debt
lkft_da = 36.81 * EUR_JUN26
lkft_adj_ebitda = 671.395133 + lkft_da
LKFT = {
    "EBITDA_MARGIN": lkft_ebitda / lkft_rev,
    "CAPEX": -13.7 * EUR_JUN26,
    "LTM_EPS": 10.31,
    "ACTUAL_EPS": 10.31,
    "ADJUSTED_STOCK_PRICE": 27.87,
    "COST_OF_EQUITY": KE_FLOORED,
    "CAPITAL_EMPLOYED": (3407.0 - 152.86) * EUR_JUN26,
    "WACC": WACC_FLOORED,
    "MARKET_CAP": lkft_mcap,
    "REVENUE_GROWTH_1YR": 2.594,
    "REVENUE_CAGR_1YR": 2.594,
    "EBIT_MARGIN": (643.78 * EUR_JUN26) / lkft_rev,
    "NET_DEBT_EBITDA_1YR": lkft_netdebt / lkft_ebitda,
    "FCF_SALES_2YR": lkft_netdebt,
    "FCF_SALES_3YR": lkft_ebitda,
    "ADJUSTED_EBITDA": lkft_adj_ebitda,
    "ADJUSTED_EBITDA_MARGIN": lkft_adj_ebitda / lkft_rev,
    "TOTAL_REVENUE": lkft_rev,
}

FILLS = {"ZLNA": ZLNA, "CYAD": CYAD, "DBV": DBV,
         "FARN": FARN, "PRQR": PRQR, "CVAC": CVAC, "LKFT": LKFT}


# Cells that are an exact restatement of another cell in the same column. These
# are copied as raw text in a second pass so the two never disagree in the last
# digit, which is how the file already treats ACTUAL_EPS and the CCC trio.
MIRRORS = {
    ("ZLNA", "ACTUAL_EPS"): "LTM_EPS",
    ("ZLNA", "ADJUSTED_EBITDA"): "FCF_SALES_3YR",
    ("CYAD", "ADJUSTED_EBITDA"): "FCF_SALES_3YR",
    ("CYAD", "ADJUSTED_EBITDA_MARGIN"): "EBITDA_MARGIN",
    ("CYAD", "ADJUSTED_EBIT_MARGIN"): "EBIT_MARGIN",
    ("DBV", "REVENUE_CAGR_1YR"): "REVENUE_GROWTH_1YR",
    ("DBV", "CCC"): "DSO",
    ("DBV", "CCC_ADJ"): "DSO",
    ("DBV", "ADJUSTED_CCC"): "DSO",
    ("FARN", "ADJUSTED_EBITDA"): "FCF_SALES_3YR",
    ("FARN", "ADJUSTED_EBITDA_MARGIN"): "EBITDA_MARGIN",
    ("FARN", "ADJUSTED_EBIT_MARGIN"): "EBIT_MARGIN",
    ("PRQR", "ADJUSTED_EBITDA"): "FCF_SALES_3YR",
    ("PRQR", "ADJUSTED_EBITDA_MARGIN"): "EBITDA_MARGIN",
    ("PRQR", "ADJUSTED_EBIT_MARGIN"): "EBIT_MARGIN",
    ("CVAC", "TOTAL_REVENUE"): "REVENUE",
    ("CVAC", "ACTUAL_EPS"): "LTM_EPS",
    ("CVAC", "REVENUE_CAGR_1YR"): "REVENUE_GROWTH_1YR",
    ("LKFT", "TOTAL_REVENUE"): "REVENUE",
    ("LKFT", "ACTUAL_EPS"): "LTM_EPS",
    ("LKFT", "REVENUE_CAGR_1YR"): "REVENUE_GROWTH_1YR",
}


def fmt(value):
    """Match the file's habit of plain decimals, at the precision it already uses."""
    text = f"{value:.12g}"
    if "e" in text or "E" in text:
        text = f"{value:.12f}".rstrip("0").rstrip(".")
    return text


rows = list(csv.reader(SRC.open(newline="")))
applied, blocked = 0, []

for row in rows:
    metric = row[0]
    for ticker, fills in FILLS.items():
        if metric not in fills:
            continue
        col = COL[ticker]
        if row[col].strip() not in ("0", "0.0", ""):
            blocked.append(f"{metric}/{ticker} already = {row[col]}")
            continue
        row[col] = fmt(fills[metric])
        applied += 1

by_metric = {row[0]: row for row in rows}
for (ticker, metric), source in MIRRORS.items():
    col = COL[ticker]
    by_metric[metric][col] = by_metric[source][col]

with SRC.open("w", newline="") as handle:
    csv.writer(handle, quoting=csv.QUOTE_MINIMAL).writerows(rows)

print(f"WACC/Ke ratio from file: {WACC_RATIO:.6f}")
print(f"Ke floored beta {BETA_FLOOR}: {KE_FLOORED}  -> WACC {WACC_FLOORED}")
print(f"Ke peer beta {BETA_PEER}: {KE_PEER}  -> WACC {WACC_PEER}")
print(f"\ncells filled: {applied}")
if blocked:
    print("REFUSED to overwrite (should be empty):")
    for item in blocked:
        print(" ", item)
