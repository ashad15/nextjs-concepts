# peersdata.csv: what was filled, from where

Updated 2026-08-17. 77 of the 116 zero cells were populated. Shape is unchanged (38 rows x 8 columns, same order) and **no non-zero cell was overwritten**. A guard in the fill script refused every attempt to touch a populated cell; it fired once, on `CAPEX`/DBV, which was already `-1.501067`.

## Conventions decoded from the file itself

Absolute figures are USD millions. Margins are ratios, not percentages. DSO and DPO are days. These relationships were reverse-engineered from the populated cells and verified to six or more decimal places on four companies independently, then used to compute every derived fill:

| Column | Actual meaning |
| --- | --- |
| `EBITDA_MARGIN` | `FCF_SALES_3YR / REVENUE` |
| `GROSS_MARGIN` | `(REVENUE - COGS) / REVENUE` |
| `ADJUSTED_EBIT_MARGIN` | `ADJUSTED_EBIT / REVENUE` |
| `ADJUSTED_EBITDA_MARGIN` | `ADJUSTED_EBITDA / REVENUE` |
| `DSO` | `ACCOUNTS_RECEIVABLE / total revenue x 365` |
| `DPO` | `ACCOUNTS_PAYABLE / COGS x 365` |
| `CCC` | `DSO + DIO - DPO`, mirrored into `CCC_ADJ` and `ADJUSTED_CCC` |
| `ACTUAL_EPS` | mirror of `LTM_EPS` |
| `REVENUE_CAGR_1YR` | mirror of `REVENUE_GROWTH_1YR` |

### Three columns do not hold what their names say

This matters for anything downstream that renders these as labelled metrics.

| Column | What it actually contains |
| --- | --- |
| `FCF_SALES_3YR` | EBITDA, absolute, USD millions |
| `FCF_SALES_2YR` | Net debt, absolute, USD millions. Negative means net cash |
| `NET_DEBT_EBITDA_1YR` | `FCF_SALES_2YR / FCF_SALES_3YR` |

Proof, from cells that were already populated before this update: Celyad's `EBITDA_MARGIN` of -10.03852212 times its `REVENUE` of 3.566522 gives exactly -35.80261, which is the value sitting in `FCF_SALES_3YR`. Its `NET_DEBT_EBITDA_1YR` of 1.537991699 times that same -35.80261 gives exactly -55.064117, the value in `FCF_SALES_2YR`. The same two identities hold exactly for DBV, Faron and ProQR.

## Vintage and FX

The pre-existing data is not a single vintage, and the fills follow each company's own last reported window rather than forcing one date.

| | Window used | FX to USD |
| --- | --- | --- |
| ZLNA | LTM Mar-2026, market data 2026-08-17 | NOK 0.10 |
| CYAD | derived only, no external data used | n/a |
| DBV | FY2025, already reports in USD | 1.0 |
| FARN | FY2025 | EUR 1.1733 |
| PRQR | FY2025 | EUR 1.1733 |
| CVAC | LTM Sep-2025, the last window before delisting | EUR 1.1733 |
| LKFT | LTM Jun-2026 | EUR 1.2149 |

Both EUR rates are back-solved from the file's own cells rather than assumed: 83.000117 / 70.74 = 1.1733 for CureVac, and 1203.449786 / 990.55 = 1.2149 for Lakefront. That CureVac's `GROSS_MARGIN` of 0.932867781 independently reproduces its reported 65.99 / 70.74 to five decimals is what confirmed the convention.

## Company status changes worth knowing

**LKFT is Galapagos NV.** Renamed Lakefront Biotherapeutics in May 2026, still Mechelen-based, listed on Euronext Amsterdam and Brussels and Nasdaq. The Cap_id `IQ1716658` and the ~EUR 1.1bn LTM revenue are consistent with Galapagos, whose revenue spiked on the 2025 Gilead collaboration unwind. It is roughly 8x the market cap of everything else in the set, which is real and not an error.

**CVAC was acquired by BioNTech** and stopped trading on 2026-01-06. Its market data cells are the final Nasdaq close of USD 4.66 and a share count of 225.18m, back-solved from the 195,341,219 shares tendered representing 86.75% of the total. Its LTM window ends Sep-2025 because that is its last reported period.

**CYAD delisted from Nasdaq in July 2023** and now trades only on Euronext Brussels. It discontinued R&D in 2025 and sold its research facility for EUR 3m, which is very likely what the `REVENUE` cell of 3.566522 picks up.

## Cells deliberately left at zero, 39 of them

| Reason | Cells |
| --- | --- |
| Genuinely nil, not missing | `VALUE_CREATOR_YEARS` for all seven. `COGS` for ZLNA, CYAD, FARN and PRQR, none of which report a cost of sales, which is also why their `GROSS_MARGIN` is 1.0 and their `DPO` is undefined |
| Undefined for want of a denominator | Every margin, `DSO`, `DPO` and the CCC trio for ZLNA. Zelluna is pre-revenue, reporting NOK 0.01m LTM. Populating a revenue that small would make every ratio in the column explode by construction |
| Ratio would be meaningless | `DSO` and the CCC trio for FARN and PRQR. ProQR's sourced receivables against the revenue base in its row give a 630-day DSO, which would actively distort peer scoring. DBV's `DPO` on its 0.140467 COGS base gives 5,357 days |
| Not sourceable | `ACCOUNTS_RECEIVABLE` for FARN. Faron does not break out trade receivables in its FY2025 release, and total assets less cash mixes in prepaids and fixed assets |

## Modelled rather than sourced

`COST_OF_EQUITY` and `WACC` for ZLNA, DBV, CVAC and LKFT are CAPM outputs, not reported figures, and they will not match Capital IQ's own beta and ERP model.

Method: `Ke = 4.20% + beta x 5.50%`, with the risk-free rate the US 10Y at Aug-2026. Real 5Y betas for this set are all far too low to use directly (DBV -0.24, LKFT 0.11, PRQR 0.03) and a negative beta would put Ke below the risk-free rate. Beta is therefore floored at 0.70, the lowest value implied by the file's own populated Ke cells, and set to 0.758, the median of those implied betas, where no listed beta exists at all. That gives Ke of 8.05% for DBV and LKFT and 8.37% for CVAC and ZLNA, both inside the 8.23% to 11.41% band already in the file.

`WACC` is then `Ke x 0.9170`. That ratio is not invented: CYAD, FARN and PRQR sit at 0.919, 0.910 and 0.922 respectively, so the file's own data supplies it.

Where a company discloses no adjusted measures, `ADJUSTED_EBITDA` and `ADJUSTED_EBIT` are set equal to the reported figures. That applies to ZLNA, CYAD, FARN and PRQR.

## Open items

**DBV's `DSO` uses `TOTAL_REVENUE`, not `REVENUE`.** DBV is the only company where the two differ materially, 5.268884 against 0.250637. Total revenue is the same base CureVac and Lakefront use, since their `REVENUE` cell is their total revenue, and it gives a sensible 17.5 days against 367 days on the narrow line.

**CYAD's `DSO` of 21.20563745 does not reconcile.** Its own receivables and revenue give 32.46 days. This is pre-existing and was not touched.

**Three rows have market data I could not reconcile to any real period**, listed here so you can re-pull them rather than because I changed them. Nothing below was modified.

| Cell | In file | What the market shows at 2026-08-17 |
| --- | --- | --- |
| CYAD `MARKET_CAP` | 226.84 | Celyad is roughly EUR 10m, at EUR 0.256 on ~44m shares |
| CYAD `ADJUSTED_STOCK_PRICE` | 18.99 | EUR 0.256 on Euronext Brussels |
| CYAD `LTM_EPS` | -3.847 | FY2025 was a profit of EUR 0.018 per share |
| PRQR `ADJUSTED_STOCK_PRICE` | 8.68 | USD 1.97, which reconciles cleanly against 141.12m shares and a USD 278.01m market cap |
| DBV `MARKET_CAP` | 225.40 | quoted at USD 810.62m, though DBV's `ADJUSTED_STOCK_PRICE` of 14.9556 does match today's USD 14.97 |
| FARN `MARKET_CAP` | 86.09 | EUR 286.0m at 2025-12-31 per the FY2025 release |

Confidence on that right-hand column is lower than on the fundamentals: share counts and market caps were the least reliable figures across sources, and one DBV pull returned a price, share count and market cap that cannot all be true simultaneously. Treat it as a prompt to check Capital IQ, not as a correction.

## Sources

Financial statements and market data:

- [Lakefront Biotherapeutics (LKFT) financials](https://stockanalysis.com/stocks/lkft/financials/), [balance sheet](https://stockanalysis.com/stocks/lkft/financials/balance-sheet/), [cash flow](https://stockanalysis.com/stocks/lkft/financials/cash-flow-statement/), [statistics](https://stockanalysis.com/stocks/lkft/statistics/)
- [CureVac (CVAC) financials](https://stockanalysis.com/stocks/cvac/financials/), [balance sheet](https://stockanalysis.com/stocks/cvac/financials/balance-sheet/), [cash flow](https://stockanalysis.com/stocks/cvac/financials/cash-flow-statement/)
- [DBV Technologies (DBVT) financials](https://stockanalysis.com/stocks/dbvt/financials/), [balance sheet](https://stockanalysis.com/stocks/dbvt/financials/balance-sheet/), [cash flow](https://stockanalysis.com/stocks/dbvt/financials/cash-flow-statement/), [statistics](https://stockanalysis.com/stocks/dbvt/statistics/)
- [ProQR (PRQR) financials](https://stockanalysis.com/stocks/prqr/financials/), [balance sheet](https://stockanalysis.com/stocks/prqr/financials/balance-sheet/), [cash flow](https://stockanalysis.com/stocks/prqr/financials/cash-flow-statement/), [statistics](https://stockanalysis.com/stocks/prqr/statistics/)
- [Zelluna (OSL:ZLNA) financials](https://stockanalysis.com/quote/osl/ZLNA/financials/), [balance sheet](https://stockanalysis.com/quote/osl/ZLNA/financials/balance-sheet/), [cash flow](https://stockanalysis.com/quote/osl/ZLNA/financials/cash-flow-statement/), [statistics](https://stockanalysis.com/quote/osl/ZLNA/statistics/)
- [Celyad Oncology (EBR:CYAD) financials](https://stockanalysis.com/quote/ebr/CYAD/financials/)

Primary filings and announcements:

- [Faron FY2025 financial statements release](https://faron.com/releases-and-publications/farons-financial-statements-release-1-january-to-31-december-2025/)
- [Celyad Oncology FY2025 results](https://celyad.com/2026/04/02/celyad-oncology-reports-full-year-2025-financial-results-and-business-highlights/)
- [Zelluna Q3 2025 results](https://www.globenewswire.com/news-release/2025/11/03/3179522/0/en/Zelluna-ASA-Reports-Third-Quarter-2025-Financial-Results-and-Provides-General-Business-Update.html)
- [BioNTech closes acquisition of CureVac](https://investors.biontech.de/news-releases/news-release-details/biontech-closes-acquisition-curevac-nv-including-subsequent)
- [Lakefront Biotherapeutics company profile, formerly Galapagos NV](https://stockanalysis.com/stocks/lkft/company/)

The fill script that produced this, including every input figure and the guard that blocks overwrites, is at `peersdata-fill.py` alongside this file. The pre-update CSV is the parent of the commit that added this note, recoverable with `git show HEAD~1:app/data/peersdata.csv`.
