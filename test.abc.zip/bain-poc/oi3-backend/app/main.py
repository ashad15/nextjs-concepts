import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.routers import companies, peers
from app.services.ingestion import ingest
from app.services.upstream import UpstreamError

settings = get_settings()

logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(levelname)s:     %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Run data ingestion once, at application start."""
    logger.info(
        "Starting %s v%s: running data ingestion", settings.app_name, settings.version
    )
    app.state.data = ingest(settings)
    logger.info("Ingested %d companies", len(app.state.data))

    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    root_path=settings.root_path,
    debug=settings.debug,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.exception_handler(UpstreamError)
async def upstream_error_handler(
    request: Request, exc: UpstreamError
) -> JSONResponse:
    """Say which dependency failed, and what to do about it.

    502 rather than 500: the API is fine, something it depends on is not, and
    the difference decides whether the fix is a key swap or a code change.
    """
    failure = exc.failure
    logger.error(
        "Upstream failure [%s/%s]: %s", failure.service, failure.reason, exc.summary
    )

    return JSONResponse(
        status_code=502,
        content={
            "detail": {
                "error": "upstream_failure",
                "service": failure.service,
                "reason": failure.reason,
                "message": exc.summary,
                "hint": failure.hint,
            }
        },
    )


app.include_router(companies.router, prefix=settings.api_prefix)
app.include_router(peers.router, prefix=settings.api_prefix)

# app/routers/search.py is still empty; wire it in once it defines a `router`.
# app.include_router(search.router, prefix=settings.api_prefix)


@app.get("/")
def root() -> dict:
    return {"name": settings.app_name, "version": settings.version, "docs": "/docs"}


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "version": settings.version,
        "companies": len(app.state.data),
    }
