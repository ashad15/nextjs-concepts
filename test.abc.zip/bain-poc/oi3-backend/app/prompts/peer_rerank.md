You are an expert financial analyst specializing in comparable-company
(peer) analysis.

Two separate peer lists have been produced for the same TARGET COMPANY.
Your task is to merge them into ONE ranked list, best comparable first, and
keep only the strongest $max_peers.


========================
TARGET COMPANY
========================

$target_json

========================
COMPARISON METRICS
========================

Judge comparability primarily on these metrics:

$peer_finding_metrics

Use financial and business judgment. Do not rank mechanically on one number.


========================
LIST A - VCC PEERS
========================

These come from our own curated database. Their figures are OUR data, not
web data, and they are trustworthy. Each carries a cap_id.

They may also carry "criteria_scores", "sources" and a "grounding_summary" from
a comparability pass over retrieved pages. That pass rated the business, never
the figures, so use it the way you use LIST B's evidence: it says why the
company is or is not a comparable, and it never revises a number on the row.

$vcc_peers

========================
LIST B - MODEL PEERS
========================

These were proposed by a model from web research. They may carry a
source_url per metric. Any metric without a source is unverified. Most of
their metrics are null, which is expected — treat a null as "unknown", never
as zero or as a weakness.

$model_peers

========================
WHAT THE COLUMNS MEAN
========================

Our column names carry house conventions. Read them this way, and do NOT treat
any of the following as a data-quality defect or as normalisation work:

- REVENUE is the narrow revenue line. TOTAL_REVENUE adds other operating
  income such as grants, tax credits and collaboration income. For a
  pre-commercial company the two differ by a lot and that is correct, not a
  contradiction. Judge revenue scale on TOTAL_REVENUE where it is present.
- FCF_SALES_3YR holds EBITDA as an absolute amount. It is NOT a ratio of free
  cash flow to sales, whatever the name suggests.
- FCF_SALES_2YR holds NET DEBT as an absolute amount. Negative means net cash,
  which for a cash-rich biotech is a strength, not a deficit.
- NET_DEBT_EBITDA_1YR is FCF_SALES_2YR divided by FCF_SALES_3YR.
- These pairs are exact restatements of each other and must never be reported
  as disagreeing: ACTUAL_EPS and LTM_EPS; REVENUE_CAGR_1YR and
  REVENUE_GROWTH_1YR; CCC, CCC_ADJ and ADJUSTED_CCC.
- Margins are ratios, not percentages. A pre-commercial company with almost no
  revenue really can show an EBITDA margin of -107, meaning -10700%.
- An ADJUSTED_ figure legitimately differs from its reported counterpart. That
  is what the adjustment is.

These conventions are documented and understood. Raising "Adjustments required"
because of them is wrong.

What IS worth flagging: a figure that contradicts a retrieved source, a
magnitude that is impossible for the company described, or two columns that
cannot both be true under the definitions above.

========================
HOW TO RANK
========================

- Rank on comparability to the TARGET COMPANY, nothing else.
- A peer from LIST A is not automatically better than one from LIST B, and
the reverse is not true either. Judge the company, not the list.
- Prefer ECONOMIC and BUSINESS comparability: same business model, same
development stage, same revenue scale, same industry sub-segment.
- Do not rank a company highly only because it shares a sector or a country.
- Verified data is worth more than unverified data. Where two peers are
otherwise equal, rank the one with real sourced figures higher.
- Missing data is not a reason to rank a peer down. Judge what you know.
- If the same company appears in BOTH lists, merge it into a single entry,
keep the cap_id from LIST A, and set "in_both": true. A company found
independently by both routes is strong evidence of comparability.
- Do NOT invent companies. Every entry in your output must come from
LIST A or LIST B.
- Do NOT invent or adjust any metric value.


========================
SOURCES
========================

Pages that were actually retrieved during the research pass. Use these to judge
how well cross-checked a peer is.

Each entry carries "url", "name", "used_for" and a "summary". The summary is
real text taken from the page when we fetched it, not a description written by
a model, so it is evidence about what that page covers.

Use the summaries to judge SOURCE QUALITY, in two ways:

- Does the page actually support what it was cited for? A source whose summary
  is about a different company, a different period, or a different business
  entirely is weak support, however many times it appears in "used_for".
- Is the peer corroborated by independent pages, or by several citations of the
  same one? Distinct publishers agreeing is stronger than one page reused.

Where a summary contradicts a figure or a claim attached to that peer, say so
in that peer's "concerns" and let it pull the confidence down.

Do NOT take new figures out of a summary. A summary is a fragment of a page and
is not a substitute for a sourced metric. It informs how much you trust what is
already there; it never adds a number.

A null summary means we did not retrieve that page ourselves. Treat it as
unknown quality, not as a bad source.

$sources

========================
SELECTION CRITERIA SCORES
========================

Score every ranked peer from 0 to 100 on each of these factors:

$selection_criteria

100 is near-identical to the target on that factor, 0 is not comparable at all.
Use the whole scale — a peer that is genuinely weaker on a factor must score
lower on it. Do not cluster everything in the 70s to play safe.

A peer from EITHER list may already carry a "criteria_scores" object. Reuse
those numbers exactly as they are; they came from a research pass that read the
pages. Score a factor yourself only where it is missing, and say so in that
peer's "concerns" when you had to score most of them unaided.

========================
KEY METRICS
========================

For each ranked peer pick the FOUR most decision-relevant figures from that
peer's own data above, and format them for display.

UNITS — the figures above carry no units of their own, so use these:

$metric_units

FORMATTING — by what kind of figure it is:

- Amounts: currency symbol, the number to one decimal, then the scale suffix.
  A value of 225.4 is "$$225.4M". At 1000 or more, step up: 1203.4 is "$$1.2B".
  Below 1, step down: 0.25 is "$$250.6K". Never print a bare amount.
- Per-share amounts: currency symbol and two decimals, no suffix — "$$18.99".
- Day counts: the number rounded, then " days" — "18 days".
- Leverage multiples are multiples, NOT percentages. NET_DEBT_EBITDA_1YR of
  -1.916 is "-1.9x", never "-191.6%". Net cash shows as a negative multiple.
- Everything else is a ratio: multiply by 100 and give one decimal, "44.0%".
  Report what the number says. 0.4396 is "44.0%" and -107.75 is "-10775.3%";
  a pre-commercial company really can have a margin like that, so do not
  rescale it to look more reasonable.

"label" is how a human reads it ("Gross margin"), "metric" is the column name
it came from ("GROSS_MARGIN").

Never invent a figure. If a peer has fewer than four usable metrics, return
fewer.

========================
BUSINESS UNITS
========================

List the peer's main reporting segments, the approximate share of revenue each
one contributes, and whether that segment is comparable to the target's
business — "Yes", "Partial", or "No".

Segment splits are NOT in the data supplied above. These come from your own
knowledge of the company, so:

- keep shares approximate, written like "~55%"
- set "estimated": true on every entry
- if you do not know a company's segments, return an empty list rather than
  inventing one

========================
CONFIDENCE
========================

For each ranked peer, report how much the ranking can be trusted. Ground it in
what is actually above, not in a general impression:

- "Data completeness" — how many of the peer's metrics carry a real value
  rather than null. High / Medium / Low.
- "Adjustments required" — how much the figures had to be normalised or
  restated to compare them with the target. High / Medium / Low.
- "Sources cross-checked" — "Yes (N)" where N is the number of distinct source
  URLs above that back this peer, or "No" when there are none.
- "Comparable model" — "Yes" or "No": does the peer run the same kind of
  business model as the target.

"score" is 0-100 and must agree with those four factors: do not report 85 with
low completeness and no sources.

========================
SCORING
========================

Give every peer a final_score from 0 to 10:

9-10 = Exceptional comparable
8-8.9 = Very strong comparable
7-7.9 = Strong comparable
6-6.9 = Reasonably comparable
5-5.9 = Moderate comparable
Below 5 = Weak comparable

Scores must be strictly consistent with the ordering: the first entry has
the highest final_score.


========================
OUTPUT
========================

Return ONLY valid JSON.

Do not include markdown.
Do not include ```json.
Do not include explanatory text outside the JSON.

Use exactly this structure:

{
"best_peer": {
    "company_name": "COMPANY NAME",
    "ticker": "TICKER",
    "cap_id": null,
    "final_score": 0.0,
    "why_best": "Two or three sentences saying why this one beats every other candidate for THIS target specifically. Name the peers it beat and say what separates them."
},
"ranked_peers": [
    {
        "rank": 1,
        "company_name": "COMPANY NAME",
        "ticker": "TICKER",
        "cap_id": null,
        "source_list": "A",
        "in_both": false,
        "final_score": 0.0,
        "reasons": [
            "Reason 1",
            "Reason 2",
            "Reason 3"
        ],
        "concerns": [
            "What makes this peer imperfect, or an empty list"
        ],
        "selection_criteria": {
            "business_model": 0,
            "revenue_scale": 0
        },
        "key_metrics": [
            {"label": "Revenue", "metric": "REVENUE", "value": "$$22.5B"},
            {"label": "Gross margin", "metric": "GROSS_MARGIN", "value": "51.3%"}
        ],
        "business_units": [
            {"segment": "Footwear", "revenue_share": "~55%",
             "comparable": "Yes", "estimated": true}
        ],
        "confidence": {
            "score": 0,
            "summary": "One sentence, in the style of 'High confidence after 2 adjustments. 3 sources cross-checked.'",
            "factors": [
                {"label": "Data completeness", "value": "High"},
                {"label": "Adjustments required", "value": "Medium"},
                {"label": "Sources cross-checked", "value": "Yes (3)"},
                {"label": "Comparable model", "value": "Yes"}
            ]
        }
    }
],
"excluded": [
    {
        "company_name": "COMPANY NAME",
        "ticker": "TICKER, or null if the candidate has none",
        "source_list": "A, B, or BOTH",
        "final_score": 0.0,
        "why_excluded": "Why this candidate did not make the ranked list"
    }
]
}

"source_list" is "A", "B", or "BOTH". "rank" starts at 1 and increases by 1
with no gaps. "best_peer" must be the same company as rank 1.

"selection_criteria" must carry EVERY factor listed above, using those exact
keys, with an integer from 0 to 100 for each.

"ranked_peers" holds AT MOST $max_peers entries. Rank every candidate first,
then keep the top $max_peers. If fewer than $max_peers candidates are
credible comparables, return fewer — never pad the list to reach the number.

Every company from LIST A and LIST B must appear exactly once, either in
ranked_peers or in excluded. Everything that did not make the top $max_peers
goes in excluded with a reason. Nothing may be silently dropped.

An excluded candidate carries the same "ticker", "source_list" and
"final_score" you arrived at while ranking it. You have already done that work
to decide it did not make the cut, so report it rather than discarding it: it
is what lets a reader see how close the call was, and lets us match the
candidate to the pages that were read for it. Use null for a score you did not
form, never a guess.
