You are an expert financial analyst. You are given real pages retrieved for a
set of candidate peer companies, and one TARGET COMPANY they are being compared
against. Rate how comparable each candidate is to the target, on the criteria
below and nothing else.

You are NOT extracting financial figures. We already hold audited figures for
every company below and they are better than anything on a web page. Do not
report a revenue, a margin or a market cap, and do not let the absence of one
in the text below stop you from scoring.

What you are supplying is the thing we do not hold: evidence, from a page we
actually retrieved, for WHY each candidate is or is not a comparable business.


========================
TARGET COMPANY
========================

$target_json


========================
CRITERIA
========================

Score every candidate from 0 to 100 on each of these, using exactly these keys:

$selection_criteria

100 is near-identical to the target on that factor, 0 is not comparable at all.

  90-100  near-identical on this factor
  70-89   close match, differences are minor
  40-69   partial match, differences are material
  10-39   weak match, comparable only loosely
  0-9     not comparable on this factor

Use the whole scale. A candidate that is genuinely weaker on a factor must
score lower on it. Do not cluster everything in the 70s to play safe, and do
not inflate a score to make a candidate look better. A low score is a useful
answer.

Judge economic and business comparability, not surface similarity. Sharing a
sector is not a reason on its own.


========================
CANDIDATES
========================

Any figures below are OUR OWN data, not web data, and they are trustworthy.
Score revenue scale and growth against these rather than against anything the
research says, and never revise one to match a web page. Margins are ratios,
not percentages, so a pre-commercial company really can show an EBITDA margin
of -107, meaning -10700 percent. TOTAL_REVENUE adds grants, tax credits and
collaboration income to the narrow REVENUE line; judge revenue scale on
TOTAL_REVENUE where it is present.

$companies


========================
WEB RESEARCH
========================

Each snippet is preceded by the SOURCE_URL it came from. That URL is the
citation for anything you take out of that snippet.

You have no search tool. The text below is everything you have.

$research


========================
RULES
========================

- Every candidate listed above must appear exactly once in your output, and
carry every criterion key, even where the research says little about it.
- Cite the SOURCE_URL of the snippet your evidence came from. Use the exact URL
as printed above, never a shortened or reconstructed one.
- Where the research does not settle a criterion, score it on what the target
and candidate descriptions already tell you, write evidence saying plainly that
the searches did not settle it, and set "source_url" to null. An honest null is
correct. A URL that does not support the claim is a failure.
- Never cite a page retrieved for a different company as evidence about this
one. The snippets are pooled across all candidates, so check the company a page
is actually about before using it.
- "evidence" is ONE concrete sentence about THIS company. Not a definition of
the criterion, not a general remark about the sector.
- Do not invent a company, a ticker or a URL.


========================
OUTPUT
========================

Return ONLY valid JSON. No markdown, no code fences, no text outside the JSON.

{
"companies": [
    {
        "company_name": "Exactly as given in CANDIDATES",
        "ticker": "Exactly as given in CANDIDATES, or null",
        "summary": "One line on how this company compares with the target.",
        "scores": [
            {
                "criterion": "one of the keys listed under CRITERIA",
                "score": 0,
                "evidence": "One concrete sentence about this company.",
                "source_url": "https://... or null"
            }
        ]
    }
]
}
