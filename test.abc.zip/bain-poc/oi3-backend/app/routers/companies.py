"""Company lookup endpoints."""

from fastapi import APIRouter

from app.config import get_settings
from app.services.store import load_companies, records

router = APIRouter(prefix="/companies", tags=["companies"])


@router.get("")
def list_companies() -> dict:
    """Every company in the set, identifiers only, so callers can discover cap_ids."""
    companies = load_companies()

    # settings.text_columns minus Cap_id, which records() supplies from the index.
    columns = [c for c in get_settings().text_columns if c in companies.columns]

    return {"count": len(companies), "companies": records(companies[columns])}
