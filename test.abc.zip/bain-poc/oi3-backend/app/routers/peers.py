from concurrent.futures import ThreadPoolExecutor
from typing import Annotated, Optional

from fastapi import APIRouter, HTTPException, Query

from app.config import get_settings
from app.services import upstream
from app.services.diskcache import json_disk_cache
from app.services.recommendation import (
    get_agent_recommendation,
    get_model_recommendation,
    merge_sources,
    rerank_peers,
)
from app.services.research import ground_vcc_peers
from app.services.store import load_companies, records
from app.services.tools.mock_data_generator import (
    RANGES,
    generate_companies,
    generate_company,
)

router = APIRouter(prefix="/peers", tags=["peers"])

# Swagger's "try it out" form sends the placeholder text for a field you left
# alone, so these arrive as literal strings rather than as a missing param.
BLANK_VALUES = {"", "null", "none", "string", "undefined", "nan"}


def blank_to_none(value: Optional[str]) -> Optional[str]:
    """Treat a placeholder or whitespace-only value as not supplied."""
    if value is None:
        return None
    value = value.strip()
    return None if value.lower() in BLANK_VALUES else value


@router.get("/mock")
def list_mock_peers(
    count: Annotated[int, Query(ge=1, le=200, description="How many to invent")] = 50,
    seed: Annotated[Optional[int], Query(description="Repeat a list exactly")] = None,
) -> dict:
    """A list of invented companies in the same shape as the real ones.

    For building the UI against before the real universe is loaded: same
    columns as `/companies`, same metric names, plausible magnitudes. No model
    calls, so it answers immediately.
    """
    companies = generate_companies(count, seed=seed)
    return {"count": len(companies), "peers": companies}


@router.get("/company/{cap_id}")
def get_company(cap_id: str) -> dict:
    """One company's internal row, on its own.

    `/vcc/{cap_id}` answers "who are this company's peers", which is a
    different question and returns the whole universe to ask it. This is for a
    company the UI already knows about and needs the figures for: a candidate
    the rerank assessed and turned down still has a full Capital IQ row here,
    and without this there is no way to read it short of running a whole
    recommendation.

    No model call and no search, so it answers immediately.
    """
    companies = load_companies()

    if cap_id not in companies.index:
        raise HTTPException(
            status_code=404, detail=f"Unknown cap_id: {cap_id}")

    return {"company": records(companies.loc[[cap_id]])[0]}


@router.get("/vcc/{cap_id}")
def get_vcc_peers(cap_id: str) -> dict:
    """Treat `cap_id` as the target; every other company is one of its peers."""
    companies = load_companies()

    if cap_id not in companies.index:
        raise HTTPException(
            status_code=404, detail=f"Unknown cap_id: {cap_id}")

    target = companies.loc[[cap_id]]
    peers = companies.drop(index=cap_id)

    return {
        "target": records(target)[0],
        "peers": records(peers),
        "count": len(peers),
    }


@router.get("/recommendation")
@router.get("/recommendation/{cap_id}")
@json_disk_cache(get_settings().data_dir / "cache" / "recommendations")
def get_recommendation(
    basic_metrics: str,
    max_peers: int,
    cap_id: Optional[str] = None,
    company_name: Optional[str] = None,
    use_agent: bool = True,
) -> dict:
    """Our own peers plus the model's, merged by a second pass into one ranking.

    Give a cap_id for a company we hold and its VCC peers come along. Give a
    company_name instead for one we don't hold: the model works from the name
    alone, and there are no VCC peers to merge.

    `use_agent` picks only HOW the model peers are found, not what comes back:
    both paths return the same fields, and both are labelled `recommended_by:
    "agent"`. The LangGraph agent runs its own search loop; `use_agent=false`
    uses one prompt over searches we fetch first, which is faster and brings
    real metric figures with a source URL each.

    Cached on all five params together, so the same company asked with
    different metrics is a separate entry. The cache is a JSON file per entry
    under data/cache/recommendations, so it survives restarts and is shared by
    every worker — rehearsing a combination is what makes it instant later.
    """
    cap_id = blank_to_none(cap_id)
    company_name = blank_to_none(company_name)

    if cap_id:
        data = get_vcc_peers(cap_id)
        target = data["target"]
        vcc_peers = data["peers"]
    elif company_name:
        target = {"Name": company_name}
        vcc_peers = []
    else:
        raise HTTPException(
            status_code=400, detail="Provide either cap_id or company_name"
        )

    started = upstream.now()
    recommend = get_agent_recommendation if use_agent else get_model_recommendation

    # Our own peers are grounded ALONGSIDE the model's, not after them. Nothing
    # else touches vcc_peers while the agent works through its search loop, so
    # one search per peer and one scoring call fit inside that window and add
    # almost no wall clock of their own. Running it afterwards would cost the
    # user the whole of it.
    #
    # ground_vcc_peers never raises, so there is nothing to catch around it: a
    # run that cannot ground its own peers falls back to how every run behaved
    # before it existed.
    vcc_sources: list = []

    with ThreadPoolExecutor(max_workers=1) as pool:
        grounding = (
            pool.submit(ground_vcc_peers, target, vcc_peers, basic_metrics)
            if get_settings().vcc_grounding
            else None
        )

        try:
            model_recommendation = recommend(target, basic_metrics, max_peers)
        except upstream.UpstreamError:
            raise
        except Exception as exc:
            # Name the service that failed rather than returning a bare 500: on
            # a demo the operator needs to know whether to swap a key or pick
            # another target, not to go reading the log.
            failure = upstream.classify(exc)
            if failure is None:
                raise
            raise upstream.UpstreamError(failure, str(exc)) from exc

        if grounding is not None:
            vcc_peers, vcc_sources = grounding.result()

    # A run whose searches all failed produces peers from the model's memory,
    # with no sources. That must not reach the screen looking like research.
    upstream.check_search_health(started)

    model_peers = model_recommendation.get("recommended_peers", [])

    # Invented figures, only when OI3_PEER_METRICS says so and only where there
    # are none. Both engines research real ones by default, and those must
    # never be overwritten.
    #
    # Worth knowing before switching this on: generate_company draws every
    # field independently, so a peer comes back with a billion in REVENUE
    # beside three million of TOTAL_REVENUE, and a GROSS_MARGIN that its own
    # REVENUE and COGS do not produce. The rerank reads that as a data-quality
    # failure and marks the peer down for it, correctly.
    if get_settings().peer_metrics == "mock":
        for peer in model_peers:
            if not peer.get("metrics"):
                mock = generate_company(peer["company_name"], use_llm=False)
                peer["metrics"] = {metric: mock[metric] for metric in RANGES}

    # One list for the whole run: the pages the model path retrieved and the
    # ones read for our own peers, folded together on URL so a page that served
    # both says so once rather than appearing twice.
    sources = merge_sources(model_recommendation.get("sources", []), vcc_sources)
    # Both engines now return the same contract, so the output does not tell
    # them apart: a peer that came from the model side is labelled "agent"
    # either way.
    ranking = rerank_peers(target, vcc_peers, model_peers,
                           basic_metrics, max_peers, sources=sources)

    return {
        "target": target,
        "best_peer": ranking.get("best_peer"),
        "ranked_peers": ranking.get("ranked_peers", []),
        "excluded": ranking.get("excluded", []),
        "counts": {
            "vcc": len(vcc_peers),
            "model": len(model_peers),
            "ranked": len(ranking.get("ranked_peers", [])),
        },
        "sources": sources,
    }
