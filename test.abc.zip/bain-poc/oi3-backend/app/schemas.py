"""Pydantic models for the peers and search APIs."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


# ── Enums ────────────────────────────────────────────────────────────────────
class Listing(str, Enum):
    public = "public"
    private = "private"


class PeerScope(str, Enum):
    """Breadth of the proposed peer set, mirroring the target-setup step."""

    tight = "tight"
    standard = "standard"
    full = "full"


class Confidence(str, Enum):
    high = "high"
    med = "med"
    pending = "pending"


class CriterionLevel(str, Enum):
    strong = "strong"
    partial = "partial"
    weak = "weak"


class Comparability(str, Enum):
    yes = "yes"
    partial = "partial"
    no = "no"


class CandidateTag(str, Enum):
    suggested = "suggested"
    longlist = "longlist"


class MatchField(str, Enum):
    ticker = "ticker"
    name = "name"
    alias = "alias"
    sector = "sector"


# ── Building blocks ──────────────────────────────────────────────────────────
class BusinessUnit(BaseModel):
    name: str
    share: str
    target_equivalent: str = Field(
        description="Closest equivalent unit at the target company"
    )
    comparability: Comparability


class IsolatableUnit(BaseModel):
    name: str
    note: str


class DataSource(BaseModel):
    """One data source behind a peer, with its full audit trail."""

    label: str
    detail: str
    raw: str = Field(description="Figure as reported by the source, before adjustment")
    adjustment: str = Field(description="What the agent changed, and why")
    adjusted: str = Field(description="Figure actually used in benchmarking")
    comparable: str = Field(
        description="Why the adjusted figure is like-for-like with the target"
    )
    adjusted_flag: bool = Field(
        default=False,
        description="True when a real adjustment was applied to the raw figure",
    )


class AnalystView(BaseModel):
    bank: str
    rating: str
    date: str
    insight: str
    priorities: str


class CriteriaScores(BaseModel):
    model: CriterionLevel
    scale: CriterionLevel
    region: CriterionLevel
    market: CriterionLevel
    product: CriterionLevel
    growth: CriterionLevel


class CriterionBreakdown(BaseModel):
    key: str
    label: str
    level: CriterionLevel
    value: float = Field(description="Normalised 0-1 value, for the radar plot")


class ComparabilitySummary(BaseModel):
    score: float = Field(description="Weighted mean of criteria levels, 1.0-3.0")
    label: str = Field(description="High / Medium / Lower comparability")
    factors: list[CriterionBreakdown]


# ── Peers ────────────────────────────────────────────────────────────────────
class PeerSummary(BaseModel):
    """Tile-level view of a peer — what the grid renders."""

    id: str
    name: str
    ticker: Optional[str] = None
    exchange: Optional[str] = None
    listing: Listing = Listing.public
    display_ticker: str = Field(description="e.g. 'ADS · XETRA' or 'Private'")
    headline: str
    reason: str
    selected: bool
    flagged: bool = False
    flag_reason: Optional[str] = None
    confidence: Confidence
    confidence_pct: int = Field(ge=0, le=100)
    scope: PeerScope = PeerScope.standard
    manually_added: bool = False
    data_gate_required: bool = False
    business_unit_only: Optional[str] = Field(
        default=None,
        description="Set when the peer is narrowed to a single business unit",
    )
    comparability: ComparabilitySummary


class PeerDetail(PeerSummary):
    """Everything behind a peer tile: rationale, criteria, analyst read, sources."""

    why: str
    business_units: list[BusinessUnit] = Field(default_factory=list)
    isolatable_unit: Optional[IsolatableUnit] = None
    sources: list[DataSource] = Field(default_factory=list)
    metrics: dict[str, str] = Field(default_factory=dict)
    confidence_note: str = ""
    criteria: CriteriaScores
    analyst: Optional[AnalystView] = None
    adjustments_applied: int = 0


class PeerSetResponse(BaseModel):
    target_id: str
    target_name: str
    scope: PeerScope
    total: int
    selected_count: int
    flagged_count: int
    confirmed: bool
    criteria_weights: dict[str, float]
    peers: list[PeerSummary]


class PeerCreateRequest(BaseModel):
    """Add a peer, either by company id from search or by free-form name."""

    company_id: Optional[str] = Field(
        default=None, description="Id from /search/companies"
    )
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    ticker: Optional[str] = Field(default=None, max_length=32)
    exchange: Optional[str] = Field(default=None, max_length=32)
    listing: Optional[Listing] = None
    note: Optional[str] = Field(default=None, max_length=500)

    @field_validator("name", "ticker", "exchange", "note")
    @classmethod
    def _strip(cls, v: Optional[str]) -> Optional[str]:
        return v.strip() if isinstance(v, str) else v

    def require_identity(self) -> None:
        if not self.company_id and not self.name:
            raise ValueError("either company_id or name is required")


class PeerUpdateRequest(BaseModel):
    selected: Optional[bool] = None
    isolate_business_unit: Optional[str] = Field(
        default=None,
        description="Narrow the peer to one business unit, e.g. 'Vans' for VF Corp",
    )
    clear_business_unit: bool = Field(
        default=False, description="Undo a previous business-unit isolation"
    )


class ConfirmRequest(BaseModel):
    peer_ids: Optional[list[str]] = Field(
        default=None,
        description="Optional explicit final selection; defaults to the current selection",
    )


class ConfirmResponse(BaseModel):
    target_id: str
    confirmed: bool
    selected_count: int
    peer_ids: list[str]
    warnings: list[str] = Field(default_factory=list)
    message: str


# ── Search ───────────────────────────────────────────────────────────────────
class CompanyResult(BaseModel):
    id: str
    name: str
    ticker: Optional[str] = None
    exchange: Optional[str] = None
    listing: Listing
    sector: Optional[str] = None
    sub_sector: Optional[str] = None
    country: Optional[str] = None
    display_ticker: str
    score: float = Field(ge=0, le=1, description="Match strength, 1.0 is an exact hit")
    matched_on: MatchField
    matched_text: str
    in_peer_set: bool = False
    data_gate: list[str] = Field(
        default_factory=list,
        description="Documents needed before this peer can benchmark",
    )


class CompanySearchResponse(BaseModel):
    query: str
    count: int
    limit: int
    results: list[CompanyResult]


class CandidateResult(BaseModel):
    id: str
    name: str
    sub: str
    tag: CandidateTag
    headline: str
    short_reason: str
    why: str
    not_included: str
    data_gate: list[str] = Field(default_factory=list)
    in_peer_set: bool = False


class CandidateListResponse(BaseModel):
    target_id: str
    suggested: list[CandidateResult]
    longlist: list[CandidateResult]
    count: int


class SuggestItem(BaseModel):
    id: str
    label: str
    sub: str
    score: float


class SuggestResponse(BaseModel):
    query: str
    items: list[SuggestItem]


# ── Targets & misc ───────────────────────────────────────────────────────────
class Target(BaseModel):
    id: str
    name: str
    legal_name: str
    ticker: Optional[str] = None
    exchange: Optional[str] = None
    listing: Listing
    sector: str
    sub_sector: Optional[str] = None
    country: Optional[str] = None
    metrics: dict[str, str] = Field(default_factory=dict)


class ErrorResponse(BaseModel):
    detail: str


class Health(BaseModel):
    status: str
    version: str
    targets: int
    peers: int
    companies: int
