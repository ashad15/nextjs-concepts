"""Claude API client.

Thin wrapper around the Anthropic SDK. Streams the response and returns the
final text, so long generations don't hit the SDK's HTTP timeout.
"""

import logging
import os
from typing import Optional

import anthropic

from app.config import get_settings

logger = logging.getLogger(__name__)


def call_claude(
    prompt: str,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    system: Optional[str] = None,
    tools: Optional[list] = None,
    timeout: Optional[float] = None,
) -> str:
    """Send `prompt` to Claude and return the response text."""
    settings = get_settings()

    if not os.getenv("ANTHROPIC_API_KEY"):
        raise ValueError("ANTHROPIC_API_KEY is not set")

    # max_retries=0 so the deadline is the deadline: one attempt, then give up.
    client = anthropic.Anthropic(
        timeout=timeout or settings.claude_timeout_seconds,
        max_retries=0,
    )

    kwargs = {
        "model": model or settings.claude_model,
        "max_tokens": max_tokens or settings.claude_max_tokens,
        # Adaptive thinking: Claude decides how much to reason per request.
        "thinking": {"type": "adaptive"},
        "output_config": {"effort": settings.claude_effort},
        "messages": [{"role": "user", "content": prompt}],
    }
    if system:
        kwargs["system"] = system
    if tools:
        # Server-side tools (web_search / web_fetch) run on Anthropic's side:
        # Claude issues the queries and the results come back in this same call.
        kwargs["tools"] = tools

    # Streaming keeps long responses from tripping the 10-minute request timeout.
    with client.messages.stream(**kwargs) as stream:
        response = stream.get_final_message()

    if response.stop_reason == "refusal":
        detail = getattr(response.stop_details, "category", None)
        logger.warning("Claude refused the request (category=%s)", detail)
        raise RuntimeError(f"Claude declined this request (category={detail})")

    return "".join(block.text for block in response.content if block.type == "text")


if __name__ == "__main__":
    # Manual smoke test: python -m app.services.claude
    print(call_claude("hello ji"))
