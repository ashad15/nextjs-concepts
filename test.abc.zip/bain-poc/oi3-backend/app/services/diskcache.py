"""A cache that outlives the process.

`functools.lru_cache` is bounded by entry count, holds its dict on the function
object, and dies with the process — so every restart, every `--reload` after a
code edit, and every worker beyond the first starts cold, and a cold miss means
a full round of web searches and model calls.

This keeps the same call signature and adds a JSON file per entry, so a
combination that has been run once stays answerable afterwards, including
across restarts and across workers. Rehearsing a demo is therefore also
recording it.

Deliberately not included: serving a stale entry when a live call fails.
A wrong-but-plausible answer is worse than a visible error, so failures
surface (see app.services.upstream) rather than being papered over.
"""

import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)


def _key(args: tuple, kwargs: dict) -> str:
    """A stable filename for one set of arguments.

    sorted() on the kwargs so the same call keyed by a different argument order
    is the same entry.
    """
    payload = json.dumps(
        {"args": args, "kwargs": sorted(kwargs.items())},
        default=str,
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:32]


def json_disk_cache(directory: Path) -> Callable:
    """Cache a function's JSON-serialisable return value in `directory`.

    Preserves the wrapped signature via functools.wraps, which is what lets
    FastAPI keep binding the query parameters: it resolves the signature
    through __wrapped__, exactly as it already does for lru_cache.
    """

    def decorate(fn: Callable) -> Callable:
        import functools

        @functools.wraps(fn)
        def wrapper(*args, **kwargs) -> Any:
            directory.mkdir(parents=True, exist_ok=True)
            path = directory / f"{_key(args, kwargs)}.json"

            if path.exists():
                try:
                    cached = json.loads(path.read_text())
                    logger.info("Cache hit: %s", path.name)
                    return cached
                except (OSError, json.JSONDecodeError) as exc:
                    # A truncated file from an interrupted write: recompute.
                    logger.warning("Unreadable cache entry %s: %s", path.name, exc)

            logger.info("Cache miss: %s", path.name)
            result = fn(*args, **kwargs)

            _write(path, result)
            return result

        wrapper.cache_dir = directory  # type: ignore[attr-defined]
        return wrapper

    return decorate


def _write(path: Path, result: Any) -> None:
    """Write via a temp file, so an interrupted run cannot leave a half entry."""
    if not result:
        logger.warning("Not caching an empty result for %s", path.name)
        return

    temp = path.with_suffix(".tmp")
    try:
        temp.write_text(json.dumps(result, default=str))
        temp.replace(path)
    except (OSError, TypeError) as exc:
        logger.warning("Could not cache %s: %s", path.name, exc)
        temp.unlink(missing_ok=True)
