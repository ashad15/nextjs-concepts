import pandas as pd
from app.config import Settings


def ingest(settings: Settings) -> dict:
    """Read -> transpose -> score -> parquet -> {cap_id: {...}, ...}."""
    raw = pd.read_csv(settings.data_dir / settings.source_file, index_col=0)
    print("1. raw       ", raw.shape, "- metrics as rows, companies as columns")

    df = raw.T.rename_axis(columns=None)

    parsed = df.apply(pd.to_numeric, errors="coerce")
    metrics = parsed.columns[parsed.notna().sum() == df.notna().sum()]

    df[metrics] = parsed[metrics].replace(0, float("nan"))

    # Ticker, Cap_id, Name, SECTOR, INDUSTRY... and the metrics worth scoring.
    text_cols = settings.text_columns
    KEEP_METRICS = settings.keep_metrics

    keep = [c for c in df.columns if c in set(text_cols) | set(KEEP_METRICS)]
    clean = df[keep].copy()
    kept = [c for c in keep if c in set(KEEP_METRICS)]
    print(
        "2. kept      ",
        clean.shape,
        "-",
        len(kept),
        "metrics +",
        len(text_cols),
        "text",
    )

    # Harmonic mean of completeness and non-zero rate, per company.
    # completeness = clean[kept].notna().mean(axis=1)
    # non_zero = 1 - (clean[kept] == 0).mean(axis=1)
    # clean["confidence_score"] = (
    #     2 * completeness * non_zero / (completeness + non_zero)).fillna(0) * 100

    # Drop the SELF_ID/PEER_xx labels entirely; Cap_id is the only index.
    clean = clean.reset_index(drop=True).set_index("Cap_id")

    # .db here is still parquet on disk, just a different file extension.
    out = clean.astype({c: str for c in clean.columns[clean.dtypes == object]})
    out.to_parquet(settings.data_dir / settings.parquet_file, index=True)
    print("3. wrote     ", settings.data_dir / settings.parquet_file)

    return clean.to_dict("index")
