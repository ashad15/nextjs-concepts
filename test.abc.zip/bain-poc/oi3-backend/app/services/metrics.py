"""Which metrics are worth searching for, and which follow by arithmetic.

Only a minority of our columns are ever published. Revenue, COGS, capex,
receivables, payables, EBITDA, EBIT and EPS appear in filings; price and market
cap are market data; cost of equity and WACC are model outputs nobody reports.
Everything else is a ratio of the first group, so asking a model to read a
margin off a page is both wasteful and a chance for it to be wrong.

So: search the primitives, compute the rest here. A margin computed from a
cited revenue and a cited COGS cannot contradict its own inputs, which is the
failure the rerank was catching when peers arrived with independently drawn
mock figures.

The identities below are not invented. They were reverse-engineered from the
Capital IQ pull in peersdata.csv and verified to six or more decimal places
across four companies; see app/data/peersdata-sources.md. That includes the two
columns whose names do not describe them: FCF_SALES_3YR is EBITDA and
FCF_SALES_2YR is net debt.
"""

from typing import Optional

from app.config import get_settings

# Published somewhere, so worth a search.
SEARCHED = [
    "REVENUE",
    "TOTAL_REVENUE",
    "COGS",
    "CAPEX",
    "ACCOUNTS_RECEIVABLE",
    "ACCOUNTS_PAYABLE",
    "ADJUSTED_EBITDA",
    "ADJUSTED_EBIT",
    "LTM_EPS",
    "MARKET_CAP",
    "ADJUSTED_STOCK_PRICE",
    "CAPITAL_EMPLOYED",
    "REVENUE_GROWTH_1YR",
    "FCF_SALES_3YR",
    "FCF_SALES_2YR",
]

# Arithmetic on the above. Never searched, never guessed.
DERIVED = [
    "EBITDA_MARGIN",
    "EBIT_MARGIN",
    "ADJUSTED_EBIT_MARGIN",
    "GROSS_MARGIN",
    "DSO",
    "DPO",
    "CCC",
    "CCC_ADJ",
    "ADJUSTED_CCC",
    "ACTUAL_EPS",
    "REVENUE_CAGR_1YR",
    "NET_DEBT_EBITDA_1YR",
]

# CAPM outputs. No page states these, so they are modelled or they are null.
MODELLED = ["COST_OF_EQUITY", "WACC"]

# Searched to feed a derivation, but not columns of their own.
HELPERS = [
    "EBIT",
    "INVENTORY",
    "TOTAL_ASSETS",
    "TOTAL_CURRENT_LIABILITIES",
    "SHARES_OUTSTANDING",
    "BETA",
]

# What to actually type into a search engine. The column name alone finds
# nothing useful for the ones whose names are misleading.
SEARCH_TERMS = {
    "REVENUE": "revenue",
    "TOTAL_REVENUE": "total revenue including other operating income",
    "COGS": "cost of revenue cost of sales",
    "CAPEX": "capital expenditure purchases of property and equipment",
    "ACCOUNTS_RECEIVABLE": "trade and other receivables",
    "ACCOUNTS_PAYABLE": "trade and other payables",
    "ADJUSTED_EBITDA": "adjusted EBITDA",
    "ADJUSTED_EBIT": "adjusted operating profit EBIT",
    "LTM_EPS": "earnings per share diluted",
    "MARKET_CAP": "market capitalisation",
    "ADJUSTED_STOCK_PRICE": "share price",
    "CAPITAL_EMPLOYED": "capital employed",
    "REVENUE_GROWTH_1YR": "revenue growth year over year",
    # Named for what they hold, not for the column they land in.
    "FCF_SALES_3YR": "EBITDA",
    "FCF_SALES_2YR": "net debt or net cash position",
    "EBIT": "operating profit or operating loss",
    "INVENTORY": "inventories",
    "TOTAL_ASSETS": "total assets",
    "TOTAL_CURRENT_LIABILITIES": "total current liabilities",
    "SHARES_OUTSTANDING": "shares outstanding",
    "BETA": "5 year beta",
}

DAYS_IN_YEAR = 365


def value_of(entry) -> Optional[float]:
    """The number inside a metric object, or None if there isn't one."""
    if isinstance(entry, dict):
        entry = entry.get("value")
    try:
        return float(entry) if entry is not None else None
    except (TypeError, ValueError):
        return None


# Leverage is a multiple, not a proportion. Reported as a ratio it renders as
# -221.7% where it means -2.2x, which reads as a catastrophe rather than a net
# cash position.
MULTIPLE_METRICS = {"NET_DEBT_EBITDA_1YR"}


def unit_for(metric: str) -> Optional[str]:
    settings = get_settings()
    if metric in settings.monetary_metrics:
        return f"{settings.metric_currency} {settings.metric_scale}"
    if metric in settings.per_share_metrics:
        return f"{settings.metric_currency} per share"
    if metric in settings.day_count_metrics:
        return "days"
    if metric in MULTIPLE_METRICS:
        return "multiple"
    return "ratio"


# The arithmetic behind each derived column, in words a reader can check
# against the figures beside it. Kept next to the code that does the sums so
# the two cannot drift: a stated formula that no longer matches the value is
# worse than no formula, because it is trusted.
# (words, LaTeX). The words are the fallback wherever maths cannot be typeset;
# the LaTeX is what a reader checking the arithmetic actually wants to see.
# Both are written here rather than in the UI, because a formula that no longer
# matches the code beside it is worse than none at all.
FORMULAS = {
    "EBITDA_MARGIN": (
        "EBITDA ÷ Revenue",
        r"\frac{\text{EBITDA}}{\text{Revenue}}",
    ),
    "EBIT_MARGIN": (
        "EBIT ÷ Revenue",
        r"\frac{\text{EBIT}}{\text{Revenue}}",
    ),
    "ADJUSTED_EBIT_MARGIN": (
        "Adjusted EBIT ÷ Revenue",
        r"\frac{\text{Adjusted EBIT}}{\text{Revenue}}",
    ),
    "GROSS_MARGIN": (
        "(Revenue − Cost of revenue) ÷ Revenue",
        r"\frac{\text{Revenue} - \text{Cost of revenue}}{\text{Revenue}}",
    ),
    "DSO": (
        "Accounts receivable ÷ Total revenue × 365",
        r"\frac{\text{Accounts receivable}}{\text{Total revenue}} \times 365",
    ),
    "DPO": (
        "Accounts payable ÷ Cost of revenue × 365",
        r"\frac{\text{Accounts payable}}{\text{Cost of revenue}} \times 365",
    ),
    "CCC": (
        "DSO + Days inventory − DPO",
        r"\text{DSO} + \text{Days inventory} - \text{DPO}",
    ),
    "CCC_ADJ": (
        "DSO + Days inventory − DPO",
        r"\text{DSO} + \text{Days inventory} - \text{DPO}",
    ),
    "ADJUSTED_CCC": (
        "DSO + Days inventory − DPO",
        r"\text{DSO} + \text{Days inventory} - \text{DPO}",
    ),
    "ACTUAL_EPS": ("Same figure as LTM EPS", r"\text{LTM EPS}"),
    "REVENUE_CAGR_1YR": (
        "Same figure as 1 year revenue growth",
        r"\text{1 year revenue growth}",
    ),
    "NET_DEBT_EBITDA_1YR": (
        "Net debt ÷ EBITDA",
        r"\frac{\text{Net debt}}{\text{EBITDA}}",
    ),
    "CAPITAL_EMPLOYED": (
        "Total assets − Total current liabilities",
        r"\text{Total assets} - \text{Total current liabilities}",
    ),
    "MARKET_CAP": (
        "Share price × Shares outstanding",
        r"\text{Share price} \times \text{Shares outstanding}",
    ),
}


def computed(value: Optional[float], inputs: list, metric: str) -> Optional[dict]:
    """A derived metric, carrying the arithmetic and the columns behind it."""
    if value is None:
        return None

    words, latex = FORMULAS.get(metric, (None, None))

    return {
        "value": round(value, 6),
        "unit": unit_for(metric),
        "origin": "computed",
        "formula": words,
        "formula_latex": latex,
        "inputs": sorted(inputs),
    }


def modelled(value: Optional[float], method: str, metric: str) -> Optional[dict]:
    if value is None:
        return None
    return {
        "value": round(value, 6),
        "unit": unit_for(metric),
        "origin": "modelled",
        "method": method,
    }


def ratio(numerator: Optional[float], denominator: Optional[float]) -> Optional[float]:
    """Divide, or return None rather than raising or inventing a zero.

    A denominator of zero is the pre-revenue case: Zelluna reports essentially
    no revenue, so its margins are undefined, not infinite.
    """
    if numerator is None or not denominator:
        return None
    return numerator / denominator


def margin_base(found: dict) -> Optional[float]:
    """The denominator a margin divides by: the narrow revenue line.

    Capital IQ divides margins by REVENUE, and peersdata.csv proves it: DBV's
    gross margin of 0.439560 is (0.250637 - 0.140467) / 0.250637, the narrow
    line, not the 5.268884 of TOTAL_REVENUE. Researched peers have to use the
    same definition or the rerank compares two different measures.

    Falls back to TOTAL_REVENUE only when REVENUE is nil, which is the ProQR
    case: Capital IQ books all of its income as total revenue, so the narrow
    line is zero and dividing by it would void every margin in the row.
    """
    return value_of(found.get("REVENUE")) or value_of(found.get("TOTAL_REVENUE"))


def turnover_base(found: dict) -> Optional[float]:
    """The denominator DSO divides by: revenue including other income.

    The opposite preference to margins, and deliberately so. Receivables arise
    from the whole of a company's income, so the narrow line overstates the
    days badly: DBV's own figures put it at 367 days on REVENUE and 17 on
    TOTAL_REVENUE.
    """
    return value_of(found.get("TOTAL_REVENUE")) or value_of(found.get("REVENUE"))


def cost_of_equity(beta: Optional[float]) -> tuple[Optional[float], str]:
    """CAPM, with a beta floor. Returns the rate and the method that made it.

    Real 5Y betas for small-cap biotech come back near zero or negative, which
    would put the cost of equity below the risk-free rate. The floor is the
    lowest beta implied by the Capital IQ rates already in peersdata.csv, so
    the output stays inside the band that data occupies.
    """
    settings = get_settings()

    if beta is None:
        used, why = settings.capm_peer_beta, "peer median beta"
    elif beta < settings.capm_beta_floor:
        used, why = settings.capm_beta_floor, f"beta {beta:.2f} floored"
    else:
        used, why = beta, f"beta {beta:.2f}"

    rate = settings.capm_risk_free_rate + used * settings.capm_equity_risk_premium
    method = (
        f"CAPM: {settings.capm_risk_free_rate:.2%} risk free "
        f"+ {used:.3f} x {settings.capm_equity_risk_premium:.2%} ERP ({why})"
    )
    return rate, method


def derive(found: dict) -> dict:
    """The full metric object for one peer, from whatever the search found.

    `found` maps a SEARCHED or HELPERS name to the extraction model's object
    for it, or to None. Every key in SEARCHED + DERIVED + MODELLED comes back,
    null where there was nothing to work from, so the shape never varies.
    """
    settings = get_settings()

    base = margin_base(found)
    turnover = turnover_base(found)
    cogs = value_of(found.get("COGS"))
    ebitda = value_of(found.get("FCF_SALES_3YR"))
    net_debt = value_of(found.get("FCF_SALES_2YR"))

    metrics = {name: found.get(name) for name in SEARCHED}

    # Two searched columns can be recovered from their parts when the search
    # missed them outright.
    if metrics.get("CAPITAL_EMPLOYED") is None:
        assets = value_of(found.get("TOTAL_ASSETS"))
        current = value_of(found.get("TOTAL_CURRENT_LIABILITIES"))
        if assets is not None and current is not None:
            metrics["CAPITAL_EMPLOYED"] = computed(
                assets - current,
                ["TOTAL_ASSETS", "TOTAL_CURRENT_LIABILITIES"],
                "CAPITAL_EMPLOYED",
            )

    if metrics.get("MARKET_CAP") is None:
        price = value_of(found.get("ADJUSTED_STOCK_PRICE"))
        shares = value_of(found.get("SHARES_OUTSTANDING"))
        if price is not None and shares is not None:
            metrics["MARKET_CAP"] = computed(
                price * shares,
                ["ADJUSTED_STOCK_PRICE", "SHARES_OUTSTANDING"],
                "MARKET_CAP",
            )

    metrics["EBITDA_MARGIN"] = computed(
        ratio(ebitda, base), ["FCF_SALES_3YR", "REVENUE"], "EBITDA_MARGIN"
    )
    metrics["EBIT_MARGIN"] = computed(
        ratio(value_of(found.get("EBIT")), base), ["EBIT", "REVENUE"], "EBIT_MARGIN"
    )
    metrics["ADJUSTED_EBIT_MARGIN"] = computed(
        ratio(value_of(found.get("ADJUSTED_EBIT")), base),
        ["ADJUSTED_EBIT", "REVENUE"],
        "ADJUSTED_EBIT_MARGIN",
    )
    metrics["GROSS_MARGIN"] = computed(
        ratio(base - cogs, base) if base is not None and cogs is not None else None,
        ["REVENUE", "COGS"],
        "GROSS_MARGIN",
    )

    # Working capital. Each is only reported when it lands somewhere a human
    # would accept: past the ceiling the ratio is arithmetic on mismatched
    # bases, and a 630-day DSO drags peer scoring around for no reason.
    ceiling = settings.working_capital_max_days

    dso = ratio(value_of(found.get("ACCOUNTS_RECEIVABLE")), turnover)
    dso = dso * DAYS_IN_YEAR if dso is not None else None
    dpo = ratio(value_of(found.get("ACCOUNTS_PAYABLE")), cogs)
    dpo = dpo * DAYS_IN_YEAR if dpo is not None else None
    dio = ratio(value_of(found.get("INVENTORY")), cogs)
    dio = dio * DAYS_IN_YEAR if dio is not None else None

    if dso is not None and abs(dso) > ceiling:
        dso = None
    if dpo is not None and abs(dpo) > ceiling:
        dpo = None

    metrics["DSO"] = computed(dso, ["ACCOUNTS_RECEIVABLE", "TOTAL_REVENUE"], "DSO")
    metrics["DPO"] = computed(dpo, ["ACCOUNTS_PAYABLE", "COGS"], "DPO")

    # CCC needs at least one leg. Inventory is genuinely nil for most of this
    # universe, so a missing one counts as zero days rather than voiding it.
    if dso is None and dpo is None:
        cycle = None
    else:
        cycle = (dso or 0.0) + (dio or 0.0) - (dpo or 0.0)

    inputs = ["DSO", "DPO"] + (["INVENTORY"] if dio is not None else [])
    for name in ("CCC", "CCC_ADJ", "ADJUSTED_CCC"):
        metrics[name] = computed(cycle, inputs, name)

    # Exact restatements of another column.
    metrics["ACTUAL_EPS"] = computed(value_of(found.get("LTM_EPS")), ["LTM_EPS"], "ACTUAL_EPS")
    metrics["REVENUE_CAGR_1YR"] = computed(
        value_of(found.get("REVENUE_GROWTH_1YR")), ["REVENUE_GROWTH_1YR"], "REVENUE_CAGR_1YR"
    )
    metrics["NET_DEBT_EBITDA_1YR"] = computed(
        ratio(net_debt, ebitda), ["FCF_SALES_2YR", "FCF_SALES_3YR"], "NET_DEBT_EBITDA_1YR"
    )

    rate, method = cost_of_equity(value_of(found.get("BETA")))

    metrics["COST_OF_EQUITY"] = (
        modelled(rate, method, "COST_OF_EQUITY")
        if settings.model_cost_of_equity
        else None
    )

    # Off by default: see model_wacc in config for why scaling Ke by a ratio
    # observed in three rows is not a weighted average cost of capital.
    metrics["WACC"] = (
        modelled(
            rate * settings.wacc_to_cost_of_equity if rate is not None else None,
            f"{method}, x {settings.wacc_to_cost_of_equity:.4f} observed WACC/Ke",
            "WACC",
        )
        if settings.model_wacc
        else None
    )

    return {name: metrics.get(name) for name in SEARCHED + DERIVED + MODELLED}


def coverage(metrics: dict) -> dict:
    """How many metrics came from a page, arithmetic, a model, or nowhere."""
    counts = {"web": 0, "computed": 0, "modelled": 0, "missing": 0}
    for entry in (metrics or {}).values():
        if not isinstance(entry, dict) or entry.get("value") is None:
            counts["missing"] += 1
        else:
            counts[entry.get("origin", "web")] = counts.get(entry.get("origin", "web"), 0) + 1
    return counts
