"""OpenAI API client.

Thin wrapper around the OpenAI SDK, shaped like `app.services.claude` so the
two are drop-in swappable. Streams the response and returns the final text,
so long generations don't hit the SDK's HTTP timeout.
"""

import logging
import os
from typing import Optional

from openai import OpenAI

from app.config import get_settings

logger = logging.getLogger(__name__)


def call_openai(
    prompt: str,
    model: Optional[str] = None,
    max_tokens: Optional[int] = None,
    system: Optional[str] = None,
    timeout: Optional[float] = None,
) -> str:
    """Send `prompt` to GPT and return the response text."""
    settings = get_settings()

    if not os.getenv("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY is not set")

    # max_retries=0 so the deadline is the deadline: one attempt, then give up.
    client = OpenAI(
        timeout=timeout or settings.openai_timeout_seconds,
        max_retries=0,
    )

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    budget = max_tokens or settings.openai_max_tokens

    # Streaming keeps long generations alive: the timeout then applies per
    # chunk, not to the whole request.
    stream = client.chat.completions.create(
        model=model or settings.openai_model,
        # gpt-5 rejects max_tokens; the reasoning models count thinking tokens
        # against this budget too, hence the separate name.
        max_completion_tokens=budget,
        reasoning_effort=settings.openai_effort,
        messages=messages,
        stream=True,
        stream_options={"include_usage": True},
    )

    chunks, finish_reason, usage = [], None, None
    for chunk in stream:
        if chunk.usage:
            usage = chunk.usage
        if not chunk.choices:
            continue
        choice = chunk.choices[0]
        if choice.delta and choice.delta.content:
            chunks.append(choice.delta.content)
        if choice.finish_reason:
            finish_reason = choice.finish_reason

    if usage:
        # Reasoning tokens are the usual reason a call is slow: they are
        # generated one at a time, before any visible output starts.
        reasoning = getattr(usage.completion_tokens_details, "reasoning_tokens", 0)
        logger.info(
            "tokens: %d in, %d out (%d reasoning, %d text)",
            usage.prompt_tokens,
            usage.completion_tokens,
            reasoning,
            usage.completion_tokens - reasoning,
        )

    if finish_reason == "length":
        logger.warning("GPT hit the token ceiling (%s), output is truncated", budget)

    return "".join(chunks)


if __name__ == "__main__":
    # Manual smoke test: python -m app.services.openai
    print(call_openai("hello ji"))
