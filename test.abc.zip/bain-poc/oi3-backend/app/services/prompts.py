"""Prompt templates, loaded from app/prompts/*.md.

Prompts are prose, so they live as markdown rather than as Python strings:
readable diffs, no escaping rules, and they render in the editor.

We use string.Template ($name) rather than str.format ({name}) because the
prompts contain literal JSON examples — with .format every brace would need
doubling, and one missed brace is a KeyError mid-request.
"""

from functools import lru_cache
from pathlib import Path
from string import Template

PROMPT_DIR = Path(__file__).parent.parent / "prompts"


@lru_cache
def load_prompt(name: str) -> Template:
    """Read app/prompts/<name>.md once per process."""
    path = PROMPT_DIR / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(f"Prompt not found: {path}")
    return Template(path.read_text())


def render_prompt(name: str, **values) -> str:
    """Fill a template. Raises KeyError if a placeholder was left unfilled."""
    return load_prompt(name).substitute(**values)


def bullets(items) -> str:
    """The '- ITEM' list format the prompts expect."""
    return "\n".join(f"- {item}" for item in items)
