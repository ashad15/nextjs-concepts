"""Peer recommendation."""

import json
import logging
import time
from typing import Optional

from app.config import get_settings
from app.services import upstream
from app.services.openai import call_openai
from app.services.prompts import bullets, render_prompt
from app.services.research import research_peers
from app.services.sources import SourceRegistry
from app.services.tools.webtools import format_results, web_search_many
from agents.search_peers import (
    comparability,
    comparability_of,
    criteria_map,
    find_peers,
    radar_values,
)

logger = logging.getLogger(__name__)


def build_queries(company: dict, metrics: Optional[list[str]] = None) -> list[str]:
    """Searches that chase `metrics` for one company, plus its peer list.

    29 metrics in one query returns nothing useful, so they go out in small
    batches — every batch is its own search and they all run at once.
    """
    settings = get_settings()
    name = " ".join(str(company.get(c) or "") for c in settings.search_name_columns)
    metrics = metrics if metrics is not None else settings.keep_metrics
    size = settings.tavily_metrics_per_query

    # Underscores are not words: FCF_SALES_2YR searches badly, FCF SALES 2YR does.
    terms = [metric.replace("_", " ") for metric in metrics]
    batches = [terms[i : i + size] for i in range(0, len(terms), size)]

    queries = [f"{name} competitors comparable companies peers"]
    queries += [f"{name} {' '.join(batch)}" for batch in batches]
    return queries


def build_queries_many(
    companies: list[dict], metrics: Optional[list[str]] = None
) -> list[str]:
    """Every query for every company, flattened — they all run in parallel."""
    return [query for company in companies for query in build_queries(company, metrics)]


def parse_json(response: str) -> dict:
    """Strip whatever wrapping the model added and load the JSON."""
    response = response.strip()

    if response.startswith("```"):
        response = response.replace("```json", "", 1)
        response = response.replace("```", "", 1)
        response = response.strip()

    if not response.startswith("{"):
        response = response[response.find("{") : response.rfind("}") + 1]

    return json.loads(response)


def sources_from_metrics(metrics: Optional[dict]) -> list:
    """The pages behind one peer's figures, folded into a per-peer source list.

    Every metric the model sourced carries its own URL, so this groups them the
    other way round: one entry per page, listing what it was used for.

    `figures` carries the actual readings taken off that page, not just the
    metric names, so a source can be opened and shown as an audit trail: what
    the page said, for which period, in which units. The values are already in
    hand here, so keeping them costs nothing.
    """
    found: dict = {}

    for name, entry in (metrics or {}).items():
        if not isinstance(entry, dict) or not entry.get("source_url"):
            continue
        source = found.setdefault(
            entry["source_url"],
            {
                "url": entry["source_url"],
                "name": entry.get("source_name"),
                "used_for": [],
                "figures": [],
            },
        )
        source["used_for"].append(name)
        source["figures"].append(
            {
                "metric": name,
                "value": entry.get("value"),
                "unit": entry.get("unit"),
                "period": entry.get("period"),
                # Always "web" here by construction, but stated rather than
                # implied so the UI never has to assume where a number came from.
                "origin": entry.get("origin", "web"),
            }
        )

    return list(found.values())


def merge_sources(existing: Optional[list], extra: Optional[list]) -> list:
    """Fold one source list into another, keyed on URL.

    A page cited both for a comparability criterion and for a figure is one
    entry saying it backed both, not two entries saying it backed one each.
    """
    merged = {source["url"]: source for source in existing or []}

    for source in extra or []:
        seen = merged.get(source["url"])
        if seen is None:
            merged[source["url"]] = source
            continue
        seen["used_for"] = sorted(set(seen.get("used_for") or []) | set(source.get("used_for") or []))
        seen["name"] = seen.get("name") or source.get("name")

        # One page can back both a criterion judgement and a figure. Keep both
        # kinds of evidence rather than letting the later write win.
        for key in ("figures", "evidence"):
            extra_items = source.get(key)
            if extra_items:
                seen.setdefault(key, []).extend(extra_items)

    return list(merged.values())


def peer_keys(peer: dict) -> list[str]:
    """What identifies one company across the two lists, lowercased.

    Ticker and cap_id only. Names are not comparable between the two sides: our
    own rows read "CureVac NV (CVAC)," while the model returns "CureVac NV", and
    a loose name match would eventually fold two different companies together,
    which is a worse failure than missing an overlap. Name is used only when a
    peer has no ticker at all, which happens for a model peer we do not hold.
    """
    keys = [
        str(peer.get(field) or "").strip().lower()
        for field in ("ticker", "Ticker", "cap_id", "Cap_id")
    ]
    keys = [key for key in keys if key]

    return keys or [str(peer.get("company_name") or peer.get("Name") or "").strip().lower()]


def reconcile_source_lists(ranked: list, vcc_peers: list) -> list:
    """Fold duplicate entries together and mark the peers both routes found.

    The rerank is asked to merge a company that appears in both lists into one
    entry tagged BOTH, but that leaves the strongest provenance a peer can have
    resting on the model noticing it. Two things can go wrong: it returns the
    company twice, once per list, or it ranks it from one list without spotting
    that the other holds it too. Both are decided here instead, on ticker and
    cap_id, which is something we know for certain.

    A peer found independently by our own universe and by an open search is
    better evidence of comparability than either route alone, so it is worth
    being sure about rather than hoping for.
    """
    known: dict[str, Optional[str]] = {}

    for peer in vcc_peers or []:
        cap_id = peer.get("Cap_id") or peer.get("cap_id")
        for key in peer_keys(peer):
            known[key] = cap_id

    kept: list[dict] = []
    seen: dict[str, dict] = {}

    for peer in ranked:
        keys = peer_keys(peer)
        first = next((seen[key] for key in keys if key in seen), None)

        if first is None:
            kept.append(peer)
            for key in keys:
                seen[key] = peer
            continue

        # The same company, ranked twice. Keep the better-placed entry; the
        # cap_id only ever exists on our own side.
        logger.info(
            "Collapsed duplicate ranked peer %s into rank %s",
            peer.get("ticker") or peer.get("company_name"),
            first.get("rank"),
        )
        first["cap_id"] = first.get("cap_id") or peer.get("cap_id")

        # Two entries from the same list is the model repeating itself, which
        # says nothing about provenance. Only entries from different lists are
        # evidence that both routes found the company.
        if peer.get("source_list") != first.get("source_list"):
            first["source_list"] = "BOTH"
            first["in_both"] = True

    for peer in kept:
        if peer.get("source_list") != "B":
            continue

        # Ranked from the model's list, but it sits in our universe too, and
        # the rerank did not say so.
        match = next((key for key in peer_keys(peer) if key in known), None)
        if not match:
            continue

        logger.info(
            "%s came from both routes; the rerank labelled it B",
            peer.get("ticker") or peer.get("company_name"),
        )
        peer["source_list"] = "BOTH"
        peer["in_both"] = True
        peer["cap_id"] = peer.get("cap_id") or known[match]

    # Ranks are contiguous by contract, and collapsing leaves gaps.
    for position, peer in enumerate(kept, start=1):
        peer["rank"] = position

    return kept


def sources_index(peers: list) -> dict:
    """{ticker or name (lowercased): {sources, metrics}} for the rerank to reattach.

    The rerank returns peers by name and ticker only, so this is how each one
    finds its researched material again without the model having to repeat it.
    Metrics travel with the sources because the rerank does not echo them
    either, and the UI needs the researched figure beside the page it came from.

    Fed from both lists. Our own rows carry the ingested column casing, hence
    the four field names, and since the grounding pass they carry `sources` of
    their own. Their `metrics` stay empty by design: those figures are on the
    row already and are better than anything the web returned.

    Entries merge rather than overwrite, because a company found by both routes
    has pages from each and both are worth keeping.
    """
    index: dict = {}

    for peer in peers or []:
        keys = [
            str(peer.get(field) or "").strip().lower()
            for field in ("ticker", "Ticker", "company_name", "Name")
        ]

        for key in keys:
            if not key:
                continue

            found = index.setdefault(
                key, {"sources": [], "metrics": {}, "documents": []}
            )
            found["sources"] = merge_sources(found["sources"], peer.get("sources"))
            # Only ever set from the model side, so the first list to carry
            # them wins and our own rows cannot blank them out.
            found["metrics"] = found["metrics"] or (peer.get("metrics") or {})
            found["documents"] = found["documents"] or (peer.get("documents") or [])

    return index


def get_model_recommendation(target: dict, basic_metrics: str, max_peers: int) -> dict:
    """Peers from one prompt over search results we fetched ourselves.

    Returns the same contract as get_agent_recommendation, so the endpoint's
    output does not change shape with `use_agent`: recommended_peers each carry
    criteria_scores, comparability and score, plus target_profile and sources.
    """
    settings = get_settings()

    peer_finding_metrics = [m.strip() for m in basic_metrics.split(",") if m.strip()]

    # "ADJ" metrics are our own internal definitions, not standard financial terms.
    custom_metrics = [m for m in settings.keep_metrics if "ADJ" in m]
    standard_metrics = [m for m in settings.keep_metrics if "ADJ" not in m]

    # We run the web searches ourselves and hand Claude the text, so every
    # figure it reports is already glued to a URL we actually retrieved.
    search_started = upstream.now()
    results = web_search_many(build_queries(target))

    # Keep the retrieved text before format_results folds it into one string,
    # so each source can carry a summary without being fetched again.
    registry = SourceRegistry()
    registry.record_many(results)

    research = format_results(results)

    # Checked here, before the model call, so a dead search service costs no
    # OpenAI credit on a run that could only produce an unsourced answer.
    upstream.check_search_health(search_started)

    prompt = render_prompt(
        "peer_recommendation",
        target_json=json.dumps(target, indent=2, default=str),
        peer_finding_metrics=bullets(peer_finding_metrics),
        # Same factors, same keys as the agent path scores on.
        selection_criteria=bullets(
            f"{key}: {text}"
            for key, text in criteria_map(peer_finding_metrics).items()
        ),
        identifier_fields=bullets(settings.text_columns),
        standard_metrics=bullets(standard_metrics),
        custom_metrics=bullets(custom_metrics),
        all_metrics=bullets(settings.keep_metrics),
        max_peers=max_peers,
        research=research,
    )

    started = time.monotonic()
    response = call_openai(prompt)
    logger.info("GPT recommendation took %.1fs", time.monotonic() - started)

    result = parse_json(response)

    # The bucket is arithmetic, so it is computed here rather than trusted from
    # the model — and by the same function the agent path uses, so an identical
    # criteria_scores map always yields an identical comparability.
    peers = result.get("recommended_peers") or []
    for peer in peers:
        _, bucket = comparability_of(peer.get("criteria_scores") or {})
        peer["comparability"] = bucket
        peer["sources"] = registry.enrich(sources_from_metrics(peer.get("metrics")))

    return {
        "recommended_peers": peers[:max_peers],
        "sources": registry.enrich(result.get("sources", [])),
        "target_profile": result.get("target_profile"),
    }


def get_agent_recommendation(target: dict, basic_metrics: str, max_peers: int) -> dict:
    """Same contract as get_model_recommendation, but the LangGraph agent finds
    the peers instead of one big prompt over pre-fetched search results.

    The agent runs its own search loop and scores every peer 0-100 on each
    comparability criterion, so the job here is mapping that back onto the shape
    rerank_peers already consumes. `basic_metrics` becomes extra criteria for
    the agent to weigh, alongside its six standard ones.
    """
    name = target.get("Name") or target.get("Ticker") or ""
    metrics = [m.strip() for m in basic_metrics.split(",") if m.strip()]

    # The agent searches inside its own loop, so the registry goes in with it:
    # what a page said is gone by the time the graph returns citations.
    registry = SourceRegistry()

    started = time.monotonic()
    peer_set = find_peers(name, custom_criteria=metrics, registry=registry)
    logger.info("Agent recommendation took %.1fs", time.monotonic() - started)

    peers, sources = [], {}
    for peer in sorted(peer_set.peers, key=lambda p: comparability(p)[0], reverse=True):
        mean, bucket = comparability(peer)
        label = peer.ticker or peer.company_name

        # Same grouping as the model path: one entry per page, saying which
        # criteria it backed. Built per peer, then merged into the run-wide list.
        own_sources: dict = {}
        for score in peer.scores:
            if not score.source_url:
                continue
            for group, used in ((own_sources, score.criterion),
                                (sources, f"{label}: {score.criterion}")):
                entry = group.setdefault(
                    score.source_url,
                    {"url": score.source_url, "name": None, "used_for": []},
                )
                entry["used_for"].append(used)

            # The sentence the agent wrote to justify this rating, kept against
            # the page it came from. Opening a source can then say why it
            # mattered, not only which criteria it touched.
            own_sources[score.source_url].setdefault("evidence", []).append(
                {
                    "criterion": score.criterion,
                    "score": score.score,
                    "evidence": score.evidence,
                }
            )

        peers.append(
            {
                "ticker": peer.ticker,
                "company_name": peer.company_name,
                "cap_id": None,
                "score": round(mean / 10, 1),  # rerank_peers scores out of 10
                "comparability": bucket,
                "criteria_scores": radar_values(peer),
                "reasons": [peer.summary] + [s.evidence for s in peer.scores],
                "sources": registry.enrich(list(own_sources.values())),
                # No "metrics" key yet: the agent rates criteria and collects no
                # figures. They are researched below, or left out entirely.
            }
        )

    peers = peers[:max_peers]

    # Researched after the ranking is settled, so we only pay for the peers
    # that survived. Each one gets its primitives searched and the rest
    # computed, which is what stops a peer arriving with figures that
    # contradict each other or the pages cited beside them.
    if get_settings().peer_metrics == "research":
        research_peers(peers, registry)

        for peer in peers:
            figure_sources = sources_from_metrics(peer.get("metrics"))
            peer["sources"] = registry.enrich(
                merge_sources(peer.get("sources"), figure_sources)
            )

            # The run-wide list says which company each page was used for.
            label = peer.get("ticker") or peer.get("company_name")
            for source in figure_sources:
                entry = sources.setdefault(
                    source["url"],
                    {"url": source["url"], "name": source.get("name"), "used_for": []},
                )
                entry["used_for"].extend(f"{label}: {use}" for use in source["used_for"])

    return {
        "recommended_peers": peers,
        "sources": registry.enrich(list(sources.values())),
        "target_profile": peer_set.target_profile,
    }


def metric_units() -> str:
    """Which columns are money, which are per-share, which are days.

    None of this is in the data, so the prompt is told explicitly rather than
    left to infer a currency from bare floats.
    """
    settings = get_settings()
    symbol = settings.metric_currency_symbol
    money = f"{settings.metric_currency} ({symbol}) {settings.metric_scale}"

    return "\n".join(
        [
            f"Amounts below are in {money}, so 225.4 means "
            f"{symbol}225.4 million:",
            bullets(settings.monetary_metrics),
            "",
            f"These are {settings.metric_currency} per share — same currency, "
            "never scaled:",
            bullets(settings.per_share_metrics),
            "",
            "These are counts of days:",
            bullets(settings.day_count_metrics),
            "",
            "Every other column is a ratio, not a percentage already: 0.4396 "
            "means 43.96%.",
        ]
    )


def rerank_peers(
    target: dict,
    vcc_peers: list,
    model_peers: list,
    basic_metrics: str,
    max_peers: int,
    sources: Optional[list] = None,
    model_source: str = "agent",
) -> dict:
    """Merge our own peers with the model's into one ranked list, best first.

    Every ranked peer also comes back with the four blocks the peer tile needs:
    0-100 selection-criteria scores for the radar, four display-formatted key
    metrics, estimated business units, and a grounded confidence breakdown.

    `sources` are the pages the research pass actually retrieved — they are what
    "Sources cross-checked" is counted from.

    `model_source` names whichever engine produced LIST B, and ends up in each
    peer's `recommended_by`.
    """
    peer_finding_metrics = [m.strip() for m in basic_metrics.split(",") if m.strip()]

    prompt = render_prompt(
        "peer_rerank",
        target_json=json.dumps(target, indent=2, default=str),
        peer_finding_metrics=bullets(peer_finding_metrics),
        # One source of truth for the factors: the agent scores model peers on
        # exactly these, and the rerank fills the same keys in for our own peers.
        # Derived from the caller's metrics, since CRITERIA is empty by design.
        selection_criteria=bullets(
            f"{key}: {text}"
            for key, text in criteria_map(peer_finding_metrics).items()
        ),
        metric_units=metric_units(),
        vcc_peers=json.dumps(vcc_peers, indent=2, default=str),
        model_peers=json.dumps(model_peers, indent=2, default=str),
        sources=json.dumps(sources or [], indent=2, default=str),
        max_peers=max_peers,
    )

    started = time.monotonic()
    response = call_openai(prompt)
    logger.info("GPT rerank took %.1fs", time.monotonic() - started)

    ranking = parse_json(response)

    # Provenance is derived, not asked for. The model already tags each peer
    # A / B / BOTH, and which engine filled LIST B is something we know for
    # certain here — so there is nothing for it to get wrong.
    labels = {"A": "vcc", "B": model_source, "BOTH": f"vcc+{model_source}"}

    # Decided here rather than taken on trust, so BOTH means both whether or
    # not the rerank spotted the overlap.
    ranked = reconcile_source_lists(
        ranking.get("ranked_peers") or [], vcc_peers
    )
    ranking["ranked_peers"] = ranked

    # Sources come back from the lists that went in, matched on ticker or name.
    # Asking the rerank to repeat them would invite invented URLs.
    #
    # Both lists, since the grounding pass. A VCC peer's pages back its
    # comparability judgement, not its figures, which is why it can arrive with
    # sources and still no metrics.
    index = sources_index(list(model_peers or []) + list(vcc_peers or []))
    for peer in ranked:
        peer["recommended_by"] = labels.get(peer.get("source_list"), "unknown")

        keys = [
            str(key).strip().lower()
            for key in (peer.get("ticker"), peer.get("company_name"))
            if key
        ]
        found = next((index[key] for key in keys if key in index), {})
        peer["sources"] = found.get("sources", [])
        # The researched figures themselves, each carrying how it was arrived
        # at: read off a page, computed from other columns, or modelled. A VCC
        # peer has none, because its figures are internal data already.
        peer["metrics"] = found.get("metrics", {})
        # Annual reports and filings found for this company. Reference material
        # for the screen, never a source of any figure above.
        peer["documents"] = found.get("documents", [])

    # best_peer is required to be the same company as rank 1, but carries no
    # source_list of its own.
    if ranking.get("best_peer") and ranked:
        ranking["best_peer"]["recommended_by"] = ranked[0]["recommended_by"]
        ranking["best_peer"]["sources"] = ranked[0]["sources"]
        ranking["best_peer"]["metrics"] = ranked[0]["metrics"]
        ranking["best_peer"]["documents"] = ranked[0]["documents"]

    return ranking


if __name__ == "__main__":
    # Manual smoke test: python -m app.services.recommendation
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    MAX_PEERS = 8

    from app.services.store import load_companies, records

    companies = load_companies()
    cap_id = companies.index[0]
    target = records(companies.loc[[cap_id]])[0]

    print(f"target: {cap_id} {target.get('Name')} ({target.get('Ticker')})")

    result = get_model_recommendation(
        target, "REVENUE,MARKET_CAP,EBITDA_MARGIN", MAX_PEERS
    )
    peers = result["recommended_peers"]

    print(f"peers: {len(peers)}  sources: {len(result.get('sources', []))}")
    for peer in peers:
        metrics = peer.get("metrics") or {}
        # ticker can come back null for an unlisted peer, so don't format None
        print(
            f"  {peer.get('score') or 0:>4}  {peer.get('ticker') or '-':<8} "
            f"{peer.get('company_name') or '-':<40} "
            f"{len(peer.get('reasons') or [])} reasons, {len(metrics)} metrics"
        )

    print(json.dumps(result, indent=2))

    # Second pass: merge our own peers with the model's into one ranking.
    vcc_peers = records(companies.drop(index=cap_id))
    model_peers = result.get("recommended_peers", [])

    ranking = rerank_peers(
        target, vcc_peers, model_peers, "REVENUE,MARKET_CAP,EBITDA_MARGIN", MAX_PEERS
    )

    best = ranking.get("best_peer") or {}
    print(
        f"\nbest: {best.get('company_name')} ({best.get('ticker')}) "
        f"score {best.get('final_score')} cap_id {best.get('cap_id')}"
    )
    print(f"why : {best.get('why_best')}\n")

    for peer in ranking.get("ranked_peers", []):
        print(
            f"  {peer.get('rank'):>2}. {peer.get('company_name') or '-':<38} "
            f"{peer.get('ticker') or '-':<10} {peer.get('source_list'):<5} "
            f"score {peer.get('final_score')}"
        )

    print("\nexcluded:", [e.get("company_name") for e in ranking.get("excluded", [])])
