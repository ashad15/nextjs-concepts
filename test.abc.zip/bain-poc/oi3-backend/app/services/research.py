"""Web research for peers, in two kinds that answer two different questions.

`research_peers` fills in FIGURES for the peers the agent found, because we hold
none for them. It is the expensive one: two search rounds and an extraction call
per peer.

`ground_vcc_peers` supplies EVIDENCE for the peers out of our own database,
because we already hold better figures for those than any web page carries but
nothing at all to say why they are comparable. One search each and one shared
scoring call, so it costs a fraction of the above.

Neither is a substitute for the other. Researching a VCC peer's revenue off a
web page would replace an audited figure with a worse one, and scoring an agent
peer's comparability again would only repeat what its own search loop already
decided.


Real figures for the peers the agent found, one worker per peer.

The agent rates comparability and collects no numbers, so its peers used to be
handed to the mock generator. That produced figures drawn independently of each
other, which the rerank then correctly flagged as impossible: a billion in
revenue beside three million of total revenue.

This researches the primitives instead and lets app.services.metrics compute
everything that follows. A margin derived from a cited revenue and a cited COGS
cannot contradict its own inputs.

Two rounds, widening only for what is still missing:

  1. the peer's own cited pages plus a curated trusted list
  2. the open web, for the figures round one did not find

Peers are researched concurrently. The work is almost entirely waiting on HTTP,
so a thread each is the right primitive; there is nothing here that wants an
agent protocol or a separate process.
"""

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Optional
from urllib.parse import urlsplit

from app.config import get_settings
from app.services.metrics import HELPERS, SEARCH_TERMS, SEARCHED, derive
from app.services.openai import call_openai
from app.services.prompts import bullets, render_prompt
from app.services.sources import SourceRegistry
from app.services.tools.webtools import format_results, web_search_many
from agents.search_peers import criteria_map

logger = logging.getLogger(__name__)

# Everything the extractor is asked for: the columns we search plus the inputs
# that only exist to feed a derivation.
WANTED = SEARCHED + HELPERS

# One query per theme rather than one per metric. A filings page carries most
# of a statement at once, so four searches retrieve more than twenty would.
# Between them these must name every figure in WANTED, or the ones left out are
# never searched for and come back null forever.
QUERY_THEMES = [
    (
        "income statement",
        ["REVENUE", "TOTAL_REVENUE", "COGS", "EBIT", "ADJUSTED_EBIT", "LTM_EPS",
         "REVENUE_GROWTH_1YR"],
    ),
    (
        "balance sheet",
        ["ACCOUNTS_RECEIVABLE", "ACCOUNTS_PAYABLE", "INVENTORY", "TOTAL_ASSETS",
         "TOTAL_CURRENT_LIABILITIES", "CAPITAL_EMPLOYED"],
    ),
    (
        "cash flow and leverage",
        ["CAPEX", "FCF_SALES_3YR", "FCF_SALES_2YR", "ADJUSTED_EBITDA"],
    ),
    (
        "market data",
        ["MARKET_CAP", "ADJUSTED_STOCK_PRICE", "SHARES_OUTSTANDING", "BETA"],
    ),
]

# Query text stays readable: a search naming a dozen line items matches nothing
# in particular. The theme still owns all its metrics for gap tracking.
MAX_TERMS_PER_QUERY = 5

UNCOVERED = sorted(set(WANTED) - {name for _, names in QUERY_THEMES for name in names})
if UNCOVERED:
    logger.error(
        "No query theme asks for %s, so they can never be found. Add them to "
        "QUERY_THEMES.",
        ", ".join(UNCOVERED),
    )


def label(peer: dict) -> str:
    """How to name this company in a search."""
    name = peer.get("company_name") or ""
    ticker = peer.get("ticker") or ""
    return f"{name} {ticker}".strip() or "unknown company"


def queries_for(peer: dict, wanted: Optional[list] = None) -> list[str]:
    """Search queries for one peer, one per theme that still has a gap."""
    company = label(peer)
    outstanding = set(wanted or WANTED)

    queries = []
    for theme, metrics in QUERY_THEMES:
        # Only the gaps, so a second round chases what the first one missed
        # instead of re-running the same search.
        gaps = [name for name in metrics if name in outstanding]
        if not gaps:
            continue
        terms = " ".join(
            SEARCH_TERMS.get(name, name.lower().replace("_", " "))
            for name in gaps[:MAX_TERMS_PER_QUERY]
        )
        queries.append(f"{company} {theme} {terms}")

    return queries


def domains_of(sources: Optional[list]) -> list[str]:
    """Hosts the research already cited for this peer.

    Usually includes the company's own site, which is the most authoritative
    place its figures appear, and costs nothing to discover because the agent
    already retrieved it.
    """
    hosts = []
    for source in sources or []:
        host = urlsplit(source.get("url") or "").netloc.lower()
        host = host[4:] if host.startswith("www.") else host
        if host and host not in hosts:
            hosts.append(host)
    return hosts


def wanted_block(names: list[str]) -> str:
    """The FIGURES TO EXTRACT list, naming what each column actually holds."""
    return "\n".join(f"- {name}: {SEARCH_TERMS.get(name, name)}" for name in names)


def extract(peer: dict, research: str, wanted: list[str]) -> dict:
    """One model call: figures out of retrieved text, for one company."""
    if not research.strip():
        return {}

    prompt = render_prompt(
        "peer_metrics",
        company=json.dumps(
            {k: peer.get(k) for k in ("company_name", "ticker", "cap_id")},
            indent=2,
            default=str,
        ),
        wanted=wanted_block(wanted),
        research=research,
    )

    try:
        response = call_openai(prompt)
    except Exception as exc:
        # One peer failing to extract must not take the whole ranking down.
        logger.warning("Metric extraction failed for %s: %s", label(peer), exc)
        return {}

    try:
        text = response if response.strip().startswith("{") else response[
            response.find("{") : response.rfind("}") + 1
        ]
        figures = (json.loads(text) or {}).get("figures") or {}
    except (ValueError, AttributeError) as exc:
        logger.warning("Unparsable extraction for %s: %s", label(peer), exc)
        return {}

    # Only keys we asked for, only entries carrying both a number and a URL.
    return {
        name: entry
        for name, entry in figures.items()
        if name in wanted
        and isinstance(entry, dict)
        and entry.get("value") is not None
        and entry.get("source_url")
    }


def as_metric(entry: dict) -> dict:
    """The extractor's object, in the shape the rest of the app expects."""
    currency = entry.get("currency") or get_settings().metric_currency
    return {
        "value": entry.get("value"),
        # Currency is reported, never converted, so it is carried rather than
        # assumed. A ratio computed from two figures in one currency is safe
        # regardless of which currency that is.
        "unit": f"{currency} {get_settings().metric_scale}",
        "period": entry.get("period"),
        "origin": "web",
        "source_url": entry.get("source_url"),
        "source_name": entry.get("source_name"),
    }


def find_documents(peer: dict, registry: Optional[SourceRegistry] = None) -> list:
    """Primary documents for one peer, for display rather than extraction.

    The company's own investor relations site is the most authoritative place
    its numbers appear and the worst place to read them from: annual reports
    are PDFs, and extraction across a full run pulled no usable figure from a
    single IR domain. What those sites are good for is the document itself.

    So one search, restricted to the peer's own domains plus the filing
    registries, keeping only URLs that look like a document. Returned beside
    the peer and clearly marked as not used for any figure, so the UI can show
    "we found these" without implying anything was taken from them.
    """
    settings = get_settings()
    domains = domains_of(peer.get("sources")) + list(settings.filing_domains)

    query = f"{label(peer)} annual report financial statements 20-F 10-K filing pdf"
    results = web_search_many([query], include_domains=domains)
    if registry is not None:
        registry.record_many(results)

    documents, seen = [], set()
    for hits in results.values():
        for hit in hits:
            url = hit.get("url") or ""
            lowered = url.lower()
            if url in seen:
                continue
            if not any(m in lowered for m in settings.filing_markers):
                continue
            if any(m in lowered for m in settings.filing_exclude_markers):
                continue
            seen.add(url)
            documents.append(
                {
                    "url": url,
                    "title": hit.get("title") or url,
                    "publisher": urlsplit(url).netloc.lower(),
                    "used_for_metrics": False,
                    "note": "Found during research. Not used for any figure.",
                }
            )

    return documents


def research_peer(peer: dict, registry: Optional[SourceRegistry] = None) -> dict:
    """Every metric for one peer: searched, then computed, then modelled."""
    settings = get_settings()
    company = label(peer)

    trusted = list(settings.trusted_domains)

    found: dict = {}
    rounds = (("trusted", trusted), ("open web", None))

    for tier, domains in rounds:
        missing = [name for name in WANTED if name not in found]
        if not missing:
            break

        results = web_search_many(queries_for(peer, missing), include_domains=domains)
        if registry is not None:
            registry.record_many(results)

        figures = extract(peer, format_results(results), missing)
        found.update(figures)

        logger.info(
            "%s: %d/%d figures after the %s round",
            company,
            len(found),
            len(WANTED),
            tier,
        )

    metrics = derive({name: as_metric(entry) for name, entry in found.items()})
    return metrics


def research_peers(peers: list, registry: Optional[SourceRegistry] = None) -> list:
    """Fill `metrics` and `documents` on every peer, researching concurrently.

    Returns the same list. A peer whose research fails keeps an empty metrics
    object rather than a fabricated one, because a gap the rerank can see is
    worth more than a number it cannot check.
    """
    if not peers:
        return peers

    settings = get_settings()
    workers = min(len(peers), settings.peer_research_max_workers)

    def run(peer: dict) -> tuple:
        # Both halves in one worker, so a peer is still one thread whichever
        # of the two is slower.
        try:
            metrics = research_peer(peer, registry)
        except Exception as exc:
            logger.warning("Metric research failed for %s: %s", label(peer), exc)
            metrics = {}

        try:
            documents = find_documents(peer, registry)
        except Exception as exc:
            logger.warning("Document lookup failed for %s: %s", label(peer), exc)
            documents = []

        return metrics, documents

    with ThreadPoolExecutor(max_workers=workers) as pool:
        for peer, (metrics, documents) in zip(peers, pool.map(run, peers)):
            peer["metrics"] = metrics
            peer["documents"] = documents

    return peers


# ---------------------------------------------------------------------------
# Grounding our own peers
# ---------------------------------------------------------------------------

# What a candidate shows the grounding prompt, on top of its name and ticker.
# These are OUR figures, not web ones. Revenue scale is one of the criteria
# being scored, so withholding the audited number would only leave it to be
# guessed off a search snippet, which is the opposite of the point.
GROUNDING_FIELDS = (
    "SECTOR",
    "INDUSTRY_GROUP",
    "INDUSTRY",
    "TOTAL_REVENUE",
    "REVENUE",
    "REVENUE_GROWTH_1YR",
    "MARKET_CAP",
    "EBITDA_MARGIN",
)


def vcc_label(peer: dict) -> str:
    """How to name one of our own rows in a search.

    Our rows arrive with the ingested column casing, so Name and Ticker rather
    than the company_name and ticker the model path uses.
    """
    name = peer.get("Name") or peer.get("company_name") or ""
    ticker = peer.get("Ticker") or peer.get("ticker") or ""
    return f"{name} {ticker}".strip() or "unknown company"


def source_label(peer: dict) -> str:
    """What a page is filed under in the run-wide source list.

    Ticker first, matching the agent path, so both routes' entries read the
    same way and the UI can group them without knowing which produced them.
    """
    for field in ("Ticker", "ticker", "Name", "company_name"):
        if peer.get(field):
            return str(peer[field])
    return "unknown company"


def grounding_query(peer: dict) -> str:
    """One search per peer. Qualitative terms only: we already hold the figures."""
    return (
        f"{vcc_label(peer)} business model end markets customers "
        "geography development stage revenue scale"
    )


def grounding_candidates(vcc_peers: list) -> str:
    """The candidate block, trimmed to what a comparability call actually needs."""
    rows = []
    for peer in vcc_peers:
        row = {
            "company_name": peer.get("Name") or peer.get("company_name"),
            "ticker": peer.get("Ticker") or peer.get("ticker"),
        }
        row.update(
            {
                field: peer[field]
                for field in GROUNDING_FIELDS
                if peer.get(field) is not None
            }
        )
        rows.append(row)

    return json.dumps(rows, indent=2, default=str)


def match_keys(peer: dict) -> list[str]:
    """Lowercased ticker then name, which is how a scored entry finds its row.

    Ticker is the join that actually lands. Our Name column carries the ticker
    and a trailing comma inside it, as in "Celyad Oncology SA (CYAD),", so the
    name is a fallback for a row with no ticker rather than the primary key.
    """
    keys = [
        str(peer.get(field) or "").strip().lower()
        for field in ("Ticker", "ticker", "Name", "company_name")
    ]
    return [key for key in keys if key]


def _ground(target: dict, vcc_peers: list, criteria: dict) -> tuple[list, list]:
    """One search per peer, then one call scoring all of them together."""
    registry = SourceRegistry()

    # Its own health channel. These run concurrently with the agent's searches,
    # and a grounding pass that happens to succeed must never make a run whose
    # real research all failed look healthy enough to return.
    results = web_search_many(
        [grounding_query(peer) for peer in vcc_peers], channel="grounding"
    )
    registry.record_many(results)

    research = format_results(results)
    if not research.strip():
        logger.warning("No pages came back for our own peers; leaving them ungrounded.")
        return vcc_peers, []

    prompt = render_prompt(
        "vcc_grounding",
        target_json=json.dumps(target, indent=2, default=str),
        selection_criteria=bullets(
            f"{key}: {text}" for key, text in criteria.items()
        ),
        companies=grounding_candidates(vcc_peers),
        research=research,
    )

    # Deliberately on the default model. This is the cheapest judgement call in
    # the run and the easiest to move: call_openai already takes `model=`.
    response = call_openai(prompt)

    text = (
        response
        if response.strip().startswith("{")
        else response[response.find("{") : response.rfind("}") + 1]
    )
    scored = (json.loads(text) or {}).get("companies") or []

    found: dict = {}
    for entry in scored:
        for key in (entry.get("ticker"), entry.get("company_name")):
            if key:
                found.setdefault(str(key).strip().lower(), entry)

    shared: dict = {}
    grounded = 0

    for peer in vcc_peers:
        entry = next(
            (found[key] for key in match_keys(peer) if key in found), None
        )
        if entry is None:
            logger.info("The grounding pass returned nothing for %s", vcc_label(peer))
            continue

        label = source_label(peer)
        scores: dict = {}
        own: dict = {}

        for score in entry.get("scores") or []:
            criterion = score.get("criterion")
            if criterion not in criteria:
                continue

            # The prompt asks for an integer 0-100 and the rest of the app
            # relies on that, so anything else is dropped rather than coerced
            # into a number nobody chose.
            try:
                value = int(score.get("score"))
            except (TypeError, ValueError):
                continue
            if not 0 <= value <= 100:
                continue

            scores[criterion] = value

            url = score.get("source_url")
            if not url:
                continue

            # Same two-sided grouping as the agent path: one entry per page for
            # the peer, and one for the run, the latter naming the company.
            for group, used in ((own, criterion), (shared, f"{label}: {criterion}")):
                group.setdefault(
                    url, {"url": url, "name": None, "used_for": []}
                )["used_for"].append(used)

            own[url].setdefault("evidence", []).append(
                {
                    "criterion": criterion,
                    "score": value,
                    "evidence": score.get("evidence"),
                }
            )

        if not scores:
            continue

        # Read by the rerank, which reuses these rather than scoring the factor
        # itself. `metrics` is deliberately untouched: our figures are already
        # on the row, and they are better than anything this pass retrieved.
        peer["criteria_scores"] = scores
        peer["sources"] = registry.enrich(list(own.values()))
        peer["grounding_summary"] = entry.get("summary")
        grounded += 1

    logger.info("Grounded %d of %d of our own peers", grounded, len(vcc_peers))
    return vcc_peers, registry.enrich(list(shared.values()))


def ground_vcc_peers(
    target: dict, vcc_peers: list, basic_metrics: str
) -> tuple[list, list]:
    """Sourced comparability scores for the peers out of our own database.

    Our rows carry audited figures and nothing at all to say WHY the company is
    comparable, so the rerank has been scoring every factor for them out of its
    own judgement, unsourced, while an agent peer's identical-looking radar came
    from cited pages. This closes that gap: one search per peer and one scoring
    call over all of them, against the same criteria the agent uses.

    It does NOT research figures. See the module docstring.

    Returns the peers, each gaining `criteria_scores`, `sources` and a
    `grounding_summary` where the pass reached it, plus the run-wide source list
    to merge into the rerank's own.

    Runs its own SourceRegistry rather than sharing the agent's. The two run
    concurrently and the registry is a plain dict, so a shared one would need
    locking to buy nothing: the two passes never cite each other's pages.

    Never raises. A run that cannot ground its own peers is the situation we are
    already in today, so it degrades to that rather than taking the ranking down.
    """
    if not vcc_peers:
        return vcc_peers, []

    criteria = criteria_map([m.strip() for m in basic_metrics.split(",") if m.strip()])
    if not criteria:
        logger.info("No criteria supplied, so our own peers go in ungrounded.")
        return vcc_peers, []

    started = time.monotonic()
    try:
        peers, sources = _ground(target, vcc_peers, criteria)
    except Exception as exc:
        logger.warning("Grounding our own peers failed: %s", exc)
        return vcc_peers, []

    logger.info("Grounding our own peers took %.1fs", time.monotonic() - started)
    return peers, sources
