"""What each cited page actually said, kept from the search that retrieved it.

Search already hands back {url, title, content} per hit. That content goes into
a prompt block and is then dropped, so the sources we return to callers carry a
bare URL and, on the agent path, a null name. Nothing downstream can say what a
page contained without fetching it again.

This keeps the retrieved text beside its URL for the life of one request, which
turns the summary into a join rather than a second round of network calls or an
extra model call. A model asked to describe its own citations will happily
describe a page it skimmed; the snippet here is the text we actually pulled.

Scoped per request on purpose. Two runs in flight at once would otherwise
attribute each other's pages, and a source block is exactly the thing that must
not be wrong.
"""

import re
from typing import Iterable, Optional
from urllib.parse import urlsplit, urlunsplit

from app.config import get_settings

# Runs of spaces and tabs, but NOT newlines. Search providers return page text
# as markdown, so a financials page arrives as a table, and a table is only a
# table while its rows are still on separate lines. Collapsing every whitespace
# run flattens it into a wall of pipes that nothing can render.
SPACES = re.compile(r"[^\S\n]+")

# Three or more blank lines carry no meaning and waste the character budget.
BLANK_LINES = re.compile(r"\n{3,}")

# Longest tail we will chop off to land on a sentence end. Beyond this the
# summary loses more than the tidier ending is worth, so it cuts on a word.
SENTENCE_LOOKBACK = 120

# Longest tail we will chop off to end on a line break instead of mid-row.
LINE_LOOKBACK = 200


def normalise(url: str) -> str:
    """A comparable form of a URL, so a citation matches the page we fetched.

    Models cite what they read but not always character for character: a
    trailing slash, a #fragment or a differently-cased host is the same page.
    Query strings are kept, because they routinely select which page it is.
    """
    if not url:
        return ""

    parts = urlsplit(url.strip())

    host = parts.netloc.lower()
    if host.startswith("www."):
        host = host[4:]

    return urlunsplit(
        (parts.scheme.lower() or "https", host, parts.path.rstrip("/"), parts.query, "")
    )


# A row boundary that has already been flattened: one line's trailing pipe
# followed by the next line's leading pipe, with only spaces between them.
JOINED_ROWS = re.compile(r"\|\s+\|")

# Enough cells to be a table rather than prose that happens to contain a pipe.
MIN_TABLE_PIPES = 6


def reflow_table(line: str) -> str:
    """Put a flattened markdown table back onto separate lines.

    Some pages arrive with the whole table already on one line, before we touch
    anything: the extractor joined it. Markdown needs one row per line, so
    without this the passage renders as a run of pipes, which is exactly the
    noise this was all meant to remove.

    A row boundary is recognisable because a row ends with a pipe and the next
    begins with one, so "| |" with nothing between is where a newline used to
    be. Left alone unless the line really looks like a table, and unless the
    split actually produces rows, so ordinary prose is never touched.
    """
    if line.count("|") < MIN_TABLE_PIPES or "---" not in line:
        return line

    rows = [row.strip().strip("|").strip() for row in JOINED_ROWS.split(line)]

    # Separator rows are rebuilt below, and the header they belonged to was
    # usually empty, which is why it flattened to nothing in the first place.
    data = [
        row for row in rows
        if row and set(row) - set("-: |")
    ]

    if len(data) < 2:
        return line

    # The separator declares how many columns a table has, and anything past
    # it is dropped by the renderer. The flattened separator is unreliable
    # here, so the width comes from the widest row that carries content.
    width = max(len(row.split("|")) for row in data)

    header = "| " + " | ".join([" "] * width) + " |"
    divider = "| " + " | ".join(["---"] * width) + " |"

    return "\n".join([header, divider, *(f"| {row} |" for row in data)])


def summarise(text: Optional[str], limit: int) -> Optional[str]:
    """Retrieved page text, tidied and trimmed, with its line structure intact.

    Line breaks are preserved deliberately. What comes back from a financials
    page is a markdown table, and every row of it sits on its own line; join
    those lines and the table becomes an unreadable run of pipe characters that
    no renderer can recover.

    Cuts on a line break where one is close enough to the limit, so a table ends
    on a whole row. Failing that, a sentence end, then a word boundary.
    """
    if not text:
        return None

    clean = BLANK_LINES.sub("\n\n", SPACES.sub(" ", text)).strip()
    if not clean:
        return None

    # Per line, because a passage is usually prose with one flattened table
    # buried in it rather than a table throughout.
    clean = "\n".join(reflow_table(line) for line in clean.split("\n"))
    if len(clean) <= limit:
        return clean

    cut = clean[:limit]

    # A whole row beats a tidy sentence: half a table row reads as corruption.
    line = cut.rfind("\n")
    if line >= limit - LINE_LOOKBACK:
        return cut[:line].rstrip()

    stop = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
    if stop >= limit - SENTENCE_LOOKBACK:
        return cut[: stop + 1]

    space = cut.rfind(" ")
    return f"{cut[:space] if space > 0 else cut}..."


class SourceRegistry:
    """Pages retrieved during one request, keyed by normalised URL."""

    def __init__(self, limit: Optional[int] = None) -> None:
        self._limit = limit or get_settings().source_summary_max_chars
        self._pages: dict[str, dict] = {}

    def record(self, hits: Optional[Iterable[dict]]) -> None:
        """Remember the title and text of every hit from one search."""
        for hit in hits or []:
            url = normalise(hit.get("url") or "")
            if not url:
                continue

            summary = summarise(hit.get("content"), self._limit)

            # The same page can come back from several queries, and providers
            # differ in how much text they return. Keep the fullest version, so
            # a thin later snippet cannot displace a richer earlier one.
            seen = self._pages.get(url)
            if seen and len(seen.get("summary") or "") >= len(summary or ""):
                continue

            self._pages[url] = {"title": hit.get("title") or None, "summary": summary}

    def record_many(self, results: Optional[dict[str, list[dict]]]) -> None:
        """Remember every hit from a `web_search_many` batch."""
        for hits in (results or {}).values():
            self.record(hits)

    def describe(self, url: str) -> Optional[dict]:
        """{title, summary} for a URL we retrieved, or None."""
        return self._pages.get(normalise(url))

    def enrich(self, sources: Optional[list]) -> list:
        """Add `title` and `summary` to each source entry, in place.

        Both keys are always set, so the caller can rely on them being present
        even when the join missed. A miss means the model cited a page we did
        not retrieve ourselves, and null is the honest answer there.

        Never overwrites a `name` or `title` that is already filled: on the
        single-prompt path those are the publisher the model reported, which is
        a better label than a page's HTML title.
        """
        for source in sources or []:
            page = self.describe(source.get("url") or "") or {}
            title = page.get("title")

            if title and not source.get("title"):
                source["title"] = title
            if title and not source.get("name"):
                source["name"] = title

            source.setdefault("title", None)
            source.setdefault("name", None)
            source["summary"] = page.get("summary")

        return sources or []

    def __len__(self) -> int:
        return len(self._pages)
