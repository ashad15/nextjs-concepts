"""Read access to the parquet snapshot written at ingestion.

Shared by the routers so the file is parsed once per process and the JSON
cleanup lives in one place.
"""

from functools import lru_cache
from typing import Any

import pandas as pd
from fastapi import HTTPException

from app.config import get_settings


@lru_cache
def load_companies() -> pd.DataFrame:
    """Read the parquet snapshot, cached for the process lifetime."""
    settings = get_settings()
    path = settings.data_dir / settings.parquet_file

    if not path.exists():
        raise HTTPException(
            status_code=503, detail=f"Company data not found: {path.name}"
        )

    return pd.read_parquet(path)


def records(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Rows as JSON-safe dicts: index exposed as cap_id, NaN turned into null.

    NaN has to go — json.dumps emits a bare `NaN` token, which is not valid JSON
    and trips up strict clients.
    """
    rows = frame.reset_index().rename(columns={"Cap_id": "cap_id"}).to_dict("records")
    return [
        {
            key: (None if isinstance(value, float) and pd.isna(value) else value)
            for key, value in row.items()
        }
        for row in rows
    ]
