"""Mock company rows shaped like app/data/peersdata.csv.

One company per call — the column, not the peer set:

    generate_company("Acme Bio")
    {'Ticker': 'ACME', 'Cap_id': 'IQ40183726', 'Name': 'Acme Bio (ACME)', ...}

Numbers are drawn from the range each metric occupies in the seed data, so they
are fake but the shape holds: margins stay negative, CAPEX stays negative, WACC
stays a small fraction. The string fields come from the model, because they
cannot be random — "google" has to come back as Communication Services, not
Healthcare.
"""

import json
import logging
import random
import sys
from typing import Optional

from app.services.openai import call_openai

logger = logging.getLogger(__name__)

# Fallback labels, for when the model is switched off or the call fails.
TEXT_DEFAULTS = {
    "SECTOR": "Healthcare",
    "INDUSTRY_GROUP": "Pharmaceuticals & Biotechnology",
    "INDUSTRY": "Pharma & Biotech Products",
}

TEXT_PROMPT = """Give the identifier fields for this company: {name}

Return only JSON, no markdown fence, with exactly these keys:

{{"Ticker": "...", "Name": "...", "SECTOR": "...",
 "INDUSTRY_GROUP": "...", "INDUSTRY": "..."}}

Name is the legal name with the ticker in round brackets, exactly like
"Zelluna ASA (ZLNA)". Match the taxonomy style of these examples, which is broad
sector, then group, then a narrower industry:

  Healthcare / Pharmaceuticals & Biotechnology / Pharma & Biotech Products
  Information Technology / Software & Services / Interactive Media & Services
  Consumer Discretionary / Consumer Durables & Apparel / Footwear

If the company is not one you recognise, invent plausible fields for the name
rather than refusing. Never return an explanation."""

# metric -> (low, high), from the min/max of the non-zero values in
# peersdata.csv. VALUE_CREATOR_YEARS is zero for every company there, so it
# stays zero here too.
RANGES = {
    "REVENUE": (0.25, 1203.0),
    "EBITDA_MARGIN": (-108.0, -10.0),
    "CAPEX": (-1.5, -0.95),
    "LTM_EPS": (-3.85, -0.41),
    "ADJUSTED_STOCK_PRICE": (2.64, 19.0),
    "COST_OF_EQUITY": (0.0823, 0.1141),
    "CAPITAL_EMPLOYED": (11.7, 103.0),
    "WACC": (0.0749, 0.1049),
    "MARKET_CAP": (86.0, 227.0),
    "VALUE_CREATOR_YEARS": (0.0, 0.0),
    "REVENUE_GROWTH_1YR": (-0.16, 8.14),
    "COGS": (0.14, 379.0),
    "DSO": (12.2, 101.0),
    "DPO": (141.0, 670.0),
    "CCC": (-527.0, 21.2),
    "EBIT_MARGIN": (-110.0, -10.2),
    "NET_DEBT_EBITDA_1YR": (0.97, 3.4),
    "FCF_SALES_2YR": (-97.8, -9.8),
    "FCF_SALES_3YR": (-35.8, -10.2),
    "ACCOUNTS_RECEIVABLE": (0.25, 40.2),
    "ACCOUNTS_PAYABLE": (0.7, 147.0),
    "ADJUSTED_EBITDA": (-32.3, -32.3),
    "GROSS_MARGIN": (0.44, 0.93),
    "TOTAL_REVENUE": (2.1, 5.3),
    "ADJUSTED_EBIT": (-208.0, 671.0),
    "ADJUSTED_EBIT_MARGIN": (-129.0, 0.56),
    "CCC_ADJ": (-527.0, 21.2),
    "ADJUSTED_EBITDA_MARGIN": (-129.0, -129.0),
    "ACTUAL_EPS": (-3.85, -0.41),
    "ADJUSTED_CCC": (-527.0, 21.2),
    "REVENUE_CAGR_1YR": (-0.16, 8.14),
}

# Parts for invented company names. Biotech-flavoured and European-listed, to
# match the sector labels in TEXT_DEFAULTS and the shape of the seed data.
NAME_STEMS = [
    "Alveron", "Bractis", "Cytovance", "Dermelia", "Elystra", "Ferrovita",
    "Genexis", "Halosyn", "Immunara", "Jadecell", "Kryonova", "Lumitera",
    "Mycelan", "Neuravax", "Onkoline", "Protevia", "Quantiva", "Rhealix",
    "Synaptor", "Tevanto", "Umbriel", "Verdantis", "Wexbio", "Xenolyte",
    "Ymirex", "Zephyra",
]
LEGAL_SUFFIXES = ["ASA", "SA", "NV", "Oyj", "AB", "AG", "plc", "Inc."]

# Columns that always hold the same value as another column in the seed data.
MIRRORS = {
    "ACTUAL_EPS": "LTM_EPS",
    "CCC_ADJ": "CCC",
    "ADJUSTED_CCC": "CCC",
    "REVENUE_CAGR_1YR": "REVENUE_GROWTH_1YR",
}


def default_text_fields(name: str) -> dict:
    """The string fields without the model: initials for a ticker, seed labels."""
    ticker = "".join(c for c in name.upper() if c.isalpha())[:4] or "MOCK"
    return {"Ticker": ticker, "Name": f"{name} ({ticker})", **TEXT_DEFAULTS}


def generate_text_fields(name: str) -> dict:
    """Ask the model for the ticker, legal name, and sector/industry labels.

    Falls back to the defaults if the call fails or comes back as something
    other than JSON — a mock row is not worth an exception.
    """
    fallback = default_text_fields(name)

    try:
        reply = call_openai(TEXT_PROMPT.format(name=name))
        # The model is asked for bare JSON, but a fence costs nothing to strip.
        fields = json.loads(reply.strip().strip("`").removeprefix("json").strip())
    except Exception as exc:
        logger.warning("Text fields for %r fell back to defaults: %s", name, exc)
        return fallback

    return {key: fields.get(key) or fallback[key] for key in fallback}


def generate_company(
    name: str,
    seed: Optional[int] = None,
    use_llm: bool = True,
    **overrides,
) -> dict:
    """Build one mock company row.

    `seed` makes the numbers reproducible, `use_llm=False` skips the model call,
    and anything in `overrides` is used verbatim:

        generate_company("Zelluna ASA", Ticker="ZLNA", REVENUE=0.0)
    """
    rng = random.Random(seed)
    text = generate_text_fields(name) if use_llm else default_text_fields(name)

    # Ticker, Cap_id, then the rest — peersdata.csv's row order.
    row = {
        "Ticker": text["Ticker"],
        "Cap_id": f"IQ{rng.randrange(10**7, 10**9)}",
        **text,
    }

    for metric, (low, high) in RANGES.items():
        row[metric] = round(rng.uniform(low, high), 6)
    for metric, source in MIRRORS.items():
        row[metric] = row[source]

    row.update(overrides)
    return row


def generate_companies(
    count: int,
    seed: Optional[int] = None,
    use_llm: bool = False,
) -> list[dict]:
    """`count` mock companies, every one with a distinct name, ticker and Cap_id.

    `use_llm` defaults to False here, unlike generate_company: a list of 50
    would otherwise be 50 model round-trips for text that is invented anyway.
    """
    combinations = [f"{stem} {suffix}" for stem in NAME_STEMS for suffix in LEGAL_SUFFIXES]
    if count > len(combinations):
        raise ValueError(f"Can only name {len(combinations)} companies, asked for {count}")

    rng = random.Random(seed)
    names = rng.sample(combinations, count)

    companies, tickers = [], set()
    for index, name in enumerate(names):
        # A per-row seed, so the numbers differ between companies but the whole
        # list still reproduces for a given `seed`.
        company = generate_company(name, seed=rng.randrange(10**9), use_llm=use_llm)

        # Two stems can share their first four letters, and a repeated ticker in
        # a peer list reads as a bug.
        ticker = company["Ticker"]
        while ticker in tickers:
            ticker = f"{company['Ticker'][:3]}{index}"
        tickers.add(ticker)
        company["Ticker"] = ticker
        company["Name"] = f"{name} ({ticker})"

        companies.append(company)

    return companies


if __name__ == "__main__":
    # Manual smoke test: python -m app.services.tools.mock_data_generator [name]
    logging.basicConfig(level=logging.INFO, format="%(levelname)s:     %(message)s")

    for key, value in generate_company(" ".join(sys.argv[1:]) or "microsoft").items():
        print(f"{key:<24} {value}")
