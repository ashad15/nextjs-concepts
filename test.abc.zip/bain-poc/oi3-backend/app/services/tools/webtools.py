"""Web search, over Exa first and Tavily second.

Both providers are normalised to the same hit shape — {url, title, content,
score} — so everything downstream (the prompt block, the agent's search tool)
is unchanged regardless of which one answered.
"""

import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from typing import Optional

import httpx
from tavily import TavilyClient

from app.config import get_settings
from app.services import upstream

logger = logging.getLogger(__name__)

EXA_SEARCH_URL = "https://api.exa.ai/search"


def get_client() -> TavilyClient:

    if not os.getenv("TAVILY_API_KEY"):
        raise ValueError("TAVILY_API_KEY is not set")
    return TavilyClient()


def _exa_key() -> Optional[str]:
    """The key, or None when it is absent or left blank in .env."""
    return (os.getenv("EXA_API_KEY") or "").strip() or None


def _exa_search(
    query: str,
    max_results: Optional[int],
    include_domains: Optional[list[str]] = None,
) -> list[dict]:
    """Exa's /search, mapped onto the shared hit shape.

    Called over REST rather than through exa-py: the SDK requires
    pydantic>=2.10.6 and this project pins 2.10.5, which is not a dependency
    bump worth making for a single POST.

    Note this is /search, not the agent runs API — the agent path calls this
    once per tool step and needs snippets back immediately, where an agent run
    is a long poll built for structured enrichment.
    """
    settings = get_settings()
    limit = max_results or settings.exa_max_results

    payload = {
        "query": query,
        "numResults": limit,
        "type": settings.exa_search_type,
        "contents": {
            "text": {
                "maxCharacters": settings.exa_text_max_characters
            }
        },
    }

    # Only sent when asked for. An empty list would restrict the search to
    # nothing at all, which is not the same as leaving it unrestricted.
    if include_domains:
        payload["includeDomains"] = list(include_domains)

    response = httpx.post(
        EXA_SEARCH_URL,
        headers={
            "x-api-key": _exa_key() or "",
            "content-type": "application/json",
        },
        json=payload,
        timeout=settings.exa_timeout_seconds,
    )
    response.raise_for_status()

    results = response.json().get("results", [])

    return [
        {
            "url": hit.get("url"),
            "title": hit.get("title") or hit.get("url"),
            "content": hit.get("text") or "",
            # Exa returns no relevance score for neural search, so this is
            # derived from rank rather than invented: results arrive best-first.
            "score": hit.get("score")
            if hit.get("score") is not None
            else round(1.0 - (index / max(len(results), 1)), 3),
        }
        for index, hit in enumerate(results)
        if hit.get("url")
    ]


def _tavily_search(
    query: str,
    max_results: Optional[int],
    search_depth: Optional[str],
    include_domains: Optional[list[str]] = None,
) -> list[dict]:
    """Tavily's search, mapped onto the shared hit shape."""
    settings = get_settings()

    response = get_client().search(
        query=query,
        max_results=max_results or settings.tavily_max_results,
        search_depth=search_depth or settings.tavily_search_depth,
        # Tavily calls it the same thing, so a tier restriction survives the
        # fallback instead of silently widening to the whole web.
        include_domains=list(include_domains) if include_domains else None,
        # No include_answer: a synthesised answer is a number we cannot
        # trace back to a page, which is exactly what we are avoiding.
        include_answer=False,
    )

    return [
        {
            "url": hit["url"],
            "title": hit["title"],
            "content": hit["content"],
            "score": hit["score"],
        }
        for hit in response.get("results", [])
    ]


def web_search(
    query: str,
    max_results: Optional[int] = None,
    search_depth: Optional[str] = None,
    include_domains: Optional[list[str]] = None,
    channel: str = "search",
) -> list[dict]:
    """Search the web. Returns [{url, title, content, score}, ...], best first.

    Exa answers first; Tavily takes over if it fails, so one provider being
    down is invisible to callers. Never raises: a failed search comes back as
    an empty list so one bad query can't take down a whole batch.

    `include_domains` restricts the search to those hosts, which is how the
    metric research tries a company's own filings before the open web.

    `channel` is which health budget this search counts against. It exists so a
    pass whose failure is survivable cannot mask one whose failure is not: the
    outage check reads one channel at a time, and searches that merely enrich an
    answer must not make a run look healthy when the searches the answer is
    actually built from have all failed.

    A failure is only recorded once *every* provider has failed, because a
    fallback that worked is not an outage. That record is what stops a run
    whose searches all failed from returning a confident, unsourced answer —
    see app.services.upstream.
    """
    started = time.monotonic()
    upstream.record_attempt(channel)

    providers = []
    if _exa_key():
        providers.append(("exa", lambda: _exa_search(query, max_results, include_domains)))
    providers.append(
        ("tavily", lambda: _tavily_search(query, max_results, search_depth, include_domains))
    )

    failures = []

    for name, run in providers:
        try:
            results = run()
        except Exception as exc:
            failure = upstream.classify_search(name, exc)
            failures.append(failure)
            logger.warning(
                "Search failed for %r via %s [%s]: %s",
                query,
                name,
                failure.reason,
                exc,
            )
            continue

        if failures:
            logger.warning(
                "Search for %r fell back to %s after %s failed",
                query,
                name,
                ", ".join(f.service for f in failures),
            )

        logger.info(
            "Search %r -> %d hits via %s in %.2fs",
            query,
            len(results),
            name,
            time.monotonic() - started,
        )
        return results

    # Every provider failed. Report the one an operator can act on, but carry
    # every provider's reason in the detail so the 502 says what to fix.
    chosen = next((f for f in failures if f.fatal), failures[0])
    upstream.record(
        channel,
        replace(
            chosen,
            detail="; ".join(f"{f.service}: {f.detail}" for f in failures),
        ),
    )
    return []


def web_search_many(queries: list[str], **kwargs) -> dict[str, list[dict]]:
    """Run several searches at once. Returns {query: results}."""
    settings = get_settings()

    if not queries:
        return {}

    started = time.monotonic()
    workers = min(len(queries), settings.tavily_max_workers)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(lambda q: web_search(q, **kwargs), queries))

    logger.info("%d searches in %.2fs", len(queries), time.monotonic() - started)
    return dict(zip(queries, results))


def format_results(results: dict[str, list[dict]], max_chars: int = 1500) -> str:
    """Flatten search results into the text block we paste into the prompt.

    Every snippet stays glued to its own URL, so there is always something
    concrete for the model to cite.
    """
    blocks = []

    for query, hits in results.items():
        blocks.append(f"### SEARCH: {query}")
        if not hits:
            blocks.append("(no results)")
        for hit in hits:
            blocks.append(f"SOURCE_URL: {hit['url']}")
            blocks.append(f"TITLE: {hit['title']}")
            blocks.append(f"CONTENT: {hit['content'][:max_chars]}")
            blocks.append("")

    return "\n".join(blocks)


if __name__ == "__main__":
    # Manual smoke test: python -m app.services.tools.webtools
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    hits = web_search_many(
        [
            "Nkarta NKTX market cap revenue",
            "Century Therapeutics IPSC market cap revenue",
            "Artiva Biotherapeutics ARTV market cap revenue",
        ]
    )

    for query, results in hits.items():
        print(f"\n{query} -> {len(results)} hits")
        for hit in results[:2]:
            print(f"  {hit['score']:.2f}  {hit['url']}")

    text = format_results(hits)
    print(f"\nprompt block: {len(text)} chars")
    print(text)
