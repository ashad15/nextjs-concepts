"""Upstream health tracking, so a dead dependency is never silent.

The problem this solves: `web_search` returns [] on any error, by design, so one
bad query cannot take down a batch. But when Tavily is down or out of credit,
*every* query returns [], the prompt carries no research, and the model answers
from memory. The response then looks entirely normal — peers, scores, rationale
— with no sources behind it. In front of an audience that is worse than an
error, because nothing on screen says the numbers are unsourced.

Searches record what happened instead of raising, because the LangGraph ToolNode
catches tool exceptions and hands them back to the model, so raising inside a
search does not reliably stop the run. The router checks health once the run
finishes and fails loudly, naming the service.

The log is global rather than per-request. Searches run across a thread pool and
contextvars do not cross that boundary, and the condition being detected —
"Tavily is failing right now" — is true for every request at once, so attributing
an event to one request buys nothing.
"""

import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class UpstreamFailure:
    """One failed call to a third-party service."""

    service: str  # "tavily" | "openai"
    reason: str  # missing_key | bad_key | quota | rate_limit | timeout | error
    detail: str

    @property
    def fatal(self) -> bool:
        """Account-level problems: retrying or ignoring these will not help."""
        return self.reason in {"missing_key", "bad_key", "quota"}

    @property
    def hint(self) -> str:
        """What the operator should actually do about it."""
        key = f"{self.service.upper()}_API_KEY"
        return {
            "missing_key": f"Set {key} in .env and restart the API.",
            "bad_key": f"{key} was rejected. Replace it in .env and restart the API.",
            "quota": f"The {self.service} account is out of credit. Swap in a funded "
            f"key and restart, or re-run a combination that is already cached.",
            "rate_limit": f"{self.service} is rate limiting. Wait a moment and retry.",
            "timeout": f"{self.service} did not respond in time. Retry.",
        }.get(self.reason, f"{self.service} call failed. Check the server log.")


class UpstreamError(Exception):
    """Raised at the request boundary when a dependency invalidated the run."""

    def __init__(self, failure: UpstreamFailure, summary: str):
        self.failure = failure
        self.summary = summary
        super().__init__(f"{failure.service}: {summary}")


_lock = threading.Lock()

# (timestamp, service, failure or None). None means the call succeeded.
_events: deque = deque(maxlen=500)


def now() -> float:
    """Mark the start of a request, to scope the health check to it."""
    return time.monotonic()


def record_attempt(channel: str) -> None:
    """One logical call on `channel`, whichever provider ends up serving it."""
    with _lock:
        _events.append((time.monotonic(), channel, None))


def record(channel: str, failure: UpstreamFailure) -> None:
    """A call on `channel` that no provider could serve.

    The channel groups the attempt with its failure; failure.service still
    names the specific provider, so the hint stays actionable.
    """
    with _lock:
        _events.append((time.monotonic(), channel, failure))


def _since(started: float, channel: str) -> tuple[int, list]:
    """(attempts, failures) for one channel since `started`.

    Attempts are the None entries only. Counting every event as an attempt
    would double-count a failed call, so attempts could never equal failures
    and a total outage would go undetected.
    """
    with _lock:
        events = [e for e in _events if e[0] >= started and e[1] == channel]

    attempts = sum(1 for e in events if e[2] is None)
    failures = [e[2] for e in events if e[2] is not None]

    return attempts, failures


def check_search_health(started: float) -> None:
    """Fail the request if the searches behind it did not actually happen.

    Two cases, both of which would otherwise return a normal-looking answer
    built with no research at all:

    - a fatal failure (bad key, no key, spent quota)
    - every single search failing, which is what a full outage looks like

    Only counts searches that no provider could serve: Exa failing while
    Tavily answers is a working search, not an outage.
    """
    attempts, failures = _since(started, "search")

    if not attempts:
        return

    fatal = next((f for f in failures if f.fatal), None)
    if fatal:
        raise UpstreamError(
            fatal,
            f"{len(failures)} of {attempts} web searches failed: {fatal.detail}",
        )

    if len(failures) == attempts:
        raise UpstreamError(
            failures[0],
            f"all {attempts} web searches failed, so the answer would carry no "
            f"sources: {failures[0].detail}",
        )


def classify_tavily(exc: Exception) -> UpstreamFailure:
    """Map a Tavily SDK exception onto a reason."""
    from tavily import errors

    reason = "error"
    if isinstance(exc, errors.MissingAPIKeyError):
        reason = "missing_key"
    elif isinstance(exc, (errors.InvalidAPIKeyError, errors.ForbiddenError)):
        reason = "bad_key"
    elif isinstance(
        exc, (errors.UsageLimitExceededError, errors.TavilyKeylessLimitError)
    ):
        reason = "quota"
    elif isinstance(exc, errors.TimeoutError):
        reason = "timeout"

    return UpstreamFailure("tavily", reason, str(exc) or type(exc).__name__)


def classify_exa(exc: Exception) -> UpstreamFailure:
    """Map an Exa REST failure onto a reason, by HTTP status."""
    import httpx

    reason = "error"
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        reason = {
            401: "bad_key",
            403: "bad_key",
            402: "quota",
            429: "rate_limit",
        }.get(code, "error")
        detail = f"HTTP {code}: {exc.response.text[:200]}"
    elif isinstance(exc, httpx.TimeoutException):
        reason, detail = "timeout", str(exc) or "request timed out"
    elif isinstance(exc, httpx.TransportError):
        reason, detail = "timeout", str(exc) or "could not connect"
    else:
        detail = str(exc) or type(exc).__name__

    return UpstreamFailure("exa", reason, detail)


def classify_search(provider: str, exc: Exception) -> UpstreamFailure:
    """Classify a failure from whichever search provider raised it."""
    return classify_exa(exc) if provider == "exa" else classify_tavily(exc)


def classify(exc: Exception) -> Optional[UpstreamFailure]:
    """Identify a third-party failure, or None if this is our own bug.

    LangChain lets the underlying openai.* exceptions through, so the agent
    path and the single-prompt path classify identically.
    """
    import openai

    if isinstance(exc, openai.OpenAIError):
        reason = "error"
        if isinstance(exc, (openai.AuthenticationError, openai.PermissionDeniedError)):
            reason = "bad_key"
        elif isinstance(exc, openai.RateLimitError):
            # One exception class covers throttling and a spent balance; only
            # the message says which, and they need different fixes.
            reason = "quota" if "quota" in str(exc).lower() else "rate_limit"
        elif isinstance(exc, (openai.APITimeoutError, openai.APIConnectionError)):
            reason = "timeout"

        return UpstreamFailure("openai", reason, str(exc) or type(exc).__name__)

    module = type(exc).__module__ or ""
    if module.startswith("tavily"):
        return classify_tavily(exc)

    if isinstance(exc, ValueError) and "API_KEY" in str(exc):
        service = "openai" if "OPENAI" in str(exc) else "tavily"
        return UpstreamFailure(service, "missing_key", str(exc))

    return None
