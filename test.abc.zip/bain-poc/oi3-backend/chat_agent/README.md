# OI Chat Agent

The assistant behind the Chat tab. A LangGraph agent served over AG-UI, answering questions about one peer analysis and operating the setup form on the user's behalf.

## Why this is a separate service with its own venv

`ag-ui-langgraph` requires langgraph 1.x, langchain-core 1.x and pydantic 2.13. The main API is pinned to langgraph 0.6.11, langchain-openai 0.3.35 and pydantic 2.10.5, and `langchain-openai 0.3.x` cannot sit alongside langchain-core 1.x at all. Installing the agent into the shared venv means upgrading all of it, and the code that would land on is `agents/search_peers.py` and `app/schemas.py`, which is the working peer pipeline. Two venvs is the cheaper of the two costs. `copilotkit` also requires fastapi >= 0.141 against the main API's 0.115.6, which is the same problem again.

## Running it

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python main.py            # :8123
```

`OPENAI_API_KEY` is read from `../.env`, the same file the main API uses. The model is `openai:gpt-5.2` by default, overridable with `OI3_CHAT_MODEL`.

From the repo root, `./start-dev.sh` starts this alongside the other three processes.

## How it fits together

```
browser  ->  Vite :5173  ->  CopilotKit runtime :4000  ->  this agent :8123
                (proxy)          (Node, thread state)        (LangGraph, AG-UI/SSE)
```

The runtime is a real hop, not a proxy: it holds thread state across turns, collects the frontend's tool declarations, and keeps the model key off the browser. Transport is SSE throughout. CopilotKit only offers WebSockets through its managed Intelligence service, which is a hosted dependency; SSE streams token by token just the same.

## State, and why the agent does not hold the data itself

The frontend owns the analysis and pushes it into agent state on every run: the full recommendation, the activity log, which screen is open, and what the setup form holds. The agent reads none of it directly.

That matters because a recommendation is around 200KB, roughly 100KB of ranked peers and 90KB of retrieved page text. Putting it in the prompt would cost tens of thousands of tokens per turn to tell the model things it mostly does not need. Instead the prompt carries a ~1KB outline (`slices.run_overview`) and the model calls a tool for the slice it wants.

Mirroring the browser rather than re-reading the cache server-side is deliberate too: the browser is what the user is looking at, so the assistant cannot end up describing a different run from the one on screen.

## Files

| File | What it holds |
| --- | --- |
| `main.py` | FastAPI app, mounts the AG-UI endpoint at `/` |
| `agent.py` | State schema, the ten tools, the compiled graph |
| `slices.py` | Pure functions cutting the recommendation into prompt-sized pieces |
| `prompts.py` | The standing brief, plus per-screen notes |

`slices.py` deliberately imports nothing from langchain, so it can be tested without a model or a graph.

## Tools

Ten, all reading from state, all returning data rather than prose:

`list_peers`, `get_peer_detail`, `explain_comparability`, `compare_peers`, `list_excluded`, `get_target`, `list_sources`, `read_source`, `get_activity_log`, `list_companies`.

`explain_comparability` is the one behind "how was the radar chart built": it returns each spoke's score, the band it falls in, and the evidence sentence and source URL behind it.

Frontend tools arrive per-run in `state["tools"]` and are bound by `CopilotKitMiddleware`. Those are declared in the browser (`src/copilot/useWorkflowTools.tsx`) and execute there.

## Two things worth knowing before changing this

**Use `ag_ui_langgraph.LangGraphAgent`, not `copilotkit.LangGraphAGUIAgent`.** The endpoint clones the agent per request and passes `enable_legacy_on_interrupt_event`, which copilotkit 0.1.95's subclass does not accept. Every run 500s on the clone.

**Keep `workers=1`.** The shared `.env` sets `WEB_CONCURRENCY=2` for the main API and uvicorn reads that variable by itself. Threads live in process memory, so a second worker would answer half the turns with no memory of the conversation.
