"""The OI chat agent: a LangGraph agent that answers over one analysis run.

The whole recommendation (roughly 200KB) is carried in the agent's state, put
there by the frontend, which already holds it because it is drawing it. None of
it goes into the prompt. The model gets an outline and a set of tools, and pulls
the slice it needs per question — which is what keeps a conversation about a
seven-peer run from costing fifty thousand tokens a turn.

Two kinds of tool are in play:

- The ones defined here run in this process and read state. They answer
  questions about the run.
- The frontend's own tools (selecting a company, ticking criteria, submitting)
  are declared in the browser and arrive per-run in `state["tools"]`.
  CopilotKitMiddleware binds them to the model and routes a call to one of them
  back to the browser instead of executing it here.
"""

import logging
import os
from typing import Annotated, Any, NotRequired, Optional

from copilotkit import CopilotKitMiddleware
from langchain.agents import create_agent
from langchain.agents.middleware import AgentState, dynamic_prompt
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.prebuilt import InjectedState

import slices
from prompts import build_system_prompt

logger = logging.getLogger(__name__)

MODEL = os.environ.get("OI3_CHAT_MODEL", "openai:gpt-5.2")


class OIAgentState(AgentState):
    """What the agent knows, beyond the conversation itself.

    Every field is written by the frontend and none by the agent. The browser is
    the source of truth for all of it: it made the recommendation call, it owns
    the activity log, and it knows which screen is open. Mirroring that here
    rather than re-fetching it server-side means the agent can never answer about
    a different run from the one on screen.
    """

    # The full peer recommendation, in the camelCase shape services/peerApi.ts
    # produces. None until an analysis has actually been run.
    recommendation: NotRequired[Optional[dict]]

    # The Log tab, oldest first.
    activityLog: NotRequired[list[dict]]

    # Which screen is open, and what is in focus on it.
    page: NotRequired[dict]

    # The setup form: chosen target, peer set breadth, ticked criteria.
    setup: NotRequired[dict]

    # The selectable company universe, for resolving an @ mention to a cap id.
    companies: NotRequired[list[dict]]

    # Frontend tool declarations, written per-run by ag_ui_langgraph.
    tools: NotRequired[list[dict]]


def _recommendation(state: dict) -> Optional[dict]:
    return state.get("recommendation")


NO_RUN = (
    "No analysis has been run yet, so there is no peer set to report on. "
    "Tell the user this and offer to help set one up."
)


# ---------------------------------------------------------------------------
# Tools over the run
#
# Each returns plain data, never prose. Wording is the model's job; these decide
# what is true. Every one of them tolerates a missing recommendation, because a
# user can open the chat before running anything and the model should be told
# that in words rather than hitting an exception.
# ---------------------------------------------------------------------------


@tool
def list_peers(state: Annotated[dict, InjectedState]) -> Any:
    """List every proposed peer with its score, confidence and which route proposed it.

    The roster, one line per peer. Start here for "who is in the set", "how many
    peers", or any question that spans the whole set. For the detail behind one
    peer, follow up with get_peer_detail.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    return {
        "peers": slices.peer_summaries(recommendation),
        "counts": slices.run_overview(recommendation)["counts"],
    }


@tool
def get_peer_detail(company: str, state: Annotated[dict, InjectedState]) -> Any:
    """Everything held on one peer: scores, figures and how each was arrived at, reasons, concerns, filings.

    Args:
        company: Company name or ticker. A partial name is fine.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    detail = slices.peer_detail(recommendation, company)

    if detail is None:
        return _not_found(recommendation, company)

    return detail


@tool
def explain_comparability(company: str, state: Annotated[dict, InjectedState]) -> Any:
    """The comparability scores behind one peer and the evidence for each, criterion by criterion.

    This is what the radar plot on the peer screen is drawn from. Use it for any
    question about the radar, the spider chart, the shape, why a peer scored the
    way it did on a factor, or what evidence sits behind a score.

    Args:
        company: Company name or ticker. A partial name is fine.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    breakdown = slices.criteria_breakdown(recommendation, company)

    if breakdown is None:
        return _not_found(recommendation, company)

    return breakdown


@tool
def compare_peers(companies: list[str], state: Annotated[dict, InjectedState]) -> Any:
    """Two or more peers side by side, as rows ready to lay out as a table.

    Returns aligned rows across the union of the criteria and figures the named
    peers carry, with a null wherever one of them lacks a value. Use this rather
    than calling get_peer_detail repeatedly when the user wants a comparison.

    Args:
        companies: Company names or tickers, two or more.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    return slices.comparison_table(recommendation, companies)


@tool
def list_excluded(state: Annotated[dict, InjectedState]) -> Any:
    """The candidates that were assessed and turned down, each with the stated reason.

    Use this for "why isn't X in the set", "what did you reject", or any question
    about a company the user expected to see and does not.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    return {"excluded": slices.excluded_candidates(recommendation)}


@tool
def get_target(state: Annotated[dict, InjectedState]) -> Any:
    """The target company's own figures, which every peer was compared against."""
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    return slices.target_figures(recommendation)


@tool
def list_sources(
    state: Annotated[dict, InjectedState], company: Optional[str] = None
) -> Any:
    """The pages read during the run and what each one backed.

    Args:
        company: Optional. Narrow to the pages read for one peer. Omit for the
            whole run.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    return {"sources": slices.sources_for(recommendation, company)}


@tool
def read_source(url: str, state: Annotated[dict, InjectedState]) -> Any:
    """The retrieved text of one page, for quoting or checking a specific claim.

    Call list_sources first to get the URL. Only use this when a claim genuinely
    has to be quoted or verified against the page text; the summaries are long.

    Args:
        url: The page URL, exactly as list_sources reported it.
    """
    recommendation = _recommendation(state)

    if not recommendation:
        return NO_RUN

    text = slices.source_text(recommendation, url)

    if text is None:
        return f"No page with that URL was read during this run: {url}"

    return text


@tool
def get_activity_log(state: Annotated[dict, InjectedState]) -> Any:
    """What has happened in this analysis so far, as shown in the Log tab.

    Each entry says who acted: the user, the system, or the agent. Use this for
    "what have I done", "what happened", or to check whether a step already ran.
    """
    entries = state.get("activityLog") or []

    if not entries:
        return "The activity log is empty."

    return {"entries": entries}


@tool
def list_companies(state: Annotated[dict, InjectedState]) -> Any:
    """The companies the user can pick as a target, with their identifiers.

    Use this to resolve a name the user typed, including an @ mention, to the
    exact company before selecting it. Never guess a cap id.
    """
    companies = state.get("companies") or []

    if not companies:
        return "The company list has not been loaded."

    return {"companies": companies}


def _not_found(recommendation: dict, query: str) -> str:
    """Say what is actually in the set, so the model can correct itself in one step.

    Returning a bare "not found" invites a second guess at the same wrong name.
    Listing the roster ends it.
    """
    names = [
        f"{peer.get('companyName')} ({peer.get('ticker')})"
        for peer in recommendation.get("rankedPeers") or []
    ]

    excluded = [item.get("companyName") for item in recommendation.get("excluded") or []]

    message = f"No peer named '{query}' is in this set. The peers are: {', '.join(names)}."

    if excluded:
        message += (
            f" These were assessed and turned down: {', '.join(str(e) for e in excluded)}"
            " — use list_excluded for the reasons."
        )

    return message


TOOLS = [
    list_peers,
    get_peer_detail,
    explain_comparability,
    compare_peers,
    list_excluded,
    get_target,
    list_sources,
    read_source,
    get_activity_log,
    list_companies,
]


@dynamic_prompt
def system_prompt(request) -> str:
    """Rebuild the brief each turn, so it tracks the screen the user is on.

    A static prompt would pin the agent to whichever page was open when the
    thread started, and this app moves the user from setup to peers mid
    conversation.
    """
    state = request.state

    return build_system_prompt(
        recommendation=state.get("recommendation"),
        page=state.get("page"),
        setup=state.get("setup"),
    )


# MemorySaver is the right checkpointer here and not a placeholder: threads are
# scoped to one analysis, the analysis is scoped to one browser session, and the
# frontend re-sends the state it owns on every run. There is nothing to recover
# from disk that the browser would not send again.
graph = create_agent(
    model=MODEL,
    tools=TOOLS,
    middleware=[system_prompt, CopilotKitMiddleware()],
    state_schema=OIAgentState,
    checkpointer=MemorySaver(),
)
