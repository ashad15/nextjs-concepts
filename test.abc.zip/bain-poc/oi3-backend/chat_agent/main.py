"""Serves the OI chat agent over AG-UI.

Its own process, on its own port, with its own venv. See requirements.txt for
why it is not mounted on the main API: the dependency sets are incompatible, and
the peer pipeline is the thing that would break.

The Node CopilotKit runtime is what talks to this, not the browser. That keeps
the model key on this side of the wire.
"""

import logging
import os
from pathlib import Path

# LangGraphAgent, not copilotkit's LangGraphAGUIAgent subclass. The endpoint
# clones the agent per request and passes enable_legacy_on_interrupt_event,
# which copilotkit 0.1.95's subclass __init__ does not accept — every run 500s
# on the clone. The base class is what the clone contract is written against.
from ag_ui_langgraph import LangGraphAgent, add_langgraph_fastapi_endpoint
from dotenv import load_dotenv
from fastapi import FastAPI

# The main backend's .env holds OPENAI_API_KEY, and there is no reason for this
# service to keep a second copy of it.
load_dotenv(Path(__file__).parent.parent / ".env")

from agent import MODEL, graph  # noqa: E402  (must follow load_dotenv)

logging.basicConfig(
    level=logging.DEBUG if os.environ.get("OI3_DEBUG") == "true" else logging.INFO,
    format="%(levelname)s:     %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(title="OI 3.0 Chat Agent", version="1.0.0")

add_langgraph_fastapi_endpoint(
    app=app,
    agent=LangGraphAgent(
        name="oi_assistant",
        description=(
            "Answers questions about an Opportunity Indicator peer analysis and "
            "operates the setup form on the user's behalf."
        ),
        graph=graph,
    ),
    path="/",
)


# No /health here: add_langgraph_fastapi_endpoint registers one already, and a
# second would be shadowed by it rather than override it.


@app.get("/agent-info")
def agent_info() -> dict:
    return {"agent": "oi_assistant", "model": MODEL}


if __name__ == "__main__":
    import uvicorn

    # Single worker, stated explicitly. The shared .env sets WEB_CONCURRENCY=2
    # for the main API, and uvicorn reads that variable on its own — which makes
    # it try to fork, which it cannot do from an app object. It also should not
    # fork here: threads live in the process (MemorySaver), so a second worker
    # would answer half the turns with no memory of the conversation.
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=int(os.environ.get("OI3_CHAT_AGENT_PORT", "8123")),
        workers=1,
    )
