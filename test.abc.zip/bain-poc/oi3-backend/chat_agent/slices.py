"""Slices of a peer recommendation, sized for a model prompt.

The whole recommendation is roughly 200KB — about 100KB of ranked peers and
another 90KB of retrieved page text. It lives in the agent's state so nothing
has to be fetched mid-conversation, but none of it belongs in a prompt: the
model asks for the part it needs and gets that part back.

Every function here takes the recommendation as the frontend holds it, which is
the camelCase shape produced by services/peerApi.ts, not the snake_case the API
returns. That is deliberate. The frontend already did the translation once, and
re-deriving it here would give us a second definition of the same contract that
could drift from the first.

Pure dict-in/dict-out, so they can be tested without a model or a graph.
"""

from typing import Any, Optional

# Criterion keys as the response carries them, paired with the words a consultant
# would actually use. The radar plot on the peer page is drawn from exactly these
# five, so "how was the radar built" is answered by walking this list.
CRITERION_LABELS: dict[str, str] = {
    "businessModel": "Business model",
    "revenueScale": "Revenue scale",
    "regionalExposure": "Regional exposure",
    "endMarket": "End market & customers",
    "productMix": "Product mix",
    "growthProfile": "Growth profile",
    "custom1": "Custom criterion",
}

# What a 0-100 comparability score means, in the same bands the peer engine
# scored against (agents/search_peers.py, SCORE_BANDS). Repeated here so the
# chat agent describes a 72 the same way the pipeline that produced it does.
SCORE_BANDS: tuple[tuple[int, str], ...] = (
    (90, "near-identical on this factor"),
    (70, "close match, differences are minor"),
    (40, "partial match, differences are material"),
    (10, "weak match, comparable only loosely"),
    (0, "not comparable on this factor"),
)


def band(score: Optional[float]) -> str:
    """Plain words for a 0-100 comparability score."""
    if score is None:
        return "not scored"
    for floor, wording in SCORE_BANDS:
        if score >= floor:
            return wording
    return "not comparable on this factor"


def _norm(text: Optional[str]) -> str:
    return (text or "").strip().lower()


def find_peer(recommendation: dict, query: str) -> Optional[dict]:
    """One ranked peer, matched on name, ticker or cap id.

    Substring matching on the name as a last resort, because the model will say
    "Zelluna" for a row that calls itself "Zelluna ASA", and refusing that would
    push it into a retry loop for no gain.
    """
    peers = recommendation.get("rankedPeers") or []
    wanted = _norm(query)

    if not wanted:
        return None

    for peer in peers:
        if wanted in {
            _norm(peer.get("companyName")),
            _norm(peer.get("ticker")),
            _norm(peer.get("capId")),
        }:
            return peer

    for peer in peers:
        if wanted in _norm(peer.get("companyName")):
            return peer

    return None


def peer_summaries(recommendation: dict) -> list[dict]:
    """Every ranked peer in one line each — the roster, not the detail."""
    summaries = []

    for peer in recommendation.get("rankedPeers") or []:
        confidence = peer.get("confidence") or {}
        reasons = peer.get("reasons") or []

        summaries.append(
            {
                "rank": peer.get("rank"),
                "company": peer.get("companyName"),
                "ticker": peer.get("ticker"),
                "score": peer.get("finalScore"),
                "confidence": confidence.get("score"),
                # "vcc" is our own internal peer list, "agent"/"model" came out
                # of the research run. Which side proposed a peer is usually the
                # first thing asked about it, so it travels with the summary.
                "proposedBy": peer.get("recommendedBy"),
                "inBothLists": peer.get("inBoth"),
                "headlineReason": reasons[0] if reasons else None,
                "concernCount": len(peer.get("concerns") or []),
            }
        )

    return summaries


def criteria_breakdown(recommendation: dict, query: str) -> Optional[dict]:
    """The comparability scores behind one peer, with the evidence for each.

    This is what the radar plot on the peer page is drawn from. The plot shows
    the shape; this returns the numbers, the band each one falls in, and the
    sentence off a retrieved page that justified it. A peer matched from our own
    internal list carries scores but usually no evidence, and saying so is part
    of the answer rather than a gap to paper over.
    """
    peer = find_peer(recommendation, query)

    if peer is None:
        return None

    # Evidence is recorded per source, keyed by the snake_case criterion name the
    # scoring prompt used, while the scores themselves arrive camelCased by the
    # frontend transform. Fold the sources first, then match on a normalised key
    # so "end_market_customers" and "endMarket" land together.
    evidence_by_criterion: dict[str, list[dict]] = {}

    for source in peer.get("sources") or []:
        for item in source.get("evidence") or []:
            key = _criterion_key(item.get("criterion"))
            evidence_by_criterion.setdefault(key, []).append(
                {
                    "evidence": item.get("evidence"),
                    "score": item.get("score"),
                    "source": source.get("name") or source.get("title"),
                    "url": source.get("url"),
                }
            )

    axes = []

    for field, label in CRITERION_LABELS.items():
        score = (peer.get("selectionCriteria") or {}).get(field)

        if score is None:
            continue

        axes.append(
            {
                "criterion": label,
                "score": score,
                "meaning": band(score),
                "evidence": evidence_by_criterion.get(_criterion_key(label), []),
            }
        )

    scored = [axis["score"] for axis in axes]

    return {
        "company": peer.get("companyName"),
        "ticker": peer.get("ticker"),
        "overallScore": peer.get("finalScore"),
        "axes": axes,
        # The peer page buckets the mean into High/Medium/Lower beside the plot,
        # so the mean is reported rather than left for the model to average and
        # possibly get wrong.
        "meanScore": round(sum(scored) / len(scored), 1) if scored else None,
        "reasons": peer.get("reasons") or [],
        "concerns": peer.get("concerns") or [],
        "confidence": peer.get("confidence"),
        "proposedBy": peer.get("recommendedBy"),
        "evidenceAvailable": bool(evidence_by_criterion),
    }


def _criterion_key(name: Optional[str]) -> str:
    """Fold "End market & customers", "end_market_customers" and "endMarket".

    Everything non-alphanumeric goes, and the result is lowercased, so the three
    spellings of one criterion collapse to the same key. Without this the
    evidence list and the score list never join and every axis looks unsourced.
    """
    if not name:
        return ""

    folded = "".join(char for char in name if char.isalnum()).lower()

    # "endmarketcustomers" and "endmarket" are the same axis under two names.
    aliases = {
        "endmarketcustomers": "endmarket",
        "custom1": "customcriterion",
    }

    return aliases.get(folded, folded)


def peer_detail(recommendation: dict, query: str) -> Optional[dict]:
    """Everything held on one peer: scores, figures, reasons, sources, filings."""
    peer = find_peer(recommendation, query)

    if peer is None:
        return None

    return {
        "rank": peer.get("rank"),
        "company": peer.get("companyName"),
        "ticker": peer.get("ticker"),
        "capId": peer.get("capId"),
        "score": peer.get("finalScore"),
        "proposedBy": peer.get("recommendedBy"),
        "inBothLists": peer.get("inBoth"),
        "reasons": peer.get("reasons") or [],
        "concerns": peer.get("concerns") or [],
        "confidence": peer.get("confidence"),
        "keyMetrics": peer.get("keyMetrics") or [],
        "researchedFigures": _figures(peer.get("metrics") or {}),
        "criteria": [
            {
                "criterion": CRITERION_LABELS[field],
                "score": score,
                "meaning": band(score),
            }
            for field, score in (peer.get("selectionCriteria") or {}).items()
            if score is not None and field in CRITERION_LABELS
        ],
        "sourceCount": len(peer.get("sources") or []),
        "filings": [
            {"title": doc.get("title"), "publisher": doc.get("publisher"), "url": doc.get("url")}
            for doc in (peer.get("documents") or [])
        ],
    }


def _figures(metrics: dict) -> list[dict]:
    """Researched figures, each carrying how it was arrived at.

    Origin is the whole point of this view. A sourced figure can be checked
    against its page, a computed one against its formula, and a modelled one is
    an assumption wearing a number's clothes — the audit panel already draws
    that distinction and an answer in chat must not blur it.
    """
    figures = []

    for name, metric in metrics.items():
        if not metric or metric.get("value") is None:
            continue

        figures.append(
            {
                "metric": name,
                "value": metric.get("value"),
                "unit": metric.get("unit"),
                "period": metric.get("period"),
                "origin": metric.get("origin"),
                "sourceName": metric.get("sourceName"),
                "sourceUrl": metric.get("sourceUrl"),
                "formula": metric.get("formula"),
                "method": metric.get("method"),
            }
        )

    return figures


def comparison_table(recommendation: dict, queries: list[str]) -> dict:
    """Two or more peers side by side, as rows ready to be laid out as a table.

    Returns the union of the criteria and figures present on the peers asked
    for, with a null wherever one of them lacks a value, so the caller never has
    to reason about ragged rows.
    """
    peers = []
    missing = []

    for query in queries:
        peer = find_peer(recommendation, query)
        if peer is None:
            missing.append(query)
        else:
            peers.append(peer)

    if not peers:
        return {"columns": [], "criteriaRows": [], "figureRows": [], "notFound": missing}

    columns = [
        {
            "company": peer.get("companyName"),
            "ticker": peer.get("ticker"),
            "rank": peer.get("rank"),
            "score": peer.get("finalScore"),
            "proposedBy": peer.get("recommendedBy"),
        }
        for peer in peers
    ]

    criteria_rows = []

    for field, label in CRITERION_LABELS.items():
        values = [(peer.get("selectionCriteria") or {}).get(field) for peer in peers]

        if all(value is None for value in values):
            continue

        criteria_rows.append({"criterion": label, "values": values})

    # Key metrics arrive pre-formatted for display ("$61.8M"), which is what a
    # table wants. Keyed on the label so peers that carry different metric sets
    # still line up row by row.
    metric_labels: list[str] = []

    for peer in peers:
        for metric in peer.get("keyMetrics") or []:
            label = metric.get("label")
            if label and label not in metric_labels:
                metric_labels.append(label)

    figure_rows = []

    for label in metric_labels:
        values = []

        for peer in peers:
            match = next(
                (m for m in (peer.get("keyMetrics") or []) if m.get("label") == label),
                None,
            )
            values.append(match.get("value") if match else None)

        figure_rows.append({"metric": label, "values": values})

    return {
        "columns": columns,
        "criteriaRows": criteria_rows,
        "figureRows": figure_rows,
        "notFound": missing,
    }


def excluded_candidates(recommendation: dict) -> list[dict]:
    """Candidates the rerank assessed and turned down, with the stated reason."""
    return [
        {
            "company": item.get("companyName"),
            "ticker": item.get("ticker"),
            "score": item.get("finalScore"),
            "whyExcluded": item.get("whyExcluded"),
        }
        for item in recommendation.get("excluded") or []
    ]


def run_overview(recommendation: dict) -> dict:
    """The shape of the run: target, best peer, counts, how much was read.

    Cheap enough to put in the system prompt, which is why it is separated from
    everything else here. It gives the model enough to answer "what happened"
    and enough to know which tool to reach for next.
    """
    target = recommendation.get("target") or {}
    best = recommendation.get("bestPeer") or {}
    counts = recommendation.get("counts") or {}
    sources = recommendation.get("sources") or []
    peers = recommendation.get("rankedPeers") or []

    figures_read = sum(
        1
        for peer in peers
        for metric in (peer.get("metrics") or {}).values()
        if metric and metric.get("value") is not None
    )

    return {
        "target": {
            "name": target.get("name"),
            "ticker": target.get("ticker"),
            "sector": target.get("sector"),
            "industry": target.get("industry"),
            "revenue": target.get("revenue"),
            "ebitdaMargin": target.get("ebitdaMargin"),
            "marketCap": target.get("marketCap"),
        },
        "bestPeer": {
            "company": best.get("companyName"),
            "ticker": best.get("ticker"),
            "score": best.get("finalScore"),
            "whyBest": best.get("whyBest"),
        }
        if best
        else None,
        "peerNames": [
            f"{peer.get('companyName')} ({peer.get('ticker')})" for peer in peers
        ],
        "counts": {
            "ranked": counts.get("ranked"),
            "fromInternalList": counts.get("vcc"),
            "fromResearch": counts.get("model"),
            "excluded": len(recommendation.get("excluded") or []),
            "pagesRead": len(sources),
            "figuresResearched": figures_read,
        },
    }


def sources_for(recommendation: dict, query: Optional[str] = None) -> list[dict]:
    """Pages read during the run, optionally narrowed to one peer.

    Page text is deliberately dropped. A summary runs to a thousand characters
    and two dozen of them would crowd out the conversation; what a caller needs
    to cite a page is its title, publisher, URL and what it was used for.
    """
    if query:
        peer = find_peer(recommendation, query)
        sources = (peer.get("sources") or []) if peer else []
    else:
        sources = recommendation.get("sources") or []

    return [
        {
            "title": source.get("title") or source.get("name"),
            "publisher": source.get("name"),
            "url": source.get("url"),
            "usedFor": source.get("usedFor") or [],
            "figureCount": len(source.get("figures") or []),
        }
        for source in sources
    ]


def source_text(recommendation: dict, url: str) -> Optional[dict]:
    """The retrieved text of one page, for when a claim has to be quoted."""
    for source in recommendation.get("sources") or []:
        if source.get("url") == url:
            return {
                "title": source.get("title") or source.get("name"),
                "url": url,
                "text": source.get("summary"),
                "figures": source.get("figures") or [],
                "evidence": source.get("evidence") or [],
            }

    return None


def target_figures(recommendation: dict) -> dict[str, Any]:
    """The target's own internal figures, which every peer is compared against."""
    return recommendation.get("target") or {}
