#!/usr/bin/env bash
# Start the API. Default is a debug run with hot reload.
#
#   ./start.sh              # debug + reload on :8000
#   ./start.sh --prod       # no reload, debug off, WEB_CONCURRENCY workers
#   PORT=9000 ./start.sh    # any port
#
set -euo pipefail

cd "$(dirname "$0")"

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-${API_PORT:-8000}}"
WEB_CONCURRENCY="${WEB_CONCURRENCY:-2}"

MODE=dev
args=()
for arg in "$@"; do
  case "$arg" in
    --prod|--no-reload) MODE=prod ;;
    *) args+=("$arg") ;;
  esac
done

# Prefer the project venv, fall back to whatever uvicorn is on PATH.
if [ -x venv/bin/uvicorn ]; then
  UVICORN=venv/bin/uvicorn
elif [ -x .venv/bin/uvicorn ]; then
  UVICORN=.venv/bin/uvicorn
elif command -v uvicorn >/dev/null 2>&1; then
  UVICORN=uvicorn
else
  echo "uvicorn not found. Create the venv first:" >&2
  echo "  python3 -m venv venv && venv/bin/pip install -r requirements.txt" >&2
  exit 1
fi

if [ "$MODE" = dev ]; then
  # OI3_DEBUG set here beats the value in .env (env vars outrank the dotenv file).
  export OI3_DEBUG=true
  echo "→ dev (debug + reload)  http://${HOST}:${PORT}/docs"
  exec "$UVICORN" app.main:app --host "$HOST" --port "$PORT" \
    --reload --reload-dir app "${args[@]+"${args[@]}"}"
else
  echo "→ prod (${WEB_CONCURRENCY} workers)  http://${HOST}:${PORT}"
  exec "$UVICORN" app.main:app --host "$HOST" --port "$PORT" \
    --workers "$WEB_CONCURRENCY" --proxy-headers "${args[@]+"${args[@]}"}"
fi
