/**
 * The CopilotKit runtime, as its own Node process.
 *
 * It sits between the browser and the Python chat agent:
 *
 *   Vite SPA :5173  ->  this runtime :4000  ->  chat agent (AG-UI) :8123
 *
 * It lives in the frontend repo rather than in a package of its own only so
 * there is one node_modules to install. Nothing here is bundled into the SPA:
 * Vite only follows imports out of src/.
 *
 * Why the middle hop exists at all, given the agent already speaks AG-UI over
 * HTTP: the runtime is what holds thread state across turns, multiplexes the
 * frontend's tool declarations, and keeps the agent's address off the public
 * internet. A browser talking straight to the agent would need all three
 * solved in the client.
 */

import { serve } from "@hono/node-server";
import {
  CopilotRuntime,
  createCopilotRuntimeHandler,
  InMemoryAgentRunner,
} from "@copilotkit/runtime/v2";
import { LangGraphHttpAgent } from "@copilotkit/runtime/langgraph";

/* The Python agent. LangGraphHttpAgent (not LangGraphAgent) is the right class
   here: the agent is a self-hosted FastAPI server speaking AG-UI directly, not
   a LangGraph Platform deployment with a graph id. The trailing slash matters,
   because that is the path add_langgraph_fastapi_endpoint was mounted on. */
const AGENT_URL = process.env.OI3_CHAT_AGENT_URL ?? "http://127.0.0.1:8123/";

const PORT = Number(process.env.OI3_RUNTIME_PORT ?? 4000);

/* Where the browser is allowed to call from. Vite's dev server, and the ngrok
   host the project already allows in vite.config.ts. */
const ALLOWED_ORIGINS = (
  process.env.OI3_RUNTIME_ORIGINS ?? "http://localhost:5173,http://127.0.0.1:5173"
)
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const runtime = new CopilotRuntime({
  agents: {
    /* Keyed "oi_assistant" to match the name the agent registers itself under,
       so the two halves cannot drift. The frontend selects it by this id. */
    oi_assistant: new LangGraphHttpAgent({ url: AGENT_URL }),
  },

  /* In-memory is the honest choice for this build. Threads last as long as the
     process, which is the same lifetime as the analysis they belong to: the
     workflow layout unmounts and starts a fresh log when the user leaves. A
     durable store would outlive the thing it is storing. */
  runner: new InMemoryAgentRunner(),
});

const handler = createCopilotRuntimeHandler({
  runtime,
  basePath: "/api/copilotkit",
  cors: { origin: ALLOWED_ORIGINS, credentials: true },
});

serve({ fetch: handler, port: PORT }, () => {
  console.log(`[oi3] CopilotKit runtime  http://127.0.0.1:${PORT}/api/copilotkit`);
  console.log(`[oi3] chat agent          ${AGENT_URL}`);
});
