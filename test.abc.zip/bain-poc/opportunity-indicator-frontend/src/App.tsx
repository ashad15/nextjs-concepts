import {
  BrowserRouter,
  Route,
  Routes,
} from "react-router-dom";

import { CopilotKit } from "@copilotkit/react-core/v2";
import "@copilotkit/react-core/v2/styles.css";

import OIDashboard from "./pages/OIDashboard";
import OISetup from "./pages/OISetup";
import PeerSelection from "./pages/PeerSelection";

import OIWorkflowLayout from "./layouts/OIWorkflowLayout";

/* Proxied by Vite to the CopilotKit runtime on :4000 (see vite.config.ts), so
   the browser never needs the runtime's address and ngrok keeps working. */
const RUNTIME_URL = "/api/copilotkit";

function App() {
  return (
    /* Above the router, because the assistant panel lives in a layout that
       every workflow route renders through, and a provider mounted per-route
       would drop the conversation on navigation. */
    <CopilotKit
      runtimeUrl={RUNTIME_URL}
      /* The runtime is mounted multi-route (createCopilotRuntimeHandler with a
         basePath). The v1-compat bridge defaults this to true, which would send
         every call to the base path and 404. */
      useSingleEndpoint={false}
      /* Off, not merely defaulted. The dev console defaults to on for any
         localhost origin, and it floats a CopilotKit badge and product
         announcements over the top right of the workspace — which lands in the
         middle of a client demo. */
      showDevConsole={false}
      onError={({ type, error, context }) => {
        // Without a handler a bad URL or a stopped runtime leaves the panel
        // saying "connecting…" indefinitely, with nothing in the console.
        console.error("[copilotkit]", type, error, context);
      }}
    >
      <BrowserRouter>
      <Routes>
        {/* MAIN DASHBOARD */}

        <Route
          path="/"
          element={<OIDashboard />}
        />

        {/* OI WORKFLOW */}

        <Route
          path="/oi"
          element={<OIWorkflowLayout />}
        >
          <Route
            path="setup"
            element={<OISetup />}
          />

          <Route
            path="peers"
            element={<PeerSelection />}
          />
        </Route>
      </Routes>
      </BrowserRouter>
    </CopilotKit>
  );
}

export default App;