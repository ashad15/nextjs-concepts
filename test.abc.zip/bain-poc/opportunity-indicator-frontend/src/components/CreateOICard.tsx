interface CreateOICardProps {
  onCreate: () => void;
}

const CreateOICard = ({ onCreate }: CreateOICardProps) => {
  return (
    <button
      type="button"
      className="create-oi-card"
      onClick={onCreate}
    >
      <div className="create-icon">+</div>

      <div className="create-title">
        Create new OI
      </div>

      <div className="create-description">
        Start from a company name — then build the peer set,
        analysis and final output.
      </div>
    </button>
  );
};

export default CreateOICard;