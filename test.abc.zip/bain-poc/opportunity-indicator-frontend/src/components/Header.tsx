const Header = () => {
  return (
    <header className="top-nav">
      <div className="brand">
        <div className="brand-mark">OI</div>

        <span className="brand-name">
          Opportunity Indicator
        </span>

        <span className="nav-separator" />

        <span className="product-name">OI 3.0</span>
      </div>

      <div className="nav-right">
        <div className="avatar">AU</div>
      </div>
    </header>
  );
};

export default Header;