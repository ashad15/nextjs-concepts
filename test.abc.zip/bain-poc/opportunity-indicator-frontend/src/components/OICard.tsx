import { useState } from "react";
import {
  OI_STAGES,
  type OpportunityIndicator,
} from "../types/oi";

interface OICardProps {
  oi: OpportunityIndicator;
  onDelete: (id: string) => void;
  onOpen: (oi: OpportunityIndicator) => void;
}

const OICard = ({
  oi,
  onDelete,
  onOpen,
}: OICardProps) => {
  const [menuOpen, setMenuOpen] = useState(false);

  const completed = oi.status === "done";

  const progress = completed
    ? 100
    : Math.round(((oi.stage + 1) / OI_STAGES.length) * 100);

  const stageName = completed
    ? "Complete"
    : OI_STAGES[oi.stage];

  const handleMenuClick = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.stopPropagation();
    setMenuOpen((current) => !current);
  };

  const handleDelete = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.stopPropagation();
    onDelete(oi.id);
    setMenuOpen(false);
  };

  const handleShare = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.stopPropagation();

    navigator.clipboard
      ?.writeText(`${window.location.origin}/oi/${oi.id}`)
      .catch(() => undefined);

    setMenuOpen(false);
  };

  return (
    <article
      className="oi-card"
      onClick={() => onOpen(oi)}
    >
      <div className="oi-card-header">
        <div className="company-initials">
          {oi.initials}
        </div>

        <div className="company-details">
          <div className="company-name">
            {oi.name}
          </div>

          <div className="company-sector">
            {oi.sector}
          </div>
        </div>

        <button
          type="button"
          className="menu-button"
          onClick={handleMenuClick}
          aria-label="More options"
        >
          <span />
          <span />
          <span />
        </button>

        {menuOpen && (
          <div
            className="oi-menu"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              onClick={handleShare}
            >
              Share
            </button>

            <button
              type="button"
              className="delete-button"
              onClick={handleDelete}
            >
              Delete
            </button>
          </div>
        )}
      </div>

      <div
        className={`prize-section ${
          !oi.prize ? "pending" : ""
        }`}
      >
        <div className="prize-number">
          {oi.prize ?? "—"}
        </div>

        <div className="prize-label">
          {oi.prize
            ? "Size of prize"
            : "Sized after analysis"}
        </div>
      </div>

      <div className="oi-state">
        <div className="state-heading">
          <span className="stage-name">
            {stageName}
          </span>

          <span
            className={`status-badge ${
              completed ? "complete" : "active"
            }`}
          >
            {completed ? "Complete" : "In progress"}
          </span>
        </div>

        <div className="progress-track">
          <div
            className={`progress-fill ${
              completed ? "complete" : ""
            }`}
            style={{
              width: `${progress}%`,
            }}
          />
        </div>

        <div className="stage-description">
          {completed
            ? `All ${OI_STAGES.length} stages complete`
            : `Stage ${oi.stage + 1} of ${
                OI_STAGES.length
              } · ${OI_STAGES[oi.stage]}`}
        </div>

        <div className="stage-list">
          {OI_STAGES.map((stage, index) => (
            <div
              key={stage}
              className={[
                "stage-item",
                index < oi.stage || completed
                  ? "done"
                  : "",
                index === oi.stage && !completed
                  ? "current"
                  : "",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              <span className="stage-dot" />
              <span>{stage}</span>
            </div>
          ))}
        </div>
      </div>

      <footer className="oi-footer">
        <span>{oi.updated}</span>

        <div className="collaborators">
          {oi.collaborators.map(
            (collaborator, index) => (
              <div
                className="collaborator-avatar"
                key={`${collaborator}-${index}`}
              >
                {collaborator}
              </div>
            )
          )}
        </div>
      </footer>
    </article>
  );
};

export default OICard;