import {
  lazy,
  Suspense,
  useEffect,
  useState,
  type ReactNode,
} from "react";

import {
  collaboratorInitials,
  collaborators,
} from "../../data/collaborators";

import { relativeTime } from "../../utils/relativeTime";

import type { ActivityActor, ActivityEntry } from "../../types/activity";
import type { PeerRecommendationResponse } from "../../types/peer";

/* A modal, and it pulls in KaTeX and its stylesheet. Fetched when someone
   actually opens the audit rather than on every page load. */
const DataAudit = lazy(() => import("../Peers/DataAudit"));

/* How often the "Just now" stamps are re-read. Entries only ever cross a
   whole-minute boundary, so anything finer would re-render for nothing. */
const TICK_MS = 30_000;

const ACTOR_LABEL: Record<ActivityActor, string> = {
  human: "You",
  system: "System",
  agent: "Agent",
};

/* Entry text carries ** around the value that matters, so a line reads
   "Named target: Nike, Inc." with the name standing out. The split keeps the
   delimiters, so odd indexes are the bold runs. */
const renderText = (text: string): ReactNode[] =>
  text.split(/(\*\*[^*]+\*\*)/g).map((part, index) =>
    part.startsWith("**") && part.endsWith("**") ? (
      <strong key={index}>{part.slice(2, -2)}</strong>
    ) : (
      part
    ),
  );

interface ActivityLogTabProps {
  entries: ActivityEntry[];

  /** Null until peers exist. Without it an audit entry has nothing to open. */
  recommendation: PeerRecommendationResponse | null;
}

const ActivityLogTab = ({
  entries,
  recommendation,
}: ActivityLogTabProps) => {
  const [now, setNow] = useState(() => Date.now());

  const [auditOpen, setAuditOpen] = useState(false);

  useEffect(() => {
    const timer = window.setInterval(
      () => setNow(Date.now()),
      TICK_MS,
    );

    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="assistant-tab-content">
      {/* SHARED WITH — static, see data/collaborators.ts */}

      <section className="log-share-card">
        <h3 className="log-share-title">
          Shared with {collaborators.length}
        </h3>

        <ul className="log-share-list">
          {collaborators.map((person) => (
            <li className="log-share-row" key={person.id}>
              <span
                className={`log-share-avatar ${
                  person.online ? "online" : ""
                }`}
              >
                {collaboratorInitials(person.name)}
              </span>

              <span className="log-share-identity">
                <span className="log-share-name">{person.name}</span>

                <span className="log-share-role">{person.title}</span>
              </span>

              <span className="log-share-access">
                <span
                  className={`log-share-badge ${person.role.toLowerCase()}`}
                >
                  {person.role}
                </span>

                <span className="log-share-seen">{person.lastSeen}</span>
              </span>
            </li>
          ))}
        </ul>

        <p className="log-share-note">
          Contributors can edit; viewers can view &amp; comment only.
        </p>
      </section>

      {/* ACTIVITY */}

      <ul className="log-list">
        {entries.map((entry) => (
          <li
            className={`log-entry log-entry-${entry.actor}`}
            key={entry.id}
          >
            <span className="log-entry-marker" aria-hidden="true">
              <span className="log-dot" />

              <span className="log-rail" />
            </span>

            <div className="log-entry-content">
              <div className="log-actor">{ACTOR_LABEL[entry.actor]}</div>

              <div className="log-text">{renderText(entry.text)}</div>

              {entry.detail === "peer-audit" &&
                recommendation && (
                  <button
                    className="log-audit-link"
                    onClick={() => setAuditOpen(true)}
                    type="button"
                  >
                    Show where every figure came from
                  </button>
                )}

              <div className="log-time">
                {relativeTime(entry.at, now)}
              </div>
            </div>
          </li>
        ))}
      </ul>

      {auditOpen && recommendation && (
        <Suspense fallback={null}>
          <DataAudit
            recommendation={recommendation}
            onClose={() => setAuditOpen(false)}
          />
        </Suspense>
      )}
    </div>
  );
};

export default ActivityLogTab;
