import { useMemo } from "react";
import { useLocation } from "react-router-dom";

import {
  CopilotChat,
  useConfigureSuggestions,
} from "@copilotkit/react-core/v2";

import MentionChatInput from "../../copilot/MentionChatInput";
import StageBanner from "../../copilot/StageBanner";
import { OI_AGENT_ID, OI_THREAD_ID } from "../../copilot/agent";

import "../../styles/AssistantChat.css";

/* Each step: what it is called, what it follows, and what it fixes.
 *
 * `note` is what stops the chat being asked to do something the step no longer
 * allows, so it says what is closed rather than merely naming the step. */
const STAGES: Record<
  string,
  { stage: string; completed: string | null; note: string | null }
> = {
  "/oi/setup": {
    stage: "Analysis set-up",
    completed: null,
    note: null,
  },
  "/oi/peers": {
    stage: "Peer selection",
    completed: "Target",
    note: "Target and criteria are fixed for this run. Changing them means running the analysis again.",
  },
};

/* Prompts worth offering, per screen.
 *
 * Screen-specific because a chip is a suggestion about what to do next, and
 * "what was rejected" is meaningless on a screen where nothing has been run
 * yet. Offering it there advertises an answer the assistant cannot give. */
const SUGGESTIONS: Record<
  string,
  { title: string; message: string }[]
> = {
  "/oi/setup": [
    {
      title: "What do I need?",
      message:
        "What information do I need to provide to run this analysis?",
    },
    {
      title: "How are peers picked?",
      message:
        "How will the peers be selected and scored once I run this?",
    },
    {
      title: "Which criteria?",
      message:
        "Which comparability criteria should I tick for this target, and why?",
    },
  ],

  "/oi/peers": [
    {
      title: "Why these peers?",
      message:
        "Why was this peer set selected? Walk me through the reasoning.",
    },
    {
      title: "Compare top three",
      message:
        "Show me the key figures for the top three peers in a table.",
    },
    {
      title: "What was rejected?",
      message:
        "Which candidates were assessed and turned down, and why?",
    },
  ],
};

const FALLBACK = SUGGESTIONS["/oi/setup"];

/**
 * The Chat tab.
 *
 * CopilotChat as shipped, with one slot replaced: the input, so that typing "@"
 * opens the company list. Everything else — streaming, markdown, tool-call
 * rendering, the confirmation card, attachments — is CopilotKit's own and is
 * left alone.
 */
const AssistantChatTab = () => {
  const { pathname } = useLocation();

  const suggestions = useMemo(
    () => SUGGESTIONS[pathname] ?? FALLBACK,
    [pathname],
  );

  useConfigureSuggestions({
    suggestions,
    available: "always",
  });

  const stage = STAGES[pathname];

  return (
    <div className="oi-chat-host">
      {stage && (
        <StageBanner
          stage={stage.stage}
          completed={stage.completed}
          note={stage.note}
        />
      )}

      <CopilotChat
        agentId={OI_AGENT_ID}
        /* Fresh per page load, so a refresh starts a new conversation rather
           than rejoining the one the runtime still holds in memory. */
        threadId={OI_THREAD_ID}
        input={MentionChatInput}
        labels={{
          chatInputPlaceholder:
            "Ask about this analysis, or type @ to name a company…",
        }}
      />
    </div>
  );
};

export default AssistantChatTab;
