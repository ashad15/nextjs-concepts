import { useState } from "react";

import ActivityLogTab from "./ActivityLogTab";
import FilingsTab from "./FilingsTab";
import SourcesTab from "./SourcesTab";
import AssistantChatTab from "./AssistantChatTab";

import type { ActivityLog } from "../../hooks/useActivityLog";
import type { PeerRecommendationResponse } from "../../types/peer";

type AssistantTab =
  | "chat"
  | "log"
  | "sources"
  | "filings";

/* "Filings" rather than "Documents": it is what the run log and the audit
   panel already call them, and the panel is narrow enough that the longer
   word crowds the other three out. */
const TABS: { id: AssistantTab; label: string }[] = [
  { id: "chat", label: "Chat" },
  { id: "log", label: "Log" },
  { id: "sources", label: "Sources" },
  { id: "filings", label: "Filings" },
];

interface AssistantPanelProps {
  activity: ActivityLog;

  /** Null until peers have been proposed; the Sources tab reads it. */
  recommendation: PeerRecommendationResponse | null;

  /** The peer being hovered on the left, if any. */
  highlightedPeerId: string | null;

  /* A request from elsewhere in the workflow to show one group's pages. The
     counter is what makes a repeat request for the same group land. */
  sourcesFocus: {
    groupId: string;
    request: number;
  } | null;
}

const AssistantPanel = ({
  activity,
  recommendation,
  highlightedPeerId,
  sourcesFocus,
}: AssistantPanelProps) => {
  const [activeTab, setActiveTab] =
    useState<AssistantTab>("chat");

  /* Asked for a group's pages, so the tab it lives in has to be the one on
     screen. Adjusted during render rather than in an effect: this is derived
     from a prop, and an effect would paint the old tab first and then switch.
     Tracking the request number rather than the group is what lets the same
     group be asked for twice after the reader has switched away. */
  const [seenRequest, setSeenRequest] =
    useState(0);

  const request = sourcesFocus?.request ?? 0;

  if (request !== seenRequest) {
    setSeenRequest(request);
    setActiveTab("sources");
  }

  return (
    <aside className="assistant-panel">
      {/* TABS */}

      <div className="assistant-tabs">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={`assistant-tab ${
              activeTab === tab.id
                ? "active"
                : ""
            }`}
            onClick={() =>
              setActiveTab(tab.id)
            }
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* CHAT

          Hidden rather than unmounted, unlike the other three tabs. Two
          reasons: an answer in flight keeps streaming while the reader checks
          the Log, and a confirmation waiting on a decision would be abandoned
          by an unmount, leaving the assistant's turn open with no way back to
          the buttons. */}

      <div
        className="assistant-chat-host"
        hidden={activeTab !== "chat"}
      >
        <AssistantChatTab />
      </div>

      {/* LOG */}

      {activeTab === "log" && (
        <ActivityLogTab
          entries={activity.entries}
          recommendation={recommendation}
        />
      )}

      {/* SOURCES */}

      {activeTab === "sources" && (
        <SourcesTab
          recommendation={recommendation}
          highlightedPeerId={
            highlightedPeerId ??
            sourcesFocus?.groupId ??
            null
          }
        />
      )}

      {/* FILINGS */}

      {activeTab === "filings" && (
        <FilingsTab
          recommendation={recommendation}
          highlightedPeerId={highlightedPeerId}
        />
      )}
    </aside>
  );
};

export default AssistantPanel;
