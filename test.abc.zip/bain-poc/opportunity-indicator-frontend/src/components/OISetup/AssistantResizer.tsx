import { useCallback, useState } from "react";

import { clamp } from "../../utils/clamp";

interface AssistantResizerProps {
  /** The flex row holding the workspace and the assistant panel. */
  containerRef: React.RefObject<HTMLDivElement | null>;

  /** Current assistant panel width, as a percentage of the row. */
  width: number;

  min: number;
  max: number;

  /** Fires continuously while dragging. */
  onWidthChange: (next: number) => void;

  /** Fires once the gesture settles, for persistence. */
  onCommit: (next: number) => void;
}

/** Percentage points moved per arrow-key press. */
const KEYBOARD_STEP = 2;

const AssistantResizer = ({
  containerRef,
  width,
  min,
  max,
  onWidthChange,
  onCommit,
}: AssistantResizerProps) => {
  const [dragging, setDragging] = useState(false);

  /** Pointer x → panel width, measured from the right edge of the row. */
  const widthFromPointer = useCallback(
    (clientX: number) => {
      const container = containerRef.current;

      if (!container) {
        return null;
      }

      const rect =
        container.getBoundingClientRect();

      if (rect.width === 0) {
        return null;
      }

      return clamp(
        ((rect.right - clientX) / rect.width) * 100,
        min,
        max,
      );
    },
    [containerRef, min, max],
  );

  const handlePointerDown = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (event.button !== 0) {
      return;
    }

    // Capture so the drag keeps tracking outside the 9px strip.
    event.currentTarget.setPointerCapture(
      event.pointerId,
    );

    setDragging(true);
  };

  const handlePointerMove = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (!dragging) {
      return;
    }

    const next = widthFromPointer(event.clientX);

    if (next !== null) {
      onWidthChange(next);
    }
  };

  const handlePointerUp = (
    event: React.PointerEvent<HTMLDivElement>,
  ) => {
    if (!dragging) {
      return;
    }

    if (
      event.currentTarget.hasPointerCapture(
        event.pointerId,
      )
    ) {
      event.currentTarget.releasePointerCapture(
        event.pointerId,
      );
    }

    setDragging(false);

    onCommit(width);
  };

  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLDivElement>,
  ) => {
    // The panel is on the right, so left widens it and right narrows it.
    const target =
      event.key === "ArrowLeft"
        ? width + KEYBOARD_STEP
        : event.key === "ArrowRight"
          ? width - KEYBOARD_STEP
          : null;

    if (target === null) {
      return;
    }

    event.preventDefault();

    const next = clamp(target, min, max);

    onWidthChange(next);
    onCommit(next);
  };

  return (
    <div
      className="oi-panel-resizer"
      role="separator"
      aria-orientation="vertical"
      aria-label="Resize the assistant panel"
      aria-valuenow={Math.round(width)}
      aria-valuemin={min}
      aria-valuemax={max}
      tabIndex={0}
      data-dragging={dragging}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onKeyDown={handleKeyDown}
    >
      <span className="oi-panel-resizer-grip" />
    </div>
  );
};

export default AssistantResizer;
