import { useState } from "react";

interface ContextSetupCardProps {
  visible: boolean;
}

const audienceOptions = [
  "CFO conversation",
  "CEO conversation",
  "Board audience",
  "Others",
];

const ContextSetupCard = ({
  visible,
}: ContextSetupCardProps) => {
  const [selectedAudiences, setSelectedAudiences] =
    useState<string[]>(["CFO conversation"]);

  const [otherAudience, setOtherAudience] =
    useState("");

  const handleAudienceSelect = (
    audience: string
  ) => {
    setSelectedAudiences((current) => {
      if (current.includes(audience)) {
        return current.filter(
          (item) => item !== audience
        );
      }

      return [...current, audience];
    });
  };

  if (!visible) {
    return null;
  }

  return (
    <section className="setup-card">
      <div className="setup-card-header">
        <div className="setup-card-step">
          2
        </div>

        <div className="setup-card-heading">
          <div className="setup-card-title">
            Context
          </div>

          <div className="setup-card-subtitle">
            Who's the deck for, and anything that
            should shape the number.
          </div>
        </div>

        <div className="setup-card-optional">
          Optional
        </div>
      </div>

      <div className="setup-card-body">
        <div className="context-question">
          Who's this deck for?
        </div>

        <div className="context-options">
          {audienceOptions.map((audience) => (
            <button
              key={audience}
              type="button"
              className={`context-chip ${
                selectedAudiences.includes(audience)
                  ? "selected"
                  : ""
              }`}
              onClick={() =>
                handleAudienceSelect(audience)
              }
            >
              {audience}
            </button>
          ))}
        </div>

        {selectedAudiences.includes("Others") && (
          <input
            type="text"
            className="context-other-input"
            value={otherAudience}
            onChange={(event) =>
              setOtherAudience(event.target.value)
            }
            placeholder="Who's the deck for?"
          />
        )}
      </div>
    </section>
  );
};

export default ContextSetupCard;