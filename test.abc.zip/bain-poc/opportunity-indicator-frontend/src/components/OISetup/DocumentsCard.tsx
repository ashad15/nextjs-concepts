import {
  useRef,
  useState,
  type DragEvent,
  type ChangeEvent,
} from "react";

interface DocumentsCardProps {
  visible: boolean;
}

interface UploadedDocument {
  id: string;
  name: string;
  size: number;
  type: string;
}

const DocumentsCard = ({
  visible,
}: DocumentsCardProps) => {
  const [documents, setDocuments] = useState<
    UploadedDocument[]
  >([]);

  const [isDragging, setIsDragging] =
    useState(false);

  const fileInputRef =
    useRef<HTMLInputElement>(null);

  if (!visible) {
    return null;
  }

  const addFiles = (files: FileList | File[]) => {
    const selectedFiles = Array.from(files);

    const mappedFiles: UploadedDocument[] =
      selectedFiles.map((file) => ({
        id: crypto.randomUUID(),
        name: file.name,
        size: file.size,
        type: file.type,
      }));

    setDocuments((current) => [
      ...current,
      ...mappedFiles,
    ]);
  };

  const handleBrowse = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    if (!event.target.files) {
      return;
    }

    addFiles(event.target.files);

    // Allows selecting the same file again later
    event.target.value = "";
  };

  const handleDragOver = (
    event: DragEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (
    event: DragEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (
    event: DragEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
    setIsDragging(false);

    if (event.dataTransfer.files.length > 0) {
      addFiles(event.dataTransfer.files);
    }
  };

  const removeDocument = (id: string) => {
    setDocuments((current) =>
      current.filter(
        (document) => document.id !== id
      )
    );
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) {
      return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }

    return `${(
      bytes /
      (1024 * 1024)
    ).toFixed(1)} MB`;
  };

  const confidence = Math.min(
    70 + documents.length * 8,
    95
  );

  return (
    <section className="setup-card">
      <div className="setup-card-header">
        <div className="setup-card-step">
          5
        </div>

        <div className="setup-card-heading">
          <div className="setup-card-title">
            Documents
          </div>

          <div className="setup-card-subtitle">
            Add what you have — each type sharpens
            a different part of the analysis.
          </div>
        </div>

        <div className="setup-card-optional">
          Optional
        </div>
      </div>

      <div className="setup-card-body">
        {/* Hidden real file input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="document-hidden-input"
          onChange={handleFileChange}
          accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.txt"
        />

        {/* Drag + Browse area */}
        <button
          type="button"
          className={`document-upload-zone ${
            isDragging ? "dragging" : ""
          }`}
          onClick={handleBrowse}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="document-upload-icon">
            ↑
          </div>

          <div className="document-upload-title">
            Drop files or{" "}
            <strong>browse</strong>
          </div>

          <div className="document-upload-subtitle">
            Emails, financials or P&amp;L,
            reports, RFP — anything you have on
            the target.
          </div>

          <div className="document-upload-supported">
            PDF, Word, Excel, PowerPoint, CSV or text
          </div>
        </button>

        <div className="document-template-section">
          <button
            type="button"
            className="document-template-link"
          >
            ↓ Download P&amp;L template
          </button>

          <div className="document-template-note">
            Most useful for private companies,
            where public filings may not be
            available. Mapping the client's
            financials into a structured template
            can improve the analysis.
          </div>
        </div>

        {documents.length > 0 && (
          <div className="uploaded-document-list">
            {documents.map((document) => (
              <div
                key={document.id}
                className="uploaded-document"
              >
                <div className="uploaded-document-icon">
                  FILE
                </div>

                <div className="uploaded-document-main">
                  <div className="uploaded-document-name">
                    {document.name}
                  </div>

                  <div className="uploaded-document-status">
                    {formatFileSize(
                      document.size
                    )}{" "}
                    · Ready
                  </div>
                </div>

                <button
                  type="button"
                  className="uploaded-document-remove"
                  onClick={() =>
                    removeDocument(document.id)
                  }
                  aria-label={`Remove ${document.name}`}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="analysis-confidence-card">
          <div className="analysis-confidence-header">
            <div className="analysis-confidence-title">
              Analysis confidence
            </div>

            <div
              className={`analysis-confidence-level ${
                confidence >= 80
                  ? "high"
                  : "medium"
              }`}
            >
              {confidence >= 80
                ? "High"
                : "Medium"}
            </div>
          </div>

          <div className="analysis-confidence-track">
            <div
              className="analysis-confidence-fill"
              style={{
                width: `${confidence}%`,
              }}
            />
          </div>

          <div className="analysis-confidence-note">
            {documents.length > 0
              ? `Confidence improved with ${documents.length} selected document${
                  documents.length > 1
                    ? "s"
                    : ""
                }.`
              : "Public and available company data can be used to begin. Additional documents can improve confidence."}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DocumentsCard;