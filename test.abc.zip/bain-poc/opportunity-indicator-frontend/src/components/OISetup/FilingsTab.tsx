import { useMemo } from "react";

import DocumentLink from "../Peers/DocumentLink";

import {
  countDocuments,
  groupDocumentsByPeer,
} from "../../utils/documentGroups";

import { confidenceLabel } from "../../utils/peerConfidence";

import { useHighlightScroll } from "../../hooks/useHighlightScroll";

import type { PeerRecommendationResponse } from "../../types/peer";

import "../../styles/PeerDocuments.css";

interface FilingsTabProps {
  recommendation: PeerRecommendationResponse | null;

  /** The peer under the cursor on the left, matched against a group id. */
  highlightedPeerId: string | null;
}

/**
 * Annual reports and filings found during the run, grouped by peer.
 *
 * Separate from Sources because the two answer different questions. A source
 * is where a figure came from; a filing is primary material the research
 * surfaced and deliberately did not read, since those sites publish documents
 * rather than tables an extractor can use. Mixing them would blur exactly the
 * line the audit view exists to hold, so the tab says outright that nothing
 * here backs a number.
 *
 * Grouping, ids and highlight behaviour match the sources tab, so hovering a
 * peer on the left lights up its evidence whichever tab is open.
 */
const FilingsTab = ({
  recommendation,
  highlightedPeerId,
}: FilingsTabProps) => {
  const groups = useMemo(
    () =>
      recommendation
        ? groupDocumentsByPeer(recommendation)
        : [],
    [recommendation],
  );

  const total = countDocuments(groups);

  const scrollRef = useHighlightScroll(
    highlightedPeerId,
  );

  if (total === 0) {
    return (
      <div className="assistant-tab-content">
        <p className="oi-sources-empty">
          {recommendation
            ? "No filings were found for this run. The peers were either matched from the internal set or researched on pages that publish figures rather than documents."
            : "No filings yet. Propose peers and any annual report or filing found for them will be listed here, grouped by peer."}
        </p>
      </div>
    );
  }

  return (
    <div
      className="assistant-tab-content"
      ref={scrollRef}
    >
      <h3 className="oi-sources-heading">
        {total} {total === 1 ? "filing" : "filings"} found
      </h3>

      <p className="oi-filings-note">
        Primary documents surfaced during research. None of them was read for a
        figure, so nothing on the peer screen rests on one.
      </p>

      {groups.map((group) => (
        <section
          className="oi-source-group"
          key={group.id}
          data-group={group.id}
          data-highlighted={
            group.id === highlightedPeerId
          }
        >
          <header className="oi-source-group-head">
            <span className="oi-source-group-name">
              {group.title}
            </span>

            {group.confidence && (
              <span
                className={`oi-source-confidence ${group.confidence}`}
              >
                {confidenceLabel[group.confidence]}
              </span>
            )}

            <span className="oi-source-group-count">
              {group.documents.length}
            </span>
          </header>

          <div className="oi-source-group-list">
            {group.documents.map((document) => (
              <DocumentLink
                key={document.url}
                document={document}
              />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default FilingsTab;
