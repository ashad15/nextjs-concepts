import { useState } from "react";

interface FramingSetupCardProps {
  visible: boolean;
}

const FramingSetupCard = ({
  visible,
}: FramingSetupCardProps) => {
  const [primaryGoals, setPrimaryGoals] =
    useState<string[]>([]);

  const [priorities, setPriorities] =
    useState<string[]>([]);

  const [additionalContext, setAdditionalContext] =
    useState("");

  const handlePrimaryGoalSelect = (
    option: string
  ) => {
    setPrimaryGoals((current) => {
      if (current.includes(option)) {
        return current.filter(
          (item) => item !== option
        );
      }

      return [...current, option];
    });
  };

  const handlePrioritySelect = (
    option: string
  ) => {
    setPriorities((current) => {
      if (current.includes(option)) {
        return current.filter(
          (item) => item !== option
        );
      }

      return [...current, option];
    });
  };

  if (!visible) {
    return null;
  }

  return (
    <section className="setup-card">
      <div className="setup-card-header">
        <div className="setup-card-step">
          3
        </div>

        <div className="setup-card-heading">
          <div className="setup-card-title">
            Framing
          </div>

          <div className="setup-card-subtitle">
            A few quick questions so the analysis
            is steered in the right direction.
          </div>
        </div>

        <div className="setup-card-optional">
          Optional
        </div>
      </div>

      <div className="setup-card-body">
        <div className="framing-question">
          <div className="framing-question-title">
            <span className="framing-question-number">
              1
            </span>
            What are you primarily trying to understand?
          </div>

          <div className="framing-options">
            {[
              "Cost opportunity",
              "Growth opportunity",
              "Margin improvement",
              "Full potential",
            ].map((option) => (
              <button
                key={option}
                type="button"
                className={`framing-chip ${
                  primaryGoals.includes(option)
                    ? "selected"
                    : ""
                }`}
                onClick={() =>
                  handlePrimaryGoalSelect(option)
                }
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        <div className="framing-question">
          <div className="framing-question-title">
            <span className="framing-question-number">
              2
            </span>
            What should matter most in the analysis?
          </div>

          <div className="framing-options">
            {[
              "Revenue",
              "Profitability",
              "Market position",
              "Efficiency",
              "Growth",
            ].map((option) => (
              <button
                key={option}
                type="button"
                className={`framing-chip ${
                  priorities.includes(option)
                    ? "selected"
                    : ""
                }`}
                onClick={() =>
                  handlePrioritySelect(option)
                }
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        <div className="framing-question">
          <div className="framing-question-title">
            <span className="framing-question-number">
              3
            </span>
            Anything else the analysis should consider?
          </div>

          <textarea
            className="framing-textarea"
            value={additionalContext}
            onChange={(event) =>
              setAdditionalContext(
                event.target.value
              )
            }
            placeholder="Add any hypothesis, ambition, constraint or context..."
          />
        </div>
      </div>
    </section>
  );
};

export default FramingSetupCard;