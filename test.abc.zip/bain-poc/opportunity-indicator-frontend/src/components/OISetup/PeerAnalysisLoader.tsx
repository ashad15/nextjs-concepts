import { useMemo } from "react";

import type { Company } from "../../data/companies";

import {
  analysisStages,
  parallelTracks,
  type ParallelTrack,
  type StageActor,
} from "../../data/analysisStages";

import {
  useScriptedProgress,
  type ProgressStatus,
} from "../../hooks/useScriptedProgress";

import "../../styles/PeerAnalysisLoader.css";

type StepState = "pending" | "active" | "complete";

const stageIndex = (id: string) =>
  analysisStages.findIndex(
    (stage) => stage.id === id,
  );

/* Where the spine forks and where it joins, derived from the tracks rather
   than written down twice. Adding a second parallel track widens the band on
   its own; nothing here needs editing. */
const bandStart = Math.min(
  ...parallelTracks.flatMap((track) =>
    track.alongside.map(stageIndex),
  ),
);

const bandEnd = Math.max(
  ...parallelTracks.flatMap((track) =>
    track.alongside.map(stageIndex),
  ),
);

/** A track's state, read off the spine.
 *
 * `completesWith` is what makes the early finish visible: once the spine has
 * moved past that step the track shows as done while the other lane is still
 * running, which is the real behaviour and the point of the whole layout. */
const trackState = (
  track: ParallelTrack,
  active: number,
): StepState => {
  const starts = Math.min(
    ...track.alongside.map(stageIndex),
  );

  const ends = stageIndex(track.completesWith);

  if (active < starts) {
    return "pending";
  }

  return active > ends
    ? "complete"
    : "active";
};

const spineState = (
  index: number,
  active: number,
): StepState => {
  if (index < active) {
    return "complete";
  }

  return index === active
    ? "active"
    : "pending";
};

interface StepRowProps {
  actor: StageActor;
  actorLabel: string;

  title: string;
  description: string;

  state: StepState;

  /* Forces the connector line on a step that ends its container but is not
     the end of the run, so the spine reads as continuous across the fork. */
  continues?: boolean;
}

const StepRow = ({
  actor,
  actorLabel,
  title,
  description,
  state,
  continues,
}: StepRowProps) => (
  <div
    className={[
      "peer-analysis-stage",
      `actor-${actor}`,
      state === "complete" ? "complete" : "",
      state === "active" ? "active" : "",
      continues ? "continues" : "",
    ]
      .filter(Boolean)
      .join(" ")}
  >
    <div className="peer-analysis-stage-marker">
      {state === "complete" ? (
        <span>✓</span>
      ) : state === "active" ? (
        <span className="peer-analysis-pulse" />
      ) : (
        <span className="peer-analysis-empty-dot" />
      )}
    </div>

    <div className="peer-analysis-stage-content">
      <div className="peer-analysis-stage-head">
        <span className="peer-analysis-stage-title">
          {title}
        </span>

        {/* Which side of the system did this: the whole point of the screen
            for an audience that wants provenance. */}
        <span className="peer-analysis-stage-actor">
          {actorLabel}
        </span>
      </div>

      <div className="peer-analysis-stage-description">
        {description}
      </div>
    </div>
  </div>
);

interface PeerAnalysisLoaderProps {
  company: Company;

  /** Whether the recommendation call has come back. */
  status: ProgressStatus;

  /** Called once, when the narration has finished and the screen can move. */
  onComplete: () => void;
}

const PeerAnalysisLoader = ({
  company,
  status,
  onComplete,
}: PeerAnalysisLoaderProps) => {
  const { stage: activeStage, tick } =
    useScriptedProgress(
      analysisStages,
      status,
      onComplete,
    );

  const current = analysisStages[activeStage];

  /* Tracks running right now. While one of these is live the screen is
     showing two things happening at once, and the status card says so. */
  const liveTracks = parallelTracks.filter(
    (track) =>
      trackState(track, activeStage) ===
      "active",
  );

  const inBand =
    activeStage >= bandStart &&
    activeStage <= bandEnd;

  const companyInitial = useMemo(
    () =>
      company.name
        .trim()
        .charAt(0)
        .toUpperCase(),
    [company.name],
  );

  const note = inBand
    ? "Two tracks are running at the same time. The internal pass finishes inside the agent's search window, so it costs almost no extra time."
    : current.actor === "agent"
      ? "Agent steps depend on live web searches, so they take the longest."
      : "This may take a few moments while peer candidates are evaluated.";

  return (
    <div className="peer-analysis-loader">
      <div className="peer-analysis-loader-inner">
        <div className="peer-analysis-ai-badge">
          <span className="peer-analysis-ai-icon">
            AI
          </span>

          <span>
            Peer recommendation in progress
          </span>
        </div>

        <div className="peer-analysis-heading">
          Building your peer set
        </div>

        <div className="peer-analysis-subtitle">
          Analysing{" "}
          <strong>{company.name}</strong>{" "}
          against relevant comparable
          companies.
        </div>

        <div className="peer-analysis-company-card">
          <div className="peer-analysis-company-logo">
            {companyInitial}
          </div>

          <div className="peer-analysis-company-info">
            <div className="peer-analysis-company-name">
              {company.name}
            </div>

            <div className="peer-analysis-company-meta">
              <span>
                {company.ticker}
              </span>

              <span className="peer-analysis-meta-dot">
                •
              </span>

              <span>
                {company.sector}
              </span>
            </div>

            <div className="peer-analysis-company-industry">
              {company.industry}
            </div>
          </div>
        </div>

        <div className="peer-analysis-progress">
          {/* Before the fork: one sequence, one column. */}
          {analysisStages
            .slice(0, bandStart)
            .map((stage, index) => (
              <StepRow
                key={stage.id}
                actor={stage.actor}
                actorLabel={stage.actorLabel}
                title={stage.title}
                description={stage.description}
                state={spineState(
                  index,
                  activeStage,
                )}
                continues
              />
            ))}

          <div
            className={[
              "peer-analysis-fork",
              activeStage >= bandStart
                ? "reached"
                : "",
            ]
              .filter(Boolean)
              .join(" ")}
          >
            <div className="peer-analysis-fork-rail">
              <span className="peer-analysis-fork-label">
                Runs in parallel
              </span>
            </div>

            <div className="peer-analysis-lanes">
              {/* Left lane: the agent's own work, on the spine. */}
              <div className="peer-analysis-lane">
                <div className="peer-analysis-lane-label">
                  Peers we don't hold
                </div>

                {analysisStages
                  .slice(
                    bandStart,
                    bandEnd + 1,
                  )
                  .map((stage, offset) => (
                    <StepRow
                      key={stage.id}
                      actor={stage.actor}
                      actorLabel={
                        stage.actorLabel
                      }
                      title={stage.title}
                      description={
                        stage.description
                      }
                      state={spineState(
                        bandStart + offset,
                        activeStage,
                      )}
                    />
                  ))}
              </div>

              {/* Right lane: everything running beside the spine. */}
              <div className="peer-analysis-lane">
                <div className="peer-analysis-lane-label">
                  Peers we already hold
                </div>

                {parallelTracks.map(
                  (track) => {
                    const state =
                      trackState(
                        track,
                        activeStage,
                      );

                    return (
                      <div
                        key={track.id}
                        className="peer-analysis-track"
                      >
                        <StepRow
                          actor={track.actor}
                          actorLabel={
                            track.actorLabel
                          }
                          title={track.title}
                          description={
                            track.description
                          }
                          state={state}
                        />

                        {/* Said once the track is done and the other lane is
                            still going: the saving is the reason it exists. */}
                        {state ===
                          "complete" &&
                          activeStage <=
                            bandEnd && (
                            <div className="peer-analysis-track-done">
                              Finished while the
                              agent is still
                              searching
                            </div>
                          )}
                      </div>
                    );
                  },
                )}
              </div>
            </div>

            <div className="peer-analysis-fork-rail join">
              <span className="peer-analysis-fork-label">
                Both tracks merge
              </span>
            </div>
          </div>

          {/* After the join: one sequence again. */}
          {analysisStages
            .slice(bandEnd + 1)
            .map((stage, offset) => (
              <StepRow
                key={stage.id}
                actor={stage.actor}
                actorLabel={stage.actorLabel}
                title={stage.title}
                description={stage.description}
                state={spineState(
                  bandEnd + 1 + offset,
                  activeStage,
                )}
              />
            ))}
        </div>

        <div className="peer-analysis-status-card">
          <div className="peer-analysis-status-loader">
            <span />
            <span />
            <span />
          </div>

          <div className="peer-analysis-status-lines">
            <div className="peer-analysis-status-text">
              {
                current.messages[
                  tick %
                    current.messages.length
                ]
              }
            </div>

            {liveTracks.map((track) => (
              <div
                key={track.id}
                className="peer-analysis-status-text secondary"
              >
                {
                  track.messages[
                    tick %
                      track.messages.length
                  ]
                }
              </div>
            ))}
          </div>
        </div>

        <div className="peer-analysis-note">
          {note}
        </div>
      </div>
    </div>
  );
};

export default PeerAnalysisLoader;
