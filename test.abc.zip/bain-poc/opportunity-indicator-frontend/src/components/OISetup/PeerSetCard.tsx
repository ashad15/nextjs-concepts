import { useState } from "react";

import { peerCriteria } from "../../data/peerCriteria";

interface PeerSetCardProps {
  visible: boolean;

  /* Both selections are owned by the workflow layout, not by this card. The
     assistant can set either of them on request, and a card holding its own
     copy would keep showing the old choice after it did. */
  selectedPeerSet: PeerSetType;

  /** Ticked comparability criteria, by id. Sent to the API as basic_metrics. */
  selectedCriteria: string[];

  onPeerSetChange: (
    peerSet: PeerSetType
  ) => void;

  onCriteriaChange: (
    criteriaIds: string[]
  ) => void;
}

export type PeerSetType =
  | "standard"
  | "tight"
  | "broad";

const peerSetOptions = [
  {
    id: "standard" as PeerSetType,
    title: "Standard",
    count: "~7 peers",
    recommended: true,
    description:
      "A focused set of the closest comparables. Best for most cases.",
    detail:
      "Direct competitors matched on business model, revenue scale and regional footprint. The application proposes the set and you confirm.",
  },
  {
    id: "tight" as PeerSetType,
    title: "Tight",
    count: "~4–5 peers",
    recommended: false,
    description:
      "Only the most direct competitors in the same space.",
    detail:
      "The narrowest read — pure-play competitors only, filtering out diversified or adjacent players. Use this when you want a strict like-for-like comparison.",
  },
  {
    id: "broad" as PeerSetType,
    title: "Broad",
    count: "~10–12 peers",
    recommended: false,
    description:
      "Direct competitors plus best-in-class benchmarks from adjacent sectors.",
    detail:
      "Widens the comparison to include best-in-class operators outside the immediate space so you can benchmark against the frontier, not just direct rivals.",
  },
];

const PeerSetCard = ({
  visible,
  selectedPeerSet,
  selectedCriteria,
  onPeerSetChange,
  onCriteriaChange,
}: PeerSetCardProps) => {
  /* Purely presentational, so it stays local: which option has its "View more"
     blurb open is not something the assistant or the API ever needs to know. */
  const [expandedPeerSet, setExpandedPeerSet] =
    useState<PeerSetType | null>(null);

  if (!visible) {
    return null;
  }

  const handlePeerSetSelect = (
    peerSet: PeerSetType
  ) => {
    onPeerSetChange(peerSet);
  };

  const toggleCriteria = (criterionId: string) => {
    const next = selectedCriteria.includes(
      criterionId
    )
      ? selectedCriteria.filter(
          (item) => item !== criterionId
        )
      : [...selectedCriteria, criterionId];

    onCriteriaChange(next);
  };

  const toggleDetails = (
    peerSetId: PeerSetType
  ) => {
    setExpandedPeerSet((current) =>
      current === peerSetId
        ? null
        : peerSetId
    );
  };

  return (
    <section className="setup-card">
      <div className="setup-card-header">
        <div className="setup-card-step">
          4
        </div>

        <div className="setup-card-heading">
          <div className="setup-card-title">
            Peer set
          </div>

          <div className="setup-card-subtitle">
            How broad a comparison do you want?
            You can fine-tune the exact peers on
            the next step.
          </div>
        </div>
      </div>

      <div className="setup-card-body">
        <div className="peer-set-options">
          {peerSetOptions.map((option) => {
            const selected =
              selectedPeerSet === option.id;

            const expanded =
              expandedPeerSet === option.id;

            return (
              <div
                key={option.id}
                className={`peer-set-option ${
                  selected ? "selected" : ""
                }`}
                onClick={() =>
                  handlePeerSetSelect(
                    option.id
                  )
                }
              >
                <div className="peer-set-radio">
                  <div className="peer-set-radio-dot" />
                </div>

                <div className="peer-set-content">
                  <div className="peer-set-title-row">
                    <span className="peer-set-title">
                      {option.title}
                    </span>

                    {option.recommended && (
                      <span className="peer-set-recommended">
                        Recommended
                      </span>
                    )}

                    <span className="peer-set-count">
                      {option.count}
                    </span>
                  </div>

                  <div className="peer-set-description">
                    {option.description}
                  </div>

                  <button
                    type="button"
                    className="peer-set-more"
                    onClick={(event) => {
                      event.stopPropagation();

                      toggleDetails(
                        option.id
                      );
                    }}
                  >
                    {expanded
                      ? "View less"
                      : "View more"}
                  </button>

                  {expanded && (
                    <div className="peer-set-detail">
                      {option.detail}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="peer-criteria-section">
          <div className="peer-criteria-title">
            What matters most for comparability?

            <span className="peer-criteria-subtitle">
              The criteria the application will
              weigh when scoring peers — you'll see
              each peer's score on the next step.
            </span>
          </div>

          <div className="peer-criteria-options">
            {peerCriteria.map((criterion) => {
              const selected =
                selectedCriteria.includes(
                  criterion.id
                );

              return (
                <button
                  key={criterion.id}
                  type="button"
                  className={`peer-criteria-chip ${
                    selected ? "selected" : ""
                  }`}
                  aria-pressed={selected}
                  onClick={() =>
                    toggleCriteria(
                      criterion.id
                    )
                  }
                >
                  {criterion.label}
                </button>
              );
            })}
          </div>

          {selectedCriteria.length === 0 && (
            <div className="peer-criteria-empty">
              Pick at least one criterion — it is
              the whole basis for scoring peers.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default PeerSetCard;