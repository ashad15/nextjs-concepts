interface SetupStepperProps {
  currentStep?: number;

  /** How many peers came back, once they have. Null before a proposal. */
  proposedPeers?: number | null;
}

/* The step whose sub-line is replaced by the proposal count once there is one. */
const PEERS_STEP = 1;

const steps = [
  {
    number: "01",
    name: "Target",
    sub: "Name the company to begin",
  },
  {
    number: "02",
    name: "Peers",
    sub: "Unlocks after target",
  },
  {
    number: "03",
    name: "Case for change",
    sub: "Unlocks after peers",
  },
  {
    number: "04",
    name: "Analysis",
    sub: "Unlocks after peers",
  },
  {
    number: "05",
    name: "Output",
    sub: "Deck · export",
  },
];

const SetupStepper = ({
  currentStep = 0,
  proposedPeers = null,
}: SetupStepperProps) => {
  return (
    <div className="setup-stepper">
      <div className="setup-stepper-row">
        {steps.map((step, index) => {
          const isDone = index < currentStep;
          const isActive = index === currentStep;
          const isLocked = index > currentStep;

          const stateClass = isDone
            ? "step-done"
            : isActive
              ? "step-active"
              : isLocked
                ? "step-locked"
                : "";

          /* The count replaces this step's static sub-line. A proposal can
             exist while the step is still ahead of the cursor, which is the
             case on the setup screen after coming back from peers. */
          const showsCount = Boolean(
            index === PEERS_STEP && proposedPeers,
          );

          return (
            <div
              key={step.number}
              className="stepper-group"
            >
              <div
                className={`setup-step-item ${stateClass}`}
              >
                <div className="setup-step-number">
                  {step.number}
                </div>

                <div className="setup-step-name">
                  {step.name}
                  {isDone && (
                    <span className="step-check">
                      ✓
                    </span>
                  )}
                </div>

                <div
                  className={`setup-step-sub ${
                    showsCount ? "with-count" : ""
                  }`}
                >
                  {showsCount ? (
                    <>
                      <span className="step-flag">
                        ⚑
                      </span>

                      {proposedPeers} proposed
                    </>
                  ) : (
                    step.sub
                  )}
                </div>
              </div>

              {index !== steps.length - 1 && (
                <div className="setup-step-divider" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SetupStepper;