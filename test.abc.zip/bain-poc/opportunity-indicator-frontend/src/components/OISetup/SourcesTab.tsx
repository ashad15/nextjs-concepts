import { useMemo } from "react";

import SourceCard from "../Peers/SourceCard";

import {
  countSources,
  groupSourcesByPeer,
} from "../../utils/sourceGroups";

import { confidenceLabel } from "../../utils/peerConfidence";

import { useHighlightScroll } from "../../hooks/useHighlightScroll";

import type { PeerRecommendationResponse } from "../../types/peer";

interface SourcesTabProps {
  recommendation: PeerRecommendationResponse | null;

  /** The peer under the cursor on the left, matched against a group id. */
  highlightedPeerId: string | null;
}

/**
 * Every page the agent read, grouped under the peer it was read for.
 *
 * Grouping by peer rather than listing flat is what makes the tab answerable:
 * the question in the room is "what is behind this peer", and the confidence
 * band sits on the group so the evidence and the score are read together.
 */
const SourcesTab = ({
  recommendation,
  highlightedPeerId,
}: SourcesTabProps) => {
  const groups = useMemo(
    () =>
      recommendation
        ? groupSourcesByPeer(recommendation)
        : [],
    [recommendation],
  );

  const total = countSources(groups);

  const scrollRef = useHighlightScroll(
    highlightedPeerId,
  );

  if (total === 0) {
    return (
      <div className="assistant-tab-content">
        <p className="oi-sources-empty">
          {recommendation
            ? "The peers in this run were matched from the internal set, so there are no external pages to cite."
            : "No sources yet. Propose peers and every page the agent reads will be listed here, grouped by peer."}
        </p>
      </div>
    );
  }

  return (
    <div className="assistant-tab-content" ref={scrollRef}>
      <h3 className="oi-sources-heading">
        {total} active {total === 1 ? "source" : "sources"}
      </h3>

      {groups.map((group) => (
        <section
          className="oi-source-group"
          key={group.id}
          data-group={group.id}
          data-highlighted={group.id === highlightedPeerId}
        >
          <header className="oi-source-group-head">
            <span className="oi-source-group-name">
              {group.title}
            </span>

            {group.confidence && (
              <span
                className={`oi-source-confidence ${group.confidence}`}
              >
                {confidenceLabel[group.confidence]}
              </span>
            )}

            <span className="oi-source-group-count">
              {group.sources.length}
            </span>
          </header>

          {group.note && (
            <p className="oi-source-group-note">{group.note}</p>
          )}

          <div className="oi-source-group-list">
            {group.sources.map((source) => (
              <SourceCard key={source.url} source={source} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default SourcesTab;
