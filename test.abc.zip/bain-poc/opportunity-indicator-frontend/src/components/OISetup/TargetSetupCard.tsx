import { useMemo, useState } from "react";

import {
  companies,
  type Company,
} from "../../data/companies";

interface TargetSetupCardProps {
  onResolved: (company: Company) => void;

  /* The named target, owned by the workflow layout. A prop rather than local
     state because the assistant can name the target too, and a card holding its
     own copy would keep showing the search box while the rest of the workflow
     had already moved on. */
  resolved: Company | null;

  onRemove: () => void;
}

const TargetSetupCard = ({
  onResolved,
  resolved: resolvedCompany,
  onRemove,
}: TargetSetupCardProps) => {
  const [search, setSearch] = useState("");

  const [selectedCompany, setSelectedCompany] =
    useState<Company | null>(null);

  const [showResults, setShowResults] =
    useState(false);

  const filteredCompanies = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return companies;
    }

    return companies.filter((company) => {
      return (
        company.name
          .toLowerCase()
          .includes(query) ||
        company.ticker
          .toLowerCase()
          .includes(query) ||
        company.capId
          .toLowerCase()
          .includes(query)
      );
    });
  }, [search]);

  const getCompanyInitial = (
    companyName: string
  ) => {
    return companyName
      .trim()
      .charAt(0)
      .toUpperCase();
  };

  const handleSelectCompany = (
    company: Company
  ) => {
    setSelectedCompany(company);

    // Search box me sirf company name visible rahega
    setSearch(company.name);

    setShowResults(false);
  };

  const handleResolve = () => {
    if (!selectedCompany) {
      return;
    }

    setShowResults(false);

    // Complete company object parent ko bhej rahe hain.
    // Peer recommendation API ke liye capId,
    // ticker, name etc. available rahenge.
    onResolved(selectedCompany);
  };

  const handleRemoveResolvedCompany = () => {
    setSelectedCompany(null);
    setSearch("");
    setShowResults(false);

    onRemove();
  };

  return (
    <section className="setup-card target-setup-card">
      <div className="setup-card-header">
        <div className="setup-card-step">
          {resolvedCompany ? "✓" : "1"}
        </div>

        <div className="setup-card-heading">
          <div className="setup-card-title">
            Name your target
          </div>

          <div className="setup-card-subtitle">
            Search by company name, ticker or Capital IQ ID.
          </div>
        </div>
      </div>

      <div className="setup-card-body">
        {!resolvedCompany ? (
          <>
            <div className="target-search-wrapper">
              <div className="target-search-row">
                <input
                  type="text"
                  value={search}
                  placeholder="Search company, ticker or Cap ID..."
                  onFocus={() =>
                    setShowResults(true)
                  }
                  onChange={(event) => {
                    setSearch(
                      event.target.value
                    );

                    setSelectedCompany(null);

                    setShowResults(true);
                  }}
                />

                <button
                  type="button"
                  disabled={!selectedCompany}
                  onClick={handleResolve}
                >
                  Resolve →
                </button>
              </div>

              {showResults && (
                <div className="target-search-results">
                  {filteredCompanies.length > 0 ? (
                    filteredCompanies.map(
                      (company) => (
                        <button
                          type="button"
                          key={company.capId}
                          className="target-search-option"
                          onClick={() =>
                            handleSelectCompany(
                              company
                            )
                          }
                        >
                          <div className="target-search-company">
                            {company.name}
                          </div>
                        </button>
                      )
                    )
                  ) : (
                    <div className="target-search-empty">
                      No company found
                    </div>
                  )}
                </div>
              )}
            </div>

            {selectedCompany && (
              <div className="target-selection-hint">
                Selected:{" "}
                <strong>
                  {selectedCompany.name}
                </strong>
              </div>
            )}
          </>
        ) : (
          <div className="resolved-company-card">
            {/* COMPANY INITIAL */}

            <div className="resolved-company-logo">
              {getCompanyInitial(
                resolvedCompany.name
              )}
            </div>

            {/* COMPANY DETAILS */}

            <div className="resolved-company-content">
              <div className="resolved-company-name-row">
                <div className="resolved-company-name">
                  {resolvedCompany.name}
                </div>

                <div
                  className="resolved-company-check"
                  title="Company resolved"
                >
                  ✓
                </div>
              </div>

              <div className="resolved-company-metadata">
                {/* PUBLIC / PRIVATE */}

                <span
                  className={`resolved-company-status ${
                    resolvedCompany.isPublic
                      ? "public"
                      : "private"
                  }`}
                >
                  <span className="resolved-company-status-dot" />

                  {resolvedCompany.isPublic
                    ? "Public"
                    : "Private"}
                </span>

                {/* TICKER */}

                <span className="resolved-company-ticker">
                  {resolvedCompany.ticker}
                </span>

                {/* SECTOR + INDUSTRY */}

                <span className="resolved-company-classification">
                  {resolvedCompany.sector}
                  {" · "}
                  {resolvedCompany.industry}
                </span>
              </div>
            </div>

            {/* REMOVE / CHANGE TARGET */}

            <button
              type="button"
              className="resolved-company-remove"
              onClick={
                handleRemoveResolvedCompany
              }
              aria-label="Change target company"
              title="Change target company"
            >
              ×
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default TargetSetupCard;