interface AIRecommendationsProps {
  visible?: boolean;
}

const AIRecommendations = ({
  visible = true,
}: AIRecommendationsProps) => {
  if (!visible) {
    return null;
  }

  return (
    <div className="ai-recommendations">
      <div className="ai-recommendations-header">
        <span className="ai-recommendations-badge">
          AI
        </span>

        <strong>
          Peer recommendation logic
        </strong>
      </div>

      <p>
        Peer recommendations will combine company data,
        comparability criteria and AI guidance. For this
        PoC, the proposed peer set is using mock data.
      </p>
    </div>
  );
};

export default AIRecommendations;