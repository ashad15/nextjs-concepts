import { useState } from "react";

import CandidateMetrics from "./CandidateMetrics";
import PeerCard from "./PeerCard";

import { peerSourceLabel } from "../../utils/peerSource";

/** One row in the add-peer sheet, whichever list it came from.
 *
 * `considered` peers were ranked by the agent against the same criteria as the
 * set on screen and did not make the cut; the reason is the rerank's own words.
 * `list` peers are the internal universe, never assessed against this target,
 * which is why they carry no reason.
 */
export interface AddCandidate {
  id: string;
  name: string;
  ticker: string;
  reason: string;
  origin: "considered" | "list";

  /** Only where we hold the company in the internal set. */
  sector?: string;
  capId?: string | null;

  /** The rerank's score for a candidate it assessed and left out. */
  finalScore?: number | null;

  /** Pages read for this company during the run, if it was researched. */
  pageCount?: number;

  /** The group to open in the Sources tab, when the run read anything. */
  sourceGroupId?: string | null;

  /* Which route produced the company: our own set, the agent's search, or
     both. A peer added by hand still came from somewhere, and that is worth
     as much on the tile afterwards as it is here. */
  recommendedBy?: string;
}

interface AddPeerSheetProps {
  query: string;
  onQueryChange: (query: string) => void;

  considered: AddCandidate[];
  available: AddCandidate[];

  /** Adds in one action. There is no separate confirm step. */
  onAdd: (candidate: AddCandidate) => void;

  /** Open this group in the Sources tab, so the pages can be read. */
  onShowSources: (groupId: string) => void;

  onClose: () => void;
}

/* Two letters is enough to make a row findable by shape while scrolling, and
   it beats a favicon we would have to fetch for a company we may not hold. */
const initials = (name: string) =>
  name
    .split(/\s+/)
    .map((word) => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

const SearchIcon = () => (
  <svg
    width="18"
    height="18"
    viewBox="0 0 18 18"
    fill="none"
    aria-hidden="true"
  >
    <circle
      cx="7.5"
      cy="7.5"
      r="6"
      stroke="currentColor"
      strokeWidth="1.6"
    />
    <path
      d="M13 13l3 3"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
  </svg>
);

const CandidateRow = ({
  candidate,
  active,
  onActivate,
  onAdd,
  onShowSources,
}: {
  candidate: AddCandidate;
  active: boolean;
  onActivate: () => void;
  onAdd: () => void;
  onShowSources: () => void;
}) => {
  const source = peerSourceLabel(
    candidate.recommendedBy,
  );

  const meta = [
    candidate.ticker,
    candidate.sector,
  ].filter(Boolean);

  const pages =
    candidate.sourceGroupId &&
    (candidate.pageCount ?? 0) > 0;

  return (
    <PeerCard
      active={active}
      onClick={onAdd}
      onMouseEnter={onActivate}
      role="option"
      ariaSelected={active}
      thumbnail={
        <span className="peer-add-initials">
          {initials(candidate.name)}
        </span>
      }
      title={candidate.name}
      meta={
        meta.length > 0
          ? meta.join(" · ")
          : undefined
      }
      tags={
        source && (
          <span
            className={`peer-add-tag ${source.kind}`}
          >
            {source.label}
          </span>
        )
      }
      /* Rendered only on the active card. Hiding it with opacity left its
         box behind, so a closed card sat taller than its neighbour for a
         button nobody could see. */
      action={
        active ? (
          <button
            type="button"
            className="peer-add-row-add"
            onClick={(event) => {
              event.stopPropagation();
              onAdd();
            }}
            tabIndex={-1}
          >
            Add
          </button>
        ) : undefined
      }
      /* Everything below opens on the active card only. Closed, the sheet
         stays a scannable list of names; the detail is one hover away for the
         company actually being weighed. */
      body={
        active &&
        (candidate.reason || candidate.capId) ? (
          <>
            {candidate.reason && (
              <p className="peer-add-row-reason">
                {candidate.reason}
              </p>
            )}

            <CandidateMetrics
              capId={candidate.capId ?? null}
              limit={4}
            />
          </>
        ) : undefined
      }
      footer={
        active &&
        (pages ||
          typeof candidate.finalScore ===
            "number") ? (
          <>
            {pages ? (
              <button
                type="button"
                className="peer-add-row-pages"
                onClick={(event) => {
                  event.stopPropagation();
                  onShowSources();
                }}
              >
                Read the {candidate.pageCount} pages
                <span aria-hidden="true"> →</span>
              </button>
            ) : (
              <span />
            )}

            {typeof candidate.finalScore ===
              "number" && (
              <span className="peer-add-score">
                Scored{" "}
                <strong>
                  {candidate.finalScore.toFixed(1)}
                </strong>{" "}
                / 10 against this target
              </span>
            )}
          </>
        ) : undefined
      }
    />
  );
};

/**
 * Adding a peer back to the set.
 *
 * A spotlight rather than a form: type to narrow, arrow keys to move, Return
 * to add. One action, because choosing a company and then confirming the
 * choice is two decisions where there is only one.
 *
 * Two lists, deliberately separated. The agent ranked the first against this
 * target and left each one out for a stated reason, so putting one back is an
 * informed decision and the reason travels with it. The second is the internal
 * universe, which this run never assessed, so it makes no claim at all.
 */
const AddPeerSheet = ({
  query,
  onQueryChange,
  considered,
  available,
  onAdd,
  onShowSources,
  onClose,
}: AddPeerSheetProps) => {
  const rows = [...considered, ...available];

  /* Keyboard and hover drive the same thing, so a reader who starts typing and
     a reader who reaches for the mouse never disagree about which row is
     open. */
  const [activeId, setActiveId] = useState<
    string | null
  >(null);

  const active =
    rows.find((row) => row.id === activeId) ??
    rows[0] ??
    null;

  const move = (step: number) => {
    if (rows.length === 0) {
      return;
    }

    const at = rows.findIndex(
      (row) => row.id === active?.id,
    );

    const next =
      (at + step + rows.length) % rows.length;

    setActiveId(rows[next].id);
  };

  const onKeyDown = (
    event: React.KeyboardEvent,
  ) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      move(1);
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      move(-1);
    }

    if (event.key === "Enter" && active) {
      onAdd(active);
    }

    if (event.key === "Escape") {
      onClose();
    }
  };

  const rowProps = (candidate: AddCandidate) => ({
    candidate,
    active: active?.id === candidate.id,
    onActivate: () => setActiveId(candidate.id),
    onAdd: () => onAdd(candidate),
    onShowSources: () =>
      candidate.sourceGroupId &&
      onShowSources(candidate.sourceGroupId),
  });

  return (
    <div
      className="peer-add-overlay"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="peer-add-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Add a peer"
        onClick={(event) =>
          event.stopPropagation()
        }
      >
        <div className="peer-add-header">
          <span
            className="peer-add-search-icon"
            aria-hidden="true"
          >
            <SearchIcon />
          </span>

          <input
            autoFocus
            type="text"
            className="peer-add-input"
            value={query}
            onChange={(event) =>
              onQueryChange(event.target.value)
            }
            onKeyDown={onKeyDown}
            placeholder="Search company name or ticker..."
          />

          <button
            type="button"
            className="peer-add-close"
            onClick={onClose}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div
          className="peer-add-body"
          role="listbox"
          aria-label="Candidates"
        >
          {considered.length > 0 && (
            <>
              <div className="peer-add-group-head">
                <span className="peer-add-group-title">
                  Agent considered, not selected
                </span>

                <span className="peer-add-group-count">
                  {considered.length}
                </span>
              </div>

              {considered.map((candidate) => (
                <CandidateRow
                  key={candidate.id}
                  {...rowProps(candidate)}
                />
              ))}
            </>
          )}

          {available.length > 0 && (
            <>
              {considered.length > 0 && (
                <div className="peer-add-divider" />
              )}

              <div className="peer-add-group-head">
                <span className="peer-add-group-title">
                  Also on the longlist
                </span>

                <span className="peer-add-group-count">
                  {available.length}
                </span>
              </div>

              {available.map((candidate) => (
                <CandidateRow
                  key={candidate.id}
                  {...rowProps(candidate)}
                />
              ))}
            </>
          )}

          {rows.length === 0 && (
            <p className="peer-add-empty">
              {query
                ? `Nothing matching "${query}".`
                : "Every company in the set is either a peer already or has been added back."}
            </p>
          )}
        </div>

        <div className="peer-add-footer">
          <span className="peer-add-footer-hint">
            Return to add
            <span className="peer-add-footer-sep">
              ·
            </span>
            Esc to close
          </span>

          <span className="peer-add-footer-hint">
            {rows.length}{" "}
            {rows.length === 1
              ? "candidate"
              : "candidates"}
          </span>
        </div>
      </div>
    </div>
  );
};

export default AddPeerSheet;
