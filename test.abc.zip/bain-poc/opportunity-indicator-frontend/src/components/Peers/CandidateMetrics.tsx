import { useEffect, useState } from "react";

import { getCompany } from "../../services/peerApi";

import { internalFigures } from "../../utils/internalMetrics";

interface CandidateMetricsProps {
  /** Null for a company we do not hold, which has no internal row to read. */
  capId: string | null;

  /** How many headline figures to show. */
  limit?: number;
}

/**
 * The internal figures for a candidate the run turned down.
 *
 * These are Capital IQ rows we already hold, not research: a rejected peer was
 * never researched, so without this the only thing on screen about it is the
 * sentence explaining the rejection. Fetched when the row opens rather than
 * for the whole list, since it is one request per company and most rows are
 * never opened.
 */
const CandidateMetrics = ({
  capId,
  limit,
}: CandidateMetricsProps) => {
  const [row, setRow] = useState<Record<
    string,
    unknown
  > | null>(null);

  const [failed, setFailed] = useState(false);

  /* One row is open at a time, so this component unmounts when the reader
     moves to another candidate and its state resets with it. No loading flag
     for that reason: not yet answered and not failed is the whole of it.
     Delayed, so sweeping the list with the cursor does not fire a request per
     row it passes over. */
  useEffect(() => {
    if (!capId) {
      return;
    }

    let active = true;

    const timer = window.setTimeout(() => {
      getCompany(capId)
        .then((company) => {
          if (active) {
            setRow(company);
          }
        })
        .catch(() => {
          if (active) {
            setFailed(true);
          }
        });
    }, 180);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [capId]);

  if (!capId || failed) {
    return null;
  }

  const figures = internalFigures(row, limit);

  if (figures.length === 0) {
    return null;
  }

  return (
    <span className="peer-add-metrics">
      {figures.map((figure) => (
        <span
          key={figure.column}
          className="peer-add-metric"
        >
          <span className="peer-add-metric-label">
            {figure.label}
          </span>

          <span className="peer-add-metric-value">
            {figure.display}
          </span>
        </span>
      ))}
    </span>
  );
};

export default CandidateMetrics;
