import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

import type {
  PeerRecommendationResponse,
  PeerSource,
} from "../../types/peer";

import {
  auditRun,
  type AuditedMetric,
  type PeerAudit,
} from "../../utils/metricAudit";

import {
  formatFigure,
  metricLabel,
} from "../../utils/metricFormat";

import { sourceHost } from "../../utils/sourceUrl";

import Formula from "./Formula";
import SourceDetail from "./SourceDetail";

import "../../styles/DataAudit.css";

interface DataAuditProps {
  recommendation: PeerRecommendationResponse;
  onClose: () => void;
}

/** A row per figure, saying where the number came from. */
const MetricRow = ({
  metric,
  entry,
  onOpenSource,
}: AuditedMetric & {
  onOpenSource?: () => void;
}) => (
  <li className="audit-row">
    <span className="audit-row-name">
      {metricLabel(metric)}
    </span>

    <span className="audit-row-value">
      {formatFigure(entry.value, entry.unit)}
    </span>

    <span className="audit-row-basis">
      {entry.origin === "web" && (
        <>
          {entry.period && (
            <span className="audit-period">
              {entry.period}
            </span>
          )}

          {entry.sourceUrl ? (
            <button
              className="audit-source-link"
              onClick={onOpenSource}
              type="button"
            >
              {entry.sourceName ??
                sourceHost(entry.sourceUrl)}
            </button>
          ) : (
            <span className="audit-muted">
              source not recorded
            </span>
          )}
        </>
      )}

      {entry.origin === "computed" && (
        <span className="audit-formula">
          <Formula
            latex={entry.formulaLatex}
            words={
              entry.formula ??
              /* A run from before formulas were recorded. Name the inputs by
                 what they hold rather than by their column names, which are
                 misleading for three of them. */
              `From ${entry.inputs
                .map(metricLabel)
                .join(" and ")}`
            }
          />
        </span>
      )}

      {entry.origin === "modelled" && (
        <span className="audit-method">
          {entry.method ?? "Modelled"}
        </span>
      )}
    </span>
  </li>
);

/** What identifies a peer in the open/closed set. */
const peerKey = (audit: PeerAudit) =>
  audit.peer.ticker || audit.peer.companyName;

/**
 * One peer, collapsed until asked for.
 *
 * Seven peers of twenty-odd figures each is more than a screen, and the reader
 * usually arrives wanting one of them. Closed, the headers are a contents page
 * that still carries the counts, so the shape of the run is legible without
 * opening anything.
 */
const PeerBlock = ({
  audit,
  open,
  onToggle,
  onOpenSource,
}: {
  audit: PeerAudit;
  open: boolean;
  onToggle: (open: boolean) => void;
  onOpenSource: (url: string) => void;
}) => {
  const { peer } = audit;

  const total =
    audit.sourced.length +
    audit.computed.length +
    audit.modelled.length;

  return (
    <details
      className="audit-peer"
      open={open}
      onToggle={(event) =>
        onToggle(event.currentTarget.open)
      }
    >
      <summary className="audit-peer-head">
        <span
          className="audit-chevron"
          aria-hidden="true"
        />

        <h3 className="audit-peer-name">
          {peer.companyName}
        </h3>

        {total === 0 ? (
          <span className="audit-peer-tag">
            Internal data
          </span>
        ) : (
          <span className="audit-peer-counts">
            {audit.sourced.length} sourced
            <span className="audit-sep">·</span>
            {audit.computed.length} computed
            {audit.modelled.length > 0 && (
              <>
                <span className="audit-sep">·</span>
                {audit.modelled.length} modelled
              </>
            )}
            {audit.pageCount > 0 && (
              <>
                <span className="audit-sep">·</span>
                {audit.pageCount} pages
              </>
            )}
          </span>
        )}
      </summary>

      <div className="audit-peer-body">
        {total === 0 && (
          <p className="audit-peer-empty">
            Figures come from the curated company set, not from research, so
            there is nothing to trace here.
          </p>
        )}

        {audit.sourced.length > 0 && (
          <div className="audit-group">
            <h4 className="audit-group-title">
              Read from a page
            </h4>

            <ul className="audit-list">
              {audit.sourced.map((item) => (
                <MetricRow
                  key={item.metric}
                  {...item}
                  onOpenSource={() =>
                    item.entry.sourceUrl &&
                    onOpenSource(item.entry.sourceUrl)
                  }
                />
              ))}
            </ul>
          </div>
        )}

        {audit.computed.length > 0 && (
          <div className="audit-group">
            <h4 className="audit-group-title">
              Calculated from the figures above
            </h4>

            <ul className="audit-list">
              {audit.computed.map((item) => (
                <MetricRow key={item.metric} {...item} />
              ))}
            </ul>
          </div>
        )}

        {audit.modelled.length > 0 && (
          <div className="audit-group">
            <h4 className="audit-group-title">
              Assumptions, not measurements
            </h4>

            <p className="audit-group-note">
              Nobody publishes these. Every input is shown, so the number can
              be recomputed and the assumption argued with. That is what
              separates it from a figure with no method behind it.
            </p>

            <ul className="audit-list">
              {audit.modelled.map((item) => (
                <MetricRow key={item.metric} {...item} />
              ))}
            </ul>
          </div>
        )}

        {audit.missing.length > 0 && (
          <p className="audit-missing">
            <span className="audit-missing-label">
              Not found ({audit.missing.length}):
            </span>{" "}
            {audit.missing
              .map(metricLabel)
              .join(", ")}
          </p>
        )}
      </div>
    </details>
  );
};

/**
 * Where every number on the screen came from.
 *
 * A partner who cannot trace a figure will not use the tool, so this is the
 * screen that has to hold up: each figure is either read off a named page,
 * calculated from figures that were, or modelled by a method stated in full.
 * Anything that was asked for and not found is listed by name rather than
 * quietly omitted, because a visible gap is worth more than a confident one.
 */
const DataAudit = ({
  recommendation,
  onClose,
}: DataAuditProps) => {
  const closeRef = useRef<HTMLButtonElement>(null);

  const [openSource, setOpenSource] =
    useState<PeerSource | null>(null);

  /* Which peers are expanded. Everything starts closed, so the panel opens on
     a list of peers rather than in the middle of the first one's figures. */
  const [openPeers, setOpenPeers] = useState<
    Set<string>
  >(() => new Set());

  const audit = auditRun(
    recommendation.rankedPeers,
    recommendation.sources,
  );

  const allOpen =
    openPeers.size === audit.peers.length;

  const togglePeer = (key: string, open: boolean) =>
    setOpenPeers((current) => {
      const next = new Set(current);

      if (open) {
        next.add(key);
      } else {
        next.delete(key);
      }

      return next;
    });

  const toggleAll = () =>
    setOpenPeers(
      allOpen
        ? new Set()
        : new Set(audit.peers.map(peerKey)),
    );

  /* Every page seen in the run, so a figure's source can be opened with the
     same passage and evidence the source cards show. */
  const sourceByUrl = new Map<string, PeerSource>();

  for (const source of recommendation.sources) {
    sourceByUrl.set(source.url, source);
  }

  for (const peer of recommendation.rankedPeers) {
    for (const source of peer.sources) {
      sourceByUrl.set(source.url, source);
    }
  }

  useEffect(() => {
    closeRef.current?.focus();

    const onKey = (event: KeyboardEvent) => {
      /* Only the top layer closes: a source opened from here sits above. */
      if (event.key === "Escape" && !openSource) {
        onClose();
      }
    };

    document.addEventListener("keydown", onKey);

    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
    };
  }, [onClose, openSource]);

  return createPortal(
    <>
      <div
        className="audit-backdrop"
        onClick={onClose}
        role="presentation"
      >
        <div
          className="audit-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="audit-title"
          onClick={(event) => event.stopPropagation()}
        >
          <button
            ref={closeRef}
            className="audit-close"
            onClick={onClose}
            aria-label="Close"
            type="button"
          >
            ✕
          </button>

          <header className="audit-head">
            <h2 id="audit-title" className="audit-title">
              Where these numbers came from
            </h2>

            <p className="audit-sub">
              Every figure is read from a named page, calculated from figures
              that were, or modelled by a stated method. Nothing is estimated.
              {audit.researched < audit.peers.length && (
                <>
                  {" "}
                  The remaining{" "}
                  {audit.peers.length - audit.researched} came from the
                  curated company set, so their figures are internal data
                  rather than research.
                </>
              )}
            </p>

            <div className="audit-stats">
              <span className="audit-stat">
                <strong>{audit.metricsCompared}</strong>
                figures
              </span>

              <span className="audit-stat">
                <strong>
                  {audit.researched} of{" "}
                  {audit.peers.length}
                </strong>
                peers researched
              </span>

              <span className="audit-stat">
                <strong>{audit.sourcesSearched}</strong>
                pages read
              </span>

              <span className="audit-stat">
                <strong>{audit.documentsRetrieved}</strong>
                filings found
              </span>

              <button
                className="audit-expand"
                onClick={toggleAll}
                type="button"
              >
                {allOpen
                  ? "Collapse all"
                  : "Expand all"}
              </button>
            </div>
          </header>

          <div className="audit-body">
            {audit.peers.map((peerAudit) => (
              <PeerBlock
                key={peerKey(peerAudit)}
                audit={peerAudit}
                open={openPeers.has(
                  peerKey(peerAudit),
                )}
                onToggle={(open) =>
                  togglePeer(
                    peerKey(peerAudit),
                    open,
                  )
                }
                onOpenSource={(url) =>
                  setOpenSource(
                    sourceByUrl.get(url) ?? null,
                  )
                }
              />
            ))}
          </div>

          <footer className="audit-actions">
            <button
              className="audit-dismiss"
              onClick={onClose}
              type="button"
            >
              Close
            </button>
          </footer>
        </div>
      </div>

      {openSource && (
        <SourceDetail
          source={openSource}
          onClose={() => setOpenSource(null)}
        />
      )}
    </>,
    document.body,
  );
};

export default DataAudit;
