import {
  documentKind,
  type DocumentKind,
} from "../../utils/documentKind";

/* Tint per kind, following the source-icon treatment in the client mockup: a
   soft rounded square, a low-saturation background, and the glyph in the
   matching hue rather than in black. */
const TINTS: Record<
  DocumentKind,
  { bg: string; fg: string }
> = {
  filing: { bg: "#f2effb", fg: "#6b4fbb" },
  report: { bg: "#f2effb", fg: "#6b4fbb" },
  pdf: { bg: "#fdf2f2", fg: "#cc0000" },
  data: { bg: "#eaf2fe", fg: "#1d6dd1" },
  other: { bg: "#f1f1f3", fg: "#636366" },
};

interface DocumentIconProps {
  url: string;
  size?: number;
}

/**
 * The crest on a primary document.
 *
 * A filing has no og:image worth fetching and its favicon is usually the
 * regulator's seal at 16px, so a drawn glyph reads better at this size than
 * anything the page can supply. Kind is inferred from the URL, which is all we
 * have and is reliable for filings.
 */
const DocumentIcon = ({
  url,
  size = 30,
}: DocumentIconProps) => {
  const kind = documentKind(url);
  const tint = TINTS[kind];

  const glyph = size * 0.47;

  return (
    <span
      className="doc-icon"
      style={{
        width: size,
        height: size,
        background: tint.bg,
        color: tint.fg,
      }}
      aria-hidden="true"
    >
      {kind === "data" ? (
        /* Bar chart: a figures page rather than a document. */
        <svg
          width={glyph}
          height={glyph}
          viewBox="0 0 14 14"
        >
          <rect x="2" y="8" width="2.4" height="4" rx="1" fill="currentColor" />
          <rect x="5.8" y="5" width="2.4" height="7" rx="1" fill="currentColor" />
          <rect x="9.6" y="2" width="2.4" height="10" rx="1" fill="currentColor" />
        </svg>
      ) : (
        /* Folded page with ruled lines: the filing or report itself. */
        <svg
          width={glyph}
          height={glyph}
          viewBox="0 0 14 14"
          fill="none"
        >
          <path
            d="M3.5 1.5h4L11 5v7.5H3.5z"
            stroke="currentColor"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
          <path
            d="M7 1.5V5h3.5M5.5 8.2h3M5.5 10.2h3"
            stroke="currentColor"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </svg>
      )}
    </span>
  );
};

export default DocumentIcon;
