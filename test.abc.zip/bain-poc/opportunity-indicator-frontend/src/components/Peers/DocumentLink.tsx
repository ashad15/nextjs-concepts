import type { PeerDocument } from "../../types/peer";

import { documentLabel } from "../../utils/documentKind";
import { sourceHost } from "../../utils/sourceUrl";

import DocumentIcon from "./DocumentIcon";

interface DocumentLinkProps {
  document: PeerDocument;
}

/**
 * One primary document, as a link out.
 *
 * Shared by the peer detail column and the filings tab so the two cannot drift:
 * a filing that reads one way beside a peer and another way in the panel is a
 * filing a reader has to reconcile.
 */
const DocumentLink = ({
  document,
}: DocumentLinkProps) => (
  <a
    className="peer-docs-item"
    href={document.url}
    target="_blank"
    rel="noopener noreferrer"
  >
    <DocumentIcon url={document.url} />

    <span className="peer-docs-main">
      <span className="peer-docs-name">
        {document.title}
      </span>

      <span className="peer-docs-meta">
        <span className="peer-docs-kind">
          {documentLabel(document.url)}
        </span>

        <span className="peer-docs-sep">·</span>

        <span className="peer-docs-host">
          {document.publisher ||
            sourceHost(document.url)}
        </span>
      </span>
    </span>

    <span
      className="peer-docs-open"
      aria-hidden="true"
    >
      ↗
    </span>
  </a>
);

export default DocumentLink;
