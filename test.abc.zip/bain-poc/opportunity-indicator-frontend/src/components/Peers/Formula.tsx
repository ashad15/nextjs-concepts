import { useEffect, useState } from "react";

import "katex/dist/katex.min.css";
import "../../styles/Formula.css";

interface FormulaProps {
  /** LaTeX for the expression, when the backend supplied one. */
  latex: string | null;

  /** The same expression in words. Always shown if the maths cannot be. */
  words: string | null;
}

/**
 * A derivation, typeset as maths where possible.
 *
 * A partner checking whether a margin is trustworthy wants to see the actual
 * quotient, not a sentence describing one. KaTeX is fetched on first use
 * rather than bundled: this only ever renders inside the audit dialog, and
 * the words are a complete answer on their own until it arrives.
 *
 * The LaTeX comes from a fixed map in our own backend, never from a page we
 * scraped, so rendering it as markup is safe. If that ever stops being true,
 * this component must stop using dangerouslySetInnerHTML.
 */
const Formula = ({ latex, words }: FormulaProps) => {
  const [html, setHtml] = useState<string | null>(null);

  useEffect(() => {
    if (!latex) {
      return;
    }

    let active = true;

    import("katex")
      .then((katex) => {
        if (!active) {
          return;
        }

        setHtml(
          katex.default.renderToString(
            /* Inline maths sets a fraction in script style, which puts the
               numerator and denominator at roughly 70% of an already small
               row and makes them unreadable. \displaystyle keeps both at full
               size while the expression stays inline in the row. */
            `\\displaystyle ${latex}`,
            {
              // A broken expression falls back to the words rather than
              // rendering an error in red where a formula should be.
              throwOnError: false,
              displayMode: false,
              output: "html",
            },
          ),
        );
      })
      .catch(() => {
        /* Words already cover it. */
      });

    return () => {
      active = false;
    };
  }, [latex]);

  if (html) {
    return (
      <span
        className="formula"
        title={words ?? undefined}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <span className="formula formula-words">
      {words}
    </span>
  );
};

export default Formula;
