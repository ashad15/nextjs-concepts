import type { ReactNode } from "react";

import "../../styles/PeerCard.css";

interface PeerCardProps {
  /** A crest, monogram or logo. Fixed width, so titles line up down a list. */
  thumbnail?: ReactNode;

  title: ReactNode;

  /** One quiet line under the title: ticker, sector, exchange. */
  meta?: ReactNode;

  /** Chips on the right of the header. Provenance, status, a score. */
  tags?: ReactNode;

  /** The single thing this card does, under the tags. */
  action?: ReactNode;

  /** Prose and figures. Ruled off from the header when present. */
  body?: ReactNode;

  /** Links and asides. Ruled off from the body when present. */
  footer?: ReactNode;

  /** Raised and separated, for the row under the cursor or the keyboard. */
  active?: boolean;

  onClick?: () => void;
  onMouseEnter?: () => void;

  role?: string;
  ariaSelected?: boolean;
}

/**
 * One company, as a card.
 *
 * Header, body, footer, with a thumbnail and one action. The zones exist so
 * that a company presented in two places is presented the same way, and so
 * that adding a figure or a chip is a matter of filling a slot rather than
 * finding room in a stack of divs. The alternative, which this replaces, was a
 * single column of text that grew a line at a time until it read as a wall.
 *
 * Layout only. Every caller decides what a company's name, tags and action
 * are, because those differ by context and the card should not guess.
 */
const PeerCard = ({
  thumbnail,
  title,
  meta,
  tags,
  action,
  body,
  footer,
  active = false,
  onClick,
  onMouseEnter,
  role,
  ariaSelected,
}: PeerCardProps) => (
  <div
    className={`peer-card ${
      active ? "active" : ""
    } ${onClick ? "clickable" : ""}`}
    onClick={onClick}
    onMouseEnter={onMouseEnter}
    role={role}
    aria-selected={ariaSelected}
  >
    <div className="peer-card-head">
      {thumbnail && (
        <div className="peer-card-thumb">
          {thumbnail}
        </div>
      )}

      <div className="peer-card-heading">
        <div className="peer-card-title">
          {title}
        </div>

        {meta && (
          <div className="peer-card-meta">
            {meta}
          </div>
        )}
      </div>

      {(tags || action) && (
        <div className="peer-card-aside">
          {tags && (
            <div className="peer-card-tags">
              {tags}
            </div>
          )}

          {action && (
            <div className="peer-card-action">
              {action}
            </div>
          )}
        </div>
      )}
    </div>

    {body && (
      <div className="peer-card-body">
        {body}
      </div>
    )}

    {footer && (
      <div className="peer-card-foot">
        {footer}
      </div>
    )}
  </div>
);

export default PeerCard;
