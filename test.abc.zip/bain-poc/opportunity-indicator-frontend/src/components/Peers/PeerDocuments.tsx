import type { PeerDocument } from "../../types/peer";

import DocumentLink from "./DocumentLink";

import "../../styles/PeerDocuments.css";

interface PeerDocumentsProps {
  documents: PeerDocument[];
}

/**
 * Annual reports and filings found for a peer, shown but never read from.
 *
 * These come from the company's own investor relations site and the filing
 * registries. Across a full run those sites produced no usable figure, because
 * they publish documents rather than tables, so they are surfaced as primary
 * material a reader may want rather than as the provenance of any number. The
 * distinction is stated on screen so nobody assumes otherwise.
 */
const PeerDocuments = ({
  documents,
}: PeerDocumentsProps) => {
  if (documents.length === 0) {
    return null;
  }

  return (
    <div className="peer-docs">
      <div className="peer-docs-head">
        <span className="peer-docs-title">
          Primary documents
        </span>

        <span className="peer-docs-count">
          {documents.length}
        </span>
      </div>

      <p className="peer-docs-note">
        Found during research. Not used for any figure above.
      </p>

      <div className="peer-docs-list">
        {documents.map((document) => (
          <DocumentLink
            key={document.url}
            document={document}
          />
        ))}
      </div>
    </div>
  );
};

export default PeerDocuments;
