interface PeerFiltersProps {
  selectedFilter: string;
  onFilterChange: (filter: string) => void;
}

const filters = [
  "All",
  "High confidence",
  "Review",
  "Manually added",
];

const PeerFilters = ({
  selectedFilter,
  onFilterChange,
}: PeerFiltersProps) => {
  return (
    <div className="peer-filters">
      {filters.map((filter) => (
        <button
          key={filter}
          type="button"
          className={`peer-filter-chip ${
            selectedFilter === filter
              ? "selected"
              : ""
          }`}
          onClick={() =>
            onFilterChange(filter)
          }
        >
          {filter}
        </button>
      ))}
    </div>
  );
};

export default PeerFilters;