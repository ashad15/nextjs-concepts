interface PeerSummaryProps {
  targetCompany: string;
  selectedCount: number;
  onAddPeer: () => void;
}

const PeerSummary = ({
  targetCompany,
  selectedCount,
  onAddPeer,
}: PeerSummaryProps) => {
  return (
    <div className="peer-summary">
      <div>
        <h1>Build your peer set</h1>

        <p>
          Proposed peers for{" "}
          <strong>
            {targetCompany || "your target company"}
          </strong>
          . Review the proposed set, remove any peer that
          does not fit, or add another company.
        </p>
      </div>

      <div className="peer-summary-actions">
        <span className="peer-selected-count">
          {selectedCount} peers selected
        </span>

        <button
          type="button"
          className="peer-add-button"
          onClick={onAddPeer}
        >
          + Add a peer
        </button>
      </div>
    </div>
  );
};

export default PeerSummary;