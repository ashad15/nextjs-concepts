import { peerSourceLabel } from "../../utils/peerSource";

export interface Peer {
  id: string;
  name: string;
  ticker: string;
  reason: string;

  confidence:
    | "high"
    | "medium"
    | "low";

  /*
   * Actual confidence percentage from API.
   * Example: 85
   */
  confidenceScore?: number;

  /*
   * Recommendation source from API.
   * Example: agent / vcc / model
   */
  recommendedBy?: string;

  selected: boolean;

  flagged?: boolean;
  manuallyAdded?: boolean;

  /*
   * Which add-peer list a manual peer came from, since the two mean different
   * things: "considered" was ranked against this target and left out, "list"
   * was never assessed at all.
   */
  addedFrom?: "considered" | "list";

  /* The internal Capital IQ row, for a manually added company we hold. */
  internalRow?: Record<string, unknown>;
}

interface PeerTableProps {
  peers: Peer[];

  onToggle: (id: string) => void;

  onOpen: (peer: Peer) => void;

  /** The tile under the cursor, or null on the way out. */
  onHover: (id: string | null) => void;
}

/* Stacked discs: the internal universe is a dataset lookup. */
const SourceDataIcon = () => (
  <svg
    viewBox="0 0 12 12"
    className="peer-tile-source-icon"
    aria-hidden="true"
  >
    <ellipse cx="6" cy="2.6" rx="4.2" ry="1.6" />
    <path d="M1.8 5.2v1.6c0 .9 1.9 1.6 4.2 1.6s4.2-.7 4.2-1.6V5.2c0 .9-1.9 1.6-4.2 1.6S1.8 6.1 1.8 5.2Z" />
    <path d="M1.8 8.2v1.2c0 .9 1.9 1.6 4.2 1.6s4.2-.7 4.2-1.6V8.2c0 .9-1.9 1.6-4.2 1.6s-4.2-.7-4.2-1.6Z" />
  </svg>
);

/* Spark: the agent went and found this one. */
const SourceAgentIcon = () => (
  <svg
    viewBox="0 0 12 12"
    className="peer-tile-source-icon"
    aria-hidden="true"
  >
    <path d="M6 .8l1.2 3.1L10.3 5 7.2 6.2 6 9.3 4.8 6.2 1.7 5l3.1-1.1L6 .8Z" />
    <path d="M9.8 8.2l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2-1.2-.5 1.2-.5.5-1.2Z" />
  </svg>
);

/* Where a peer came from: our own universe, the agent's search, or both.
   Each is labelled, because "the model suggested it", "it was already in the
   dataset" and "both found it independently" are three different claims, and
   the third is the strongest evidence of comparability a peer can carry. */
const sourceChip = (value?: string) => {
  const source = peerSourceLabel(value);

  if (!source) {
    return null;
  }

  const Icon =
    source.kind === "vcc"
      ? SourceDataIcon
      : SourceAgentIcon;

  return {
    kind: source.kind,
    label: source.label,

    /* Both routes get both marks, so the chip reads as a pair at a glance
       rather than relying on the reader parsing the label. */
    Icon:
      source.kind === "both"
        ? () => (
            <>
              <SourceDataIcon />
              <SourceAgentIcon />
            </>
          )
        : Icon,
  };
};

const PeerTable = ({
  peers,
  onToggle,
  onOpen,
  onHover,
}: PeerTableProps) => {
  return (
    <div className="peer-grid">
      {peers.map((peer) => {
        /* Shown for manual peers too. Adding a company by hand does not
           change where it came from, and "the agent found this as well" is
           worth as much on a tile the analyst chose as on one it proposed. */
        const chip = sourceChip(
          peer.recommendedBy
        );

        /* Manually added peers arrive with no score, so the bar behind the
           footer would render at zero width and the band label would sit on
           an empty strip. */
        const scored =
          typeof peer.confidenceScore ===
          "number";

        return (
          <article
            key={peer.id}
            className={[
              "peer-tile",
              !peer.selected
                ? "deselected"
                : "",
              peer.flagged
                ? "flagged"
                : "",
            ]
              .filter(Boolean)
              .join(" ")}
            onClick={() =>
              onOpen(peer)
            }
            onMouseEnter={() =>
              onHover(peer.id)
            }
            onMouseLeave={() =>
              onHover(null)
            }
          >
            {peer.manuallyAdded && (
              <span className="peer-tile-badge manual">
                Manual
              </span>
            )}

            <button
              type="button"
              className="peer-tile-check"
              onClick={(event) => {
                event.stopPropagation();

                onToggle(peer.id);
              }}
            >
              {peer.selected
                ? "✓"
                : ""}
            </button>

            <div className="peer-tile-content">
              <div className="peer-tile-name">
                {peer.name}
              </div>

              <div className="peer-tile-identity">
                <span className="peer-tile-ticker">
                  {peer.ticker}
                </span>

                {chip && (
                  <span
                    className={`peer-tile-source ${chip.kind}`}
                  >
                    <chip.Icon />
                    {chip.label}
                  </span>
                )}
              </div>

              <div className="peer-tile-reason">
                {peer.reason}
              </div>
            </div>

            <div
              className={`peer-tile-footer ${
                scored
                  ? peer.confidence
                  : "pending"
              }`}
            >
              {/* The score, as how far the bar fills the footer. Drawn
                  behind the label rather than beside it, so the whole strip
                  reads as the measure. */}
              {scored && (
                <span
                  className="peer-tile-footer-fill"
                  style={{
                    width: `${Math.max(
                      0,
                      Math.min(
                        peer.confidenceScore ??
                          0,
                        100
                      )
                    )}%`,
                  }}
                  role="img"
                  aria-label={`Confidence ${peer.confidenceScore} percent`}
                />
              )}

              <div
                className={`peer-confidence ${
                  scored
                    ? peer.confidence
                    : "pending"
                }`}
              >
                <span className="peer-confidence-dot" />

                {/* A peer with no score is not a low-confidence peer, it is
                    one nothing has scored. Saying "Low confidence" over an
                    empty bar states a judgement we never made, and which of
                    the two lists it came from is the honest answer instead. */}
                {!scored
                  ? peer.addedFrom ===
                    "considered"
                    ? "Set aside by the agent"
                    : "Not assessed"
                  : peer.confidence ===
                      "high"
                    ? "High confidence"
                    : peer.confidence ===
                        "medium"
                      ? "Medium confidence"
                      : "Low confidence"}

                {scored && (
                  <span className="peer-confidence-score">
                    ({peer.confidenceScore}%)
                  </span>
                )}
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
};

export default PeerTable;