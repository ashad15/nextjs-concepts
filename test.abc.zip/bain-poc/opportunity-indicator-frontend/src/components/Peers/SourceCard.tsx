import { useEffect, useState } from "react";

import type { PeerSource } from "../../types/peer";

import { criterionLabel } from "../../data/peerCriteria";

import {
  getLinkPreview,
  type LinkPreview,
} from "../../services/linkPreview";

import {
  sourceHost,
  sourceMonogram,
  sourcePath,
} from "../../utils/sourceUrl";

import SourceDetail from "./SourceDetail";

import "../../styles/SourceCard.css";

interface SourceCardProps {
  source: PeerSource;
}

/**
 * One cited page: thumbnail on the left, what it backed on the right.
 *
 * Opens a dialog rather than the publisher. The run keeps the passage that was
 * retrieved and the figures read from it, and sending the reader straight out
 * to the page throws all of that away and loses them to another tab. Opening
 * the original is still one click, from inside the dialog.
 *
 * Most IR and SEC pages publish no og:image, so the thumbnail degrades to the
 * site's favicon and then to a monogram.
 */
const SourceCard = ({
  source,
}: SourceCardProps) => {
  const [open, setOpen] = useState(false);

  const [preview, setPreview] =
    useState<LinkPreview | null>(null);

  const [loading, setLoading] =
    useState(true);

  /* A declared image can still 404 or be hotlink-blocked once requested. */
  const [imageFailed, setImageFailed] =
    useState(false);

  const [faviconFailed, setFaviconFailed] =
    useState(false);

  // Each card is keyed by url, so a new url means a fresh mount and no reset.
  useEffect(() => {
    let active = true;

    getLinkPreview(source.url).then(
      (result) => {
        if (!active) {
          return;
        }

        setPreview(result);
        setLoading(false);
      },
    );

    return () => {
      active = false;
    };
  }, [source.url]);

  const host = sourceHost(source.url);
  const path = sourcePath(source.url);

  const publisher =
    source.name ??
    preview?.siteName ??
    host;

  const showImage = Boolean(
    preview?.image && !imageFailed,
  );

  const showFavicon =
    !showImage &&
    Boolean(
      preview?.favicon && !faviconFailed,
    );

  const thumbKind = showImage
    ? "image"
    : showFavicon
      ? "favicon"
      : "monogram";

  /* Whatever the card managed to resolve, reused as the dialog's crest so it
     does not flash a monogram before resolving the same image again. */
  const crest = showImage
    ? preview?.image
    : showFavicon
      ? preview?.favicon
      : null;

  const figureCount = source.figures.length;

  return (
    <>
    <button
      className="peer-v3-source-card"
      onClick={() => setOpen(true)}
      type="button"
      aria-haspopup="dialog"
    >
      <div
        className="peer-v3-source-thumb"
        data-kind={thumbKind}
        data-loading={
          loading && !preview
        }
      >
        {showImage && (
          <img
            className="peer-v3-source-image"
            src={preview?.image ?? ""}
            alt=""
            loading="lazy"
            onError={() =>
              setImageFailed(true)
            }
          />
        )}

        {showFavicon && (
          <img
            className="peer-v3-source-favicon"
            src={preview?.favicon ?? ""}
            alt=""
            loading="lazy"
            onError={() =>
              setFaviconFailed(true)
            }
          />
        )}

        {!showImage &&
          !showFavicon &&
          !loading && (
            <span className="peer-v3-source-monogram">
              {sourceMonogram(host)}
            </span>
          )}
      </div>

      <div className="peer-v3-source-main">
        <div className="peer-v3-source-head">
          <span className="peer-v3-source-name">
            {publisher}
          </span>

          <span
            className="peer-v3-source-open"
            aria-hidden="true"
          >
            ↗
          </span>
        </div>

        {(source.title ?? preview?.title) && (
          <span className="peer-v3-source-title">
            {source.title ?? preview?.title}
          </span>
        )}

        {path && (
          <span className="peer-v3-source-path">
            {host}
            {path}
          </span>
        )}

        {source.usedFor.length > 0 && (
          <div className="peer-v3-source-tags">
            {source.usedFor.map(
              (criterion) => (
                <span
                  key={criterion}
                  className="peer-v3-source-tag"
                >
                  {criterionLabel(
                    criterion,
                  )}
                </span>
              ),
            )}
          </div>
        )}

        {figureCount > 0 && (
          <span className="peer-v3-source-figures">
            {figureCount}{" "}
            {figureCount === 1
              ? "figure"
              : "figures"}{" "}
            read from this page
          </span>
        )}
      </div>
    </button>

    {open && (
      <SourceDetail
        source={source}
        thumbnail={crest}
        onClose={() => setOpen(false)}
      />
    )}
    </>
  );
};

export default SourceCard;
