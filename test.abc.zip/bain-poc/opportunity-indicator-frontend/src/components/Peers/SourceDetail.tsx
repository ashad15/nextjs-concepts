import { lazy, Suspense, useEffect, useRef } from "react";
import { createPortal } from "react-dom";

import type { PeerSource } from "../../types/peer";

import { criterionLabel } from "../../data/peerCriteria";

import {
  formatFigure,
  hasMarkdownTable,
  metricLabel,
} from "../../utils/metricFormat";

import {
  sourceHost,
  sourceMonogram,
} from "../../utils/sourceUrl";

import "../../styles/SourceDetail.css";

/* The markdown renderer is most of the weight of this screen and is only ever
   needed once a dialog is actually open, so it is fetched on first open rather
   than shipped in the initial bundle. */
const SourcePassage = lazy(() => import("./SourcePassage"));

interface SourceDetailProps {
  source: PeerSource;

  /** The og:image or favicon the card already resolved, reused as the crest. */
  thumbnail?: string | null;

  onClose: () => void;
}

/**
 * What one cited page actually said, and what was taken from it.
 *
 * Opening a source used to jump straight out to the publisher, which loses the
 * reader and shows nothing about why the page mattered. The run now keeps the
 * retrieved text, the figures read off the page and the ratings it justified,
 * so all of that can be shown in place with leaving still one click away.
 *
 * Rendered through a portal: the workspace clips overflow, so a modal mounted
 * inside the detail panel would be cut off rather than centred.
 */
const SourceDetail = ({
  source,
  thumbnail,
  onClose,
}: SourceDetailProps) => {
  const closeRef = useRef<HTMLButtonElement>(null);

  const host = sourceHost(source.url);

  const publisher =
    source.name ?? source.title ?? host;

  /* Criterion keys are lowercase, metric columns are uppercase. Splitting them
     keeps "Revenue scale" out of the figures list and REVENUE out of the tags. */
  const criteria = source.usedFor.filter(
    (entry) => entry === entry.toLowerCase(),
  );

  useEffect(() => {
    closeRef.current?.focus();

    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", onKey);

    /* The page behind must not scroll while the dialog is up. */
    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";

    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
    };
  }, [onClose]);

  return createPortal(
    <div
      className="src-modal-backdrop"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="src-modal"
        /* A financials table wants columns side by side, and most passages
           are prose that reads better narrow. So the dialog sizes to what it
           is actually showing rather than splitting the difference. */
        data-wide={hasMarkdownTable(source.summary)}
        role="dialog"
        aria-modal="true"
        aria-labelledby="src-modal-title"
        onClick={(event) => event.stopPropagation()}
      >
        <button
          ref={closeRef}
          className="src-modal-close"
          onClick={onClose}
          aria-label="Close"
          type="button"
        >
          ✕
        </button>

        <header className="src-modal-head">
          <div className="src-modal-crest" aria-hidden="true">
            {thumbnail ? (
              <img src={thumbnail} alt="" />
            ) : (
              <span>{sourceMonogram(host)}</span>
            )}
          </div>

          <div className="src-modal-heading">
            <h2 id="src-modal-title" className="src-modal-title">
              {source.title ?? publisher}
            </h2>

            <p className="src-modal-sub">
              {publisher}
              <span className="src-modal-dot">·</span>
              {host}
            </p>
          </div>
        </header>

        <div className="src-modal-body">
          {source.summary ? (
            <section className="src-modal-section">
              <h3 className="src-modal-label">Passage used</h3>

              <div className="src-modal-quote">
                <Suspense
                  fallback={
                    <p className="src-modal-passage-loading">
                      {source.summary}
                    </p>
                  }
                >
                  <SourcePassage text={source.summary} />
                </Suspense>
              </div>
            </section>
          ) : (
            <p className="src-modal-note">
              This page was cited by the model but not retrieved by us, so we
              cannot show what it said. Open it to read the original.
            </p>
          )}

          {source.figures.length > 0 && (
            <section className="src-modal-section">
              <h3 className="src-modal-label">
                Figures read from this page
              </h3>

              <ul className="src-modal-figures">
                {source.figures.map((figure) => (
                  <li
                    key={figure.metric}
                    className="src-modal-figure"
                  >
                    <span className="src-modal-figure-name">
                      {metricLabel(figure.metric)}
                    </span>

                    <span className="src-modal-figure-value">
                      {formatFigure(figure.value, figure.unit)}
                    </span>

                    <span className="src-modal-figure-period">
                      {figure.period ?? "period not stated"}
                    </span>
                  </li>
                ))}
              </ul>

              <p className="src-modal-foot">
                Taken as reported. Ratios shown elsewhere are calculated from
                these, never read off a page.
              </p>
            </section>
          )}

          {source.evidence.length > 0 && (
            <section className="src-modal-section">
              <h3 className="src-modal-label">
                What it supported
              </h3>

              <ul className="src-modal-evidence">
                {source.evidence.map((item) => (
                  <li
                    key={item.criterion}
                    className="src-modal-evidence-item"
                  >
                    <div className="src-modal-evidence-head">
                      <span className="src-modal-evidence-name">
                        {criterionLabel(item.criterion)}
                      </span>

                      <span className="src-modal-evidence-score">
                        {item.score}
                        <span className="src-modal-evidence-of">
                          /100
                        </span>
                      </span>
                    </div>

                    <p className="src-modal-evidence-text">
                      {item.evidence}
                    </p>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {criteria.length > 0 &&
            source.evidence.length === 0 && (
              <div className="src-modal-tags">
                {criteria.map((criterion) => (
                  <span
                    key={criterion}
                    className="src-modal-tag"
                  >
                    {criterionLabel(criterion)}
                  </span>
                ))}
              </div>
            )}
        </div>

        <footer className="src-modal-actions">
          <a
            className="src-modal-open"
            href={source.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            Open original
            <span aria-hidden="true">↗</span>
          </a>

          <button
            className="src-modal-dismiss"
            onClick={onClose}
            type="button"
          >
            Close
          </button>
        </footer>
      </div>
    </div>,
    document.body,
  );
};

export default SourceDetail;
