import { Streamdown } from "streamdown";

import "streamdown/styles.css";
import "../../styles/SourcePassage.css";

interface SourcePassageProps {
  text: string;
}

/**
 * The retrieved passage, rendered as the markdown it actually is.
 *
 * Search providers return page text as markdown, so a financials page arrives
 * as a pipe-delimited table. Shown as plain text that reads as noise, which is
 * exactly the case where the passage matters most: the figures we extracted
 * came out of that table.
 *
 * Streamdown rather than a plain markdown renderer because these passages are
 * cut off at a character budget, so they routinely end mid-row or mid-fence.
 * It is built to parse incomplete markdown, which is the same problem streaming
 * output has, and it closes the unterminated construct instead of spilling raw
 * syntax down the page.
 */
const SourcePassage = ({
  text,
}: SourcePassageProps) => (
  <div className="src-passage">
    <Streamdown
      // Complete text, not a live stream, so no typing animation.
      mode="static"
      // Cut at a character budget, so it routinely ends mid-row or mid-fence.
      parseIncompleteMarkdown
      // Copy and download belong in a chat transcript, not an evidence panel.
      controls={false}
      // Untrusted text scraped from third-party pages. Anchors and images are
      // unwrapped to their text: the reader already has "Open original" for
      // the real page, and nothing here should navigate anywhere else.
      disallowedElements={["a", "img"]}
      unwrapDisallowed
    >
      {text}
    </Streamdown>
  </div>
);

export default SourcePassage;
