import { useEffect, useRef } from "react";

import type { Company } from "../data/companies";

interface CompanyMentionMenuProps {
  companies: Company[];
  highlighted: number;

  onHighlight: (index: number) => void;
  onChoose: (index: number) => void;
}

/**
 * The list that opens when someone types "@" in the chat.
 *
 * Sits above the input rather than below it: the input is anchored to the
 * bottom of a tall narrow panel, so a menu below would be off screen.
 */
const CompanyMentionMenu = ({
  companies,
  highlighted,
  onHighlight,
  onChoose,
}: CompanyMentionMenuProps) => {
  const activeRef = useRef<HTMLButtonElement>(null);

  /* Keep the arrow-key selection in view. The list is scrollable once it is
     longer than a few entries, and without this the highlight walks off the
     bottom while the menu stays where it was. */
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: "nearest" });
  }, [highlighted]);

  return (
    <div
      className="oi-mention-menu"
      role="listbox"
      aria-label="Companies"
    >
      {companies.map((company, index) => (
        <button
          key={company.capId}
          ref={index === highlighted ? activeRef : undefined}
          type="button"
          role="option"
          aria-selected={index === highlighted}
          className={`oi-mention-option ${
            index === highlighted ? "active" : ""
          }`}
          /* Mouse down rather than click: the textarea loses focus on mouse
             down, and by the time a click fires the caret position this menu
             was opened against is gone. */
          onMouseDown={(event) => {
            event.preventDefault();
            onChoose(index);
          }}
          onMouseEnter={() => onHighlight(index)}
        >
          <span className="oi-mention-name">
            {company.name}
          </span>

          <span className="oi-mention-meta">
            {company.ticker} · {company.sector}
          </span>
        </button>
      ))}
    </div>
  );
};

export default CompanyMentionMenu;
