import { criterionLabel } from "../data/peerCriteria";

interface ConfirmRunCardProps {
  target: string | null;
  peerSet: string;
  criteriaIds: string[];
  maxPeers: number;

  /* Undefined until the call is actually waiting on an answer. The buttons are
     rendered disabled in that window rather than hidden, so the card does not
     change shape under the cursor the moment it becomes clickable. */
  onConfirm?: () => void;
  onCancel?: () => void;

  /* Set once answered, so the card can say what was decided instead of
     vanishing and leaving the conversation with a gap in it. */
  outcome?: "confirmed" | "cancelled" | null;

  /* Why the run cannot start, in words, or null when it can. The assistant can
     call this tool before the form is filled in, and a card whose only button
     would fail is worse than one that says what is missing. */
  blockedBecause?: string | null;
}

/**
 * The confirmation shown in chat before an analysis is started.
 *
 * Proposing peers is a slow, paid run over live web search and several model
 * calls, and it discards whatever set is already on screen. That is worth a
 * deliberate yes, which is why this is the one thing the assistant cannot do on
 * its own. Everything it is about to commit to is restated here, because the
 * user may have been told about these settings several messages ago.
 */
const ConfirmRunCard = ({
  target,
  peerSet,
  criteriaIds,
  maxPeers,
  onConfirm,
  onCancel,
  outcome,
  blockedBecause,
}: ConfirmRunCardProps) => {
  const pending = !outcome && Boolean(onConfirm);

  return (
    <div className="oi-confirm-card">
      <div className="oi-confirm-title">
        {blockedBecause
          ? "Not ready to run"
          : "Start the peer analysis?"}
      </div>

      <div className="oi-confirm-detail">
        {blockedBecause
          ? `This cannot start yet: ${blockedBecause}.`
          : "This searches live sources and runs the model, and it replaces any peer set already proposed. It takes a couple of minutes."}
      </div>

      <dl className="oi-confirm-summary">
        <div>
          <dt>Target</dt>
          <dd>{target ?? "Not chosen yet"}</dd>
        </div>

        <div>
          <dt>Peer set</dt>
          <dd>
            {peerSet} · up to {maxPeers} peers
          </dd>
        </div>

        <div>
          <dt>Compared on</dt>
          <dd>
            {criteriaIds.length > 0
              ? criteriaIds.map(criterionLabel).join(", ")
              : "Nothing ticked yet"}
          </dd>
        </div>
      </dl>

      {outcome ? (
        <div className="oi-confirm-outcome">
          {outcome === "confirmed"
            ? "✓ Started"
            : "Cancelled. Nothing was run."}
        </div>
      ) : (
        <div className="oi-confirm-actions">
          {/* Hidden rather than disabled when the form is not ready: a button
              that cannot be pressed still reads as the thing to press. */}
          {!blockedBecause && (
            <button
              type="button"
              className="oi-confirm-primary"
              disabled={!pending}
              onClick={onConfirm}
            >
              Run the analysis
            </button>
          )}

          <button
            type="button"
            className="oi-confirm-secondary"
            disabled={!onCancel}
            onClick={onCancel}
          >
            {blockedBecause ? "OK" : "Not yet"}
          </button>
        </div>
      )}
    </div>
  );
};

export default ConfirmRunCard;
