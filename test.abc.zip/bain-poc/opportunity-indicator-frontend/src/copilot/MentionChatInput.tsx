import {
  useCallback,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  CopilotChatInput,
  type CopilotChatInputProps,
} from "@copilotkit/react-core/v2";

import CompanyMentionMenu from "./CompanyMentionMenu";
import {
  applyMention,
  matchCompanies,
  readMentionQuery,
} from "./mentions";

/**
 * The chat input, with an @ mention menu for picking a company.
 *
 * Registered as CopilotChat's `input` slot rather than built from scratch, and
 * it has to be done at the slot rather than by controlling the chat: CopilotChat
 * accepts `inputValue` and `onInputChange` props, but overwrites both with its
 * own internal state before passing them down, so a caller that sets them is
 * silently ignored. The slot is where the real value and setter arrive, so it is
 * the only place a mention can be read out of the text or written back into it.
 *
 * Everything else about the input is left alone: send, stop, attachments,
 * transcription and keyboard behaviour all still come from CopilotChatInput.
 */
const MentionChatInputBase = (props: CopilotChatInputProps) => {
  const { value = "", onChange } = props;

  const [highlighted, setHighlighted] = useState(0);

  /* The caret, sampled on every keystroke. Mentions are matched backwards from
     it, so editing one in the middle of a sentence behaves the same as typing a
     new one at the end. Without it, only the last @ in the whole string could
     ever match. */
  const [caret, setCaret] = useState<number | null>(null);

  const hostRef = useRef<HTMLDivElement>(null);

  const mention = useMemo(
    () => readMentionQuery(value, caret ?? value.length),
    [value, caret],
  );

  const matches = useMemo(
    () => (mention ? matchCompanies(mention.query) : []),
    [mention],
  );

  /* Dismissed with Escape. Keyed to the mention's start offset so that moving
     to a different mention reopens the menu, while carrying on typing in the
     dismissed one leaves it shut. */
  const [dismissedAt, setDismissedAt] = useState<number | null>(null);

  const open =
    mention !== null &&
    matches.length > 0 &&
    mention.start !== dismissedAt;

  const textarea = useCallback(
    () => hostRef.current?.querySelector("textarea") ?? null,
    [],
  );

  const syncCaret = useCallback(() => {
    /* Read after the browser has applied the keystroke. Reading during the
       event gives the caret position from before it. */
    requestAnimationFrame(() => {
      const element = textarea();

      if (element) {
        setCaret(element.selectionStart);
      }
    });
  }, [textarea]);

  const choose = useCallback(
    (index: number) => {
      const company = matches[index];

      if (!mention || !company || !onChange) {
        return;
      }

      const next = applyMention(value, mention, company);

      onChange(next.text);
      setHighlighted(0);
      setDismissedAt(null);

      /* Put the caret back after the inserted name. Deferred, because the
         textarea is re-rendered from the value we just set and setting the
         selection before that lands would be overwritten by it. */
      requestAnimationFrame(() => {
        const element = textarea();

        if (element) {
          element.focus();
          element.setSelectionRange(next.caret, next.caret);
          setCaret(next.caret);
        }
      });
    },
    [matches, mention, onChange, value, textarea],
  );

  /* While the menu is open the arrow keys and Enter belong to it. Captured on
     the way down, because the textarea's own Enter handler would otherwise send
     the half-typed mention as a message. */
  const handleKeyDown = useCallback(
    (event: React.KeyboardEvent) => {
      if (!open) {
        syncCaret();
        return;
      }

      if (event.key === "ArrowDown") {
        event.preventDefault();
        event.stopPropagation();
        setHighlighted((current) =>
          Math.min(current + 1, matches.length - 1),
        );
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        event.stopPropagation();
        setHighlighted((current) => Math.max(current - 1, 0));
      } else if (event.key === "Enter" || event.key === "Tab") {
        event.preventDefault();
        event.stopPropagation();
        choose(highlighted);
      } else if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        setDismissedAt(mention?.start ?? null);
      } else {
        syncCaret();
      }
    },
    [open, matches.length, highlighted, choose, mention, syncCaret],
  );

  return (
    <div
      className="oi-mention-input"
      ref={hostRef}
      onKeyDownCapture={handleKeyDown}
      onClick={syncCaret}
    >
      {open && (
        <CompanyMentionMenu
          companies={matches}
          highlighted={highlighted}
          onHighlight={setHighlighted}
          onChoose={choose}
        />
      )}

      <CopilotChatInput
        {...props}
        onChange={(next: string) => {
          setHighlighted(0);
          setDismissedAt(null);
          syncCaret();
          onChange?.(next);
        }}
      />
    </div>
  );
};

/* The slot type is `typeof CopilotChatInput`, which includes the sub-components
   hung off it (SendButton, ToolbarButton, the transcribe buttons, and so on).
   Anyone customising those reaches for them through the slot, so copying them
   across keeps that working rather than casting the type away and quietly
   breaking it. */
const MentionChatInput = Object.assign(
  MentionChatInputBase,
  CopilotChatInput,
);

export default MentionChatInput;
