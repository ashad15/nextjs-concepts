/** Which workflow step the conversation is in, pinned at the top of the chat.
 *
 * Its job is to stop someone treating the chat as if it still belongs to a step
 * that has closed. Once peers are proposed, the target and the criteria are the
 * inputs that produced them: they cannot be changed from the peer step, and the
 * assistant has no tools to do it there. Without a visible marker the
 * conversation just carries on, and a reader scrolling back through messages
 * about naming a target has nothing telling them that door has shut.
 *
 * Pinned rather than drawn inline between messages, and that is a deliberate
 * retreat from the obvious approach. CopilotKit can render custom content
 * against a specific message, but it resolves those renderers as the message
 * renders, so a marker recorded when the step changes never appears against
 * messages already on screen. A banner has no such dependency, and it has the
 * better property anyway: an inline rule scrolls out of view, while the thing
 * it is saying stays true for the rest of the step.
 */

interface StageBannerProps {
  /** The step now in progress, e.g. "Peer selection". */
  stage: string;

  /** The step just completed, if any. Null on the first step. */
  completed: string | null;

  /** One line on what is fixed now. Omitted while nothing is locked. */
  note?: string | null;
}

const StageBanner = ({ stage, completed, note }: StageBannerProps) => (
  <div className="oi-stage-banner">
    <div className="oi-stage-line">
      {completed && (
        <>
          <span className="oi-stage-done">{completed}</span>
          <span className="oi-stage-arrow" aria-hidden="true">
            →
          </span>
        </>
      )}

      <span className="oi-stage-current">{stage}</span>
    </div>

    {note && <div className="oi-stage-note">{note}</div>}
  </div>
);

export default StageBanner;
