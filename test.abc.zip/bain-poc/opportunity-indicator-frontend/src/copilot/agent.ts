/** Names and shapes shared by everything that talks to the chat agent.
 *
 * The agent id has to match the key the runtime registers the agent under
 * (server/runtime.ts) which in turn matches the name the Python service
 * registers (chat_agent/main.py). Three places, one string, so it lives here
 * rather than being typed out in each of them.
 */

export const OI_AGENT_ID = "oi_assistant";

/** A thread id minted once per page load.
 *
 * Reloading has to start a fresh conversation. The runtime keeps threads in
 * memory and would happily rejoin the previous one, which leaves the assistant
 * talking about an analysis the reloaded page no longer holds: nothing else in
 * the app survives a refresh, so a chat history that does is the odd one out.
 *
 * Module scope, so it is minted once and every consumer agrees on it. A value
 * computed per render would start a new thread on every keystroke.
 *
 * Passed to CopilotChat only, never to `useAgent`. `useAgent({ agentId,
 * threadId })` is a different mode that registers a private agent under that
 * name instead of resolving the shared one, which would leave the state-sync
 * hook writing to an instance the chat panel cannot see.
 */
export const OI_THREAD_ID = `oi-${crypto.randomUUID()}`;

/** Which screen the user is on, and what they are looking at on it.
 *
 * Kept small on purpose: this is the part of state the system prompt reads
 * verbatim on every turn, so it pays for itself in tokens each time.
 */
export interface AgentPageContext {
  /** Router path, e.g. "/oi/peers". The prompt keys its page notes off this. */
  route: string;

  /** The peer under the cursor or open on screen, if any. Resolves "this one". */
  focusedPeer: string | null;
}

/** What the setup form currently holds. */
export interface AgentSetupContext {
  target: string | null;
  targetCapId: string | null;
  peerSet: string;

  /** Criteria labels currently ticked, as shown on the card, not ids. */
  criteria: string[];

  /* Every criterion the card offers, ticked or not.
   *
   * Without this the assistant can see what is selected but not what could be,
   * so "tick everything except product mix" is unanswerable and it has to ask
   * the user to read the chips off their own screen. Six short strings, sent
   * with a payload that already carries the whole run. */
  availableCriteria: string[];
}

/** A company the user can pick as a target, as the agent needs to see it. */
export interface AgentCompany {
  capId: string;
  name: string;
  ticker: string;
  sector: string;
}
