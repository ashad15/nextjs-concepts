import { companies, type Company } from "../data/companies";

/** An @ mention being typed: where it starts, and what has been typed so far. */
export interface MentionQuery {
  /** Index of the "@" in the input. */
  start: number;

  /** Index just past the last character typed into the mention. */
  end: number;

  /** What follows the "@", lowercased. Empty right after typing "@". */
  query: string;
}

/* How far a mention is allowed to run. Company names have spaces in them
   ("Celyad Oncology SA"), so a mention cannot simply stop at the first space,
   but without a bound "@" followed by a whole sentence would keep matching.
   Three words covers every name in the list with room to spare. */
const MAX_MENTION_WORDS = 3;

/**
 * The mention the caret is currently inside, if any.
 *
 * Reads backwards from the caret to the nearest "@". A mention is live only
 * while the caret is still in it, which is what closes the menu once the user
 * has moved on and starts typing the rest of the sentence.
 *
 * `caret` defaults to the end of the text, which is where it is while someone
 * is typing left to right. Pass the real caret when it is known, so editing an
 * earlier mention behaves the same as typing a new one.
 */
export const readMentionQuery = (
  text: string,
  caret: number = text.length,
): MentionQuery | null => {
  const before = text.slice(0, caret);

  const at = before.lastIndexOf("@");

  if (at === -1) {
    return null;
  }

  /* Must start a word. Otherwise an email address would open the menu on
     every keystroke after the @. */
  const preceding = at > 0 ? before[at - 1] : " ";

  if (!/\s/.test(preceding)) {
    return null;
  }

  const typed = before.slice(at + 1);

  /* A newline always ends a mention, and so does running past the word
     budget. */
  if (typed.includes("\n")) {
    return null;
  }

  if (typed.trim().split(/\s+/).length > MAX_MENTION_WORDS) {
    return null;
  }

  return { start: at, end: caret, query: typed.toLowerCase() };
};

/**
 * Companies matching what has been typed, best first.
 *
 * An empty query lists everything, which is what makes bare "@" useful: the
 * list is short enough to pick from directly rather than having to recall a
 * name before the menu will help.
 */
export const matchCompanies = (query: string): Company[] => {
  const wanted = query.trim().toLowerCase();

  if (!wanted) {
    return companies;
  }

  const scored = companies
    .map((company) => {
      const name = company.name.toLowerCase();
      const ticker = company.ticker.toLowerCase();

      /* Ranked so the obvious match is first and reachable with Enter.
         A ticker typed in full is the most deliberate thing a user can do,
         then a name that starts with the query, then anything containing it. */
      if (ticker === wanted) return { company, rank: 0 };
      if (name.startsWith(wanted)) return { company, rank: 1 };
      if (ticker.startsWith(wanted)) return { company, rank: 2 };
      if (name.includes(wanted)) return { company, rank: 3 };

      return null;
    })
    .filter(
      (entry): entry is { company: Company; rank: number } =>
        entry !== null,
    );

  return scored
    .sort((a, b) => a.rank - b.rank)
    .map((entry) => entry.company);
};

/**
 * Put a chosen company into the text, replacing the mention being typed.
 *
 * The name is written back with its "@" kept and a trailing space added, so the
 * sentence carries on naturally and the menu closes on its own. Keeping the
 * marker matters: it is what tells the assistant this name was picked off the
 * list rather than typed from memory, which is the difference between resolving
 * it exactly and guessing.
 */
export const applyMention = (
  text: string,
  mention: MentionQuery,
  company: Company,
): { text: string; caret: number } => {
  const inserted = `@${company.name} `;

  const next =
    text.slice(0, mention.start) +
    inserted +
    text.slice(mention.end);

  return {
    text: next,
    caret: mention.start + inserted.length,
  };
};
