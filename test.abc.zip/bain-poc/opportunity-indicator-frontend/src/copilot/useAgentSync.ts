import { useEffect, useMemo } from "react";

import {
  useAgent,
  UseAgentUpdate,
} from "@copilotkit/react-core/v2";

import {
  OI_AGENT_ID,
  type AgentCompany,
  type AgentPageContext,
  type AgentSetupContext,
} from "./agent";

import type { ActivityEntry } from "../types/activity";
import type { PeerRecommendationResponse } from "../types/peer";

interface AgentSyncInput {
  recommendation: PeerRecommendationResponse | null;
  page: AgentPageContext;
  setup: AgentSetupContext;
  activityLog: ActivityEntry[];
  companies: AgentCompany[];
}

/* Written into state alongside everything else, and the reason it exists is
   below: it is how this hook tells in one comparison whether the agent still
   holds what it last wrote. */
const SYNC_TOKEN_KEY = "oiSyncToken";

/* The log as the agent should read it: who did what, in words, oldest first.
   Ids and millisecond timestamps are dropped — nothing the agent can say is
   improved by knowing an entry's uuid, and both would cost tokens on a payload
   that is re-sent every turn. */
const toAgentLog = (entries: ActivityEntry[]) =>
  entries.map((entry) => ({
    actor: entry.actor,
    // The log stores emphasis as **markdown**, which reads fine as-is.
    text: entry.text,
    at: new Date(entry.at).toISOString(),
  }));

/**
 * Mirrors what is on screen into the agent's state.
 *
 * State rather than context, and the distinction matters: `useAgentContext`
 * serialises into the model's prompt on every run, while state is carried
 * alongside it and only ever read by a tool. The recommendation is roughly
 * 200KB, so putting it in context would spend tens of thousands of tokens a
 * turn to tell the model things it mostly does not need. In state it costs
 * nothing until a tool reaches for a slice of it.
 *
 * The browser is the source of truth for all of this. It made the
 * recommendation call, it owns the activity log, and it knows which screen is
 * open, so mirroring it here is what stops the agent answering about a
 * different run from the one being looked at.
 *
 * ## Why this re-checks rather than writing once
 *
 * Writing once and remembering what was written is not enough, because this
 * hook is not the only writer. The chat panel is mounted with an explicit
 * thread id, and that makes CopilotChat call `connectAgent`, which loads that
 * thread's state from the runtime and replaces the agent's local state
 * wholesale. Anything written before the connect lands is gone.
 *
 * A guard that only compared "what I last wrote" against "what I want to write"
 * would see no change and stay quiet, leaving the agent with empty state for
 * the rest of the session: every tool reports nothing loaded, and the assistant
 * tells the user no analysis has been run while they are looking at one.
 *
 * So the check is against the agent's *actual* state, via a token this hook
 * writes and only this hook sets. If the token is missing or stale, whatever
 * happened in between has been undone and the payload goes again. Subscribing
 * to state changes is what wakes it up when that happens.
 */
export const useAgentSync = ({
  recommendation,
  page,
  setup,
  activityLog,
  companies,
}: AgentSyncInput) => {
  /* The shared registry instance, deliberately without a threadId.
     `useAgent({ agentId, threadId })` is a different mode that registers a
     private proxied agent, and it throws without a `runtimeAgentId` to go with
     it. Passing agentId alone returns the same agent CopilotChat resolves,
     which is the point: both halves have to be looking at one object.

     Subscribed to state changes as well as run status, because a connect
     replacing the state is exactly the event this hook has to react to. */
  const { agent } = useAgent({
    agentId: OI_AGENT_ID,
    updates: [
      UseAgentUpdate.OnStateChanged,
      UseAgentUpdate.OnRunStatusChanged,
    ],
  });

  const payload = useMemo(
    () => ({
      recommendation,
      page,
      setup,
      activityLog: toAgentLog(activityLog),
      companies,
    }),
    [recommendation, page, setup, activityLog, companies],
  );

  /* A fresh token whenever the payload changes, keyed off the memo above rather
     than off the contents. Hashing 200KB on every render to detect a change the
     memo has already told us about would be the most expensive thing this hook
     does. */
  const token = useMemo(
    () => crypto.randomUUID(),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- identity is the signal
    [payload],
  );

  useEffect(() => {
    const current = (agent.state ?? {}) as Record<string, unknown>;

    /* One comparison, no deep equality. The token is only ever set by the line
       below, so if it survives, so did everything written with it. */
    if (current[SYNC_TOKEN_KEY] === token) {
      return;
    }

    /* Merged over whatever is there rather than replacing it, because the graph
       writes its own keys into state and overwriting the lot would strip them.

       `tools` is the exception, and it has to be. The tools the browser offers
       change with the screen: naming a target exists on the set-up step and is
       deliberately gone once peers are proposed. The agent server merges the
       run's tools over the ones already in state and keeps both, so carrying
       state.tools forward resurrects every tool that has ever been registered.
       The assistant then happily "changes the target" from a screen that has no
       way to do it, and reports success for a call nothing handled.

       Dropping the key lets each run's own declarations stand alone. */
    const carried = { ...current };
    delete carried.tools;

    agent.setState({
      ...carried,
      ...payload,
      [SYNC_TOKEN_KEY]: token,
    });
  }, [agent, payload, token]);

  return agent;
};
