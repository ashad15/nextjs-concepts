import { useFrontendTool } from "@copilotkit/react-core/v2";
import { z } from "zod";
import type { NavigateFunction } from "react-router-dom";

import { OI_AGENT_ID } from "./agent";

import { companies, type Company } from "../data/companies";
import {
  criterionLabel,
  peerCriteria,
} from "../data/peerCriteria";

import type { ActivityLog } from "../hooks/useActivityLog";
import type { PeerSetType } from "../components/OISetup/PeerSetCard";
import type { Actor } from "../layouts/OIWorkflowLayout";

const PEER_SETS: PeerSetType[] = ["tight", "standard", "broad"];

/* The criterion labels, as a tuple, so they can go into the tool's schema as an
   enum rather than being described in prose.

   This is the difference between the assistant knowing what it may pick and
   guessing. With a bare string array it could see which criteria were ticked
   but not which existed, so "tick everything except product mix" was
   unanswerable and it asked the user to read the chips off their own screen. In
   the schema, the six values travel with the tool definition itself. */
const CRITERION_LABELS = peerCriteria.map(
  (criterion) => criterion.label,
) as [string, ...string[]];

/* How many peers each breadth asks for. Mirrors getMaxPeers in OISetup, and is
   only used to say so in the log line. */
const PEER_SET_SIZES: Record<PeerSetType, string> = {
  tight: "about 4",
  standard: "about 7",
  broad: "about 10",
};

/** Resolve what the user typed to a company we actually hold.
 *
 * The model is told to call the company list first, but it will still
 * occasionally pass a bare name, and an @ mention arrives with its marker
 * attached. Matching on cap id, ticker and name, then falling back to a
 * substring, turns all of those into the same answer instead of an error the
 * model has to recover from.
 */
const resolveCompany = (query: string): Company | null => {
  const wanted = query.trim().replace(/^@/, "").toLowerCase();

  if (!wanted) {
    return null;
  }

  const exact = companies.find(
    (company) =>
      company.capId.toLowerCase() === wanted ||
      company.ticker.toLowerCase() === wanted ||
      company.name.toLowerCase() === wanted,
  );

  return (
    exact ??
    companies.find((company) =>
      company.name.toLowerCase().includes(wanted),
    ) ??
    null
  );
};

/** Match a criterion the model named to one of the six on the card. */
const resolveCriterion = (query: string): string | null => {
  const wanted = query.trim().toLowerCase();

  const match = peerCriteria.find(
    (criterion) =>
      criterion.id.toLowerCase() === wanted ||
      criterion.label.toLowerCase() === wanted ||
      criterion.label.toLowerCase().startsWith(wanted),
  );

  return match?.id ?? null;
};

interface SetupToolsInput {
  resolveTarget: (company: Company, actor?: Actor) => void;
  setPeerSet: React.Dispatch<React.SetStateAction<PeerSetType>>;
  setCriteriaIds: React.Dispatch<React.SetStateAction<string[]>>;
  activity: ActivityLog;

  /* Whether the set-up is still open for editing, i.e. the user is on the
     set-up step. False once peers have been proposed. */
  canEdit: boolean;
}

/* Returned by every set-up tool once the step has closed.
 *
 * A refusal the model can read, rather than no tool at all. Unregistering these
 * on the peer step does stop them working, and that was the first attempt, but
 * it stops them silently: the model finds nothing to call, has no result to
 * report, and narrates the change it believed it was making. Twice in testing
 * it told the user the target had been switched while the screen still showed
 * the original. A tool that answers "no, and here is why" cannot be
 * misreported, because the refusal is the tool result. */
const CLOSED = {
  ok: false as const,
  message:
    "The set-up is closed. These are the inputs that produced the peer set on " +
    "screen, so they cannot be changed from the peer step. Tell the user this " +
    "plainly, say that changing an input means re-running the analysis (a few " +
    "minutes, and it replaces the current peer set), and offer to take them " +
    "back to the set-up step with go_to_step. Do not claim anything changed.",
};

/**
 * The tools that let the assistant fill in the analysis set-up.
 *
 * Registered by the layout and always present, but refusing once the set-up
 * step has closed. The refusal is the point: after peers are proposed, the
 * target, the breadth and the criteria are the settings that produced the set
 * being looked at, and quietly re-picking one would leave the screen showing a
 * peer set that no longer matches the inputs it was built from.
 *
 * Always present rather than registered per page, which is what this did
 * first. Removing the tools does prevent the change, but it leaves the model
 * with nothing to call and no result to relay, and it fills the gap by
 * narrating the change it meant to make. A tool that returns a refusal gives it
 * something true to say.
 *
 * Navigation is deliberately not here. It belongs to the whole workflow and is
 * registered by the layout.
 *
 * Every one of these logs against "agent". That is the whole point of the actor
 * on the log: the same action reads as You when the user clicks and as Agent
 * when the assistant does it, and someone reviewing the analysis afterwards can
 * tell which decisions were theirs.
 *
 * Each registration passes a dependency array. Omitting it registers the tool
 * once with the closure it had at mount, so a handler reading changing state
 * would act on whatever the page loaded with. The handlers below close over
 * stable setters and would survive that today, which is exactly why the
 * dependencies are written out rather than left to luck.
 */
export const useSetupTools = ({
  resolveTarget,
  setPeerSet,
  setCriteriaIds,
  activity,
  canEdit,
}: SetupToolsInput) => {
  useFrontendTool(
    {
      agentId: OI_AGENT_ID,
      name: "select_target_company",
      description:
        "Choose the target company for the analysis. Call list_companies first " +
        "to get the exact name or cap id. This fills in the target on the setup " +
        "form exactly as if the user had picked it.",
      parameters: z.object({
        company: z
          .string()
          .describe(
            "Company name, ticker or cap id, as list_companies reported it.",
          ),
      }),
      handler: async ({ company }) => {
        if (!canEdit) {
          return CLOSED;
        }

        const match = resolveCompany(company);

        if (!match) {
          /* Returned rather than thrown: the model can correct itself from
             this in one turn, whereas an exception surfaces as a failed tool
             call and usually ends the run. */
          return {
            ok: false,
            message:
              `No company called "${company}" is available. The list is: ` +
              companies
                .map((item) => `${item.name} (${item.ticker})`)
                .join(", "),
          };
        }

        resolveTarget(match, "agent");

        return {
          ok: true,
          selected: {
            name: match.name,
            ticker: match.ticker,
            capId: match.capId,
            sector: match.sector,
          },
        };
      },
    },
    [resolveTarget, canEdit],
  );

  useFrontendTool(
    {
      agentId: OI_AGENT_ID,
      name: "set_peer_set_breadth",
      description:
        "Set how broad the peer set should be. Tight is the closest few direct " +
        "competitors, Standard is the recommended default, Broad widens to " +
        "best-in-class operators in adjacent sectors.",
      parameters: z.object({
        peerSet: z
          .enum(["tight", "standard", "broad"])
          .describe("Which breadth to select."),
      }),
      handler: async ({ peerSet }) => {
        if (!canEdit) {
          return CLOSED;
        }

        const next = peerSet as PeerSetType;

        if (!PEER_SETS.includes(next)) {
          return { ok: false, message: `Unknown peer set: ${peerSet}` };
        }

        setPeerSet(next);

        activity.logAgent(
          `Set peer set to **${next}** (${PEER_SET_SIZES[next]} peers)`,
        );

        return { ok: true, peerSet: next };
      },
    },
    [setPeerSet, activity, canEdit],
  );

  useFrontendTool(
    {
      agentId: OI_AGENT_ID,
      name: "set_comparability_criteria",
      description:
        "Tick which criteria the peers are scored on. The full set of criteria " +
        "the form offers is: " +
        CRITERION_LABELS.join(", ") +
        ". This replaces the current selection outright, so pass every " +
        'criterion you want ticked. For "all except X", pass all of them ' +
        "except X. At least one is required.",
      parameters: z.object({
        criteria: z
          .array(z.enum(CRITERION_LABELS))
          .min(1)
          .describe(
            "The complete set to tick, not just additions. Anything omitted " +
              "is unticked.",
          ),
      }),
      handler: async ({ criteria }) => {
        if (!canEdit) {
          return CLOSED;
        }

        /* "all" is still honoured, even though the schema no longer offers it.
           The enum stops it arriving from a well-behaved call, but a model that
           has seen the older description in its own earlier turn will still try
           it, and turning that into an error helps nobody. */
        const wantsAll =
          criteria.length === 1 &&
          criteria[0].trim().toLowerCase() === "all";

        const ids = wantsAll
          ? peerCriteria.map((criterion) => criterion.id)
          : criteria
              .map(resolveCriterion)
              .filter((id): id is string => id !== null);

        if (ids.length === 0) {
          return {
            ok: false,
            message:
              "None of those matched. The criteria are: " +
              peerCriteria.map((criterion) => criterion.label).join(", "),
          };
        }

        setCriteriaIds(ids);

        const labels = ids.map(criterionLabel);

        activity.logAgent(
          `Set comparability criteria to **${labels.join(", ")}**`,
        );

        return { ok: true, criteria: labels };
      },
    },
    [setCriteriaIds, activity, canEdit],
  );

};

/**
 * Navigation, which belongs to the workflow rather than to either step.
 *
 * Separate from the set-up tools above because it outlives them: it is
 * registered by the layout and stays available on every screen, which is what
 * lets the assistant offer to take someone back to the set-up step when they
 * ask for something the peer step cannot do.
 */
export const useNavigationTools = ({
  navigate,
}: {
  navigate: NavigateFunction;
}) => {
  useFrontendTool(
    {
      agentId: OI_AGENT_ID,
      name: "go_to_step",
      description:
        "Move the user to a step of the workflow. Only go to the peer step " +
        "once an analysis has actually been run, or it will be empty. Going " +
        "back to the set-up step is how the target or the criteria get " +
        "changed, but say first that it means running the analysis again.",
      parameters: z.object({
        step: z
          .enum(["setup", "peers"])
          .describe(
            "setup is the analysis set-up form, peers is the proposed peer set.",
          ),
      }),
      handler: async ({ step }) => {
        navigate(step === "peers" ? "/oi/peers" : "/oi/setup");

        return { ok: true, step };
      },
    },
    [navigate],
  );
};
