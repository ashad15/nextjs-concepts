/* The stages the peer analysis screen walks through.
 *
 * These mirror what the backend actually does on the agent path: read the
 * target's record, pull the VCC universe, then run TWO tracks at once, and
 * finally merge them into one ranking. See app/routers/peers.py and
 * app/services/recommendation.py.
 *
 * The concurrency is the part worth drawing. Once the universe is loaded the
 * service forks: the agent goes looking for peers we do not hold, and at the
 * same moment a second pass grounds the peers we do. The second finishes well
 * inside the first, which is the whole reason it costs almost nothing. A
 * single-file ladder would describe a slower system than the one that exists.
 *
 * The TIMINGS are scripted, not measured. The API reports nothing until it
 * returns, so the screen paces itself and finishes when the answer is in
 * hand. Wiring real progress needs the backend to stream its phases; until
 * then this is a narration of the right steps in roughly the right order and
 * the right shape, and the code should not pretend otherwise.
 *
 * `normalMs` tracks how long each phase really takes, so a live run is paced
 * against something true. `fastMs` is a different job: a cached run answers
 * in under a second, and these are the seconds someone gets to SAY what the
 * screen is showing. They are set by how much there is to explain, not by
 * how long the work took, and the fork is the part that needs explaining.
 *
 *   live, up to the hold  ~21s, then it waits for the answer
 *   cached, end to end    ~19s, of which ~12s sits on the parallel band
 *
 * If a room needs longer, `search` and `metrics` are the two to stretch:
 * everything worth narrating happens while one of those is on screen.
 */
export type StageActor = "system" | "agent";

export interface AnalysisStage {
  id: string;

  actor: StageActor;

  /** What the actor is, in the audience's terms. */
  actorLabel: string;

  title: string;
  description: string;

  /** Scripted duration while the answer is still outstanding. */
  normalMs: number;

  /** Compressed duration once the answer has arrived. */
  fastMs: number;

  /** Cycled in the status pill while this stage runs. */
  messages: string[];

  /* Where the screen waits out a slow run. Put it on the stage the backend
     genuinely spends its time in, so a long wait is spent on a plausible
     step and the closing step still plays once the answer lands. */
  hold?: boolean;
}

/** A step that runs BESIDE the spine rather than on it.
 *
 * A parallel track carries no timings of its own. Its state is derived from
 * where the spine has got to, which is what keeps the two in step: the track
 * cannot drift, and "it finished early" is expressed as a fact about the
 * spine rather than as a second scripted clock that happens to be shorter.
 */
export interface ParallelTrack {
  id: string;

  actor: StageActor;
  actorLabel: string;

  title: string;
  description: string;

  /** The spine step ids this runs alongside, in spine order. */
  alongside: string[];

  /** The spine step this track finishes inside. */
  completesWith: string;

  /** Cycled in the status pill while this track runs. */
  messages: string[];
}

/** The main sequence. Steps between the fork and the join share the screen
 *  with everything in `parallelTracks`. */
export const analysisStages: AnalysisStage[] = [
  {
    id: "target",
    actor: "system",
    actorLabel: "System",
    title: "Target profile prepared",
    description:
      "Identity, sector and industry classification read from the target's record.",
    normalMs: 1800,
    fastMs: 900,
    messages: [
      "Reading the target record...",
      "Resolving industry classification...",
    ],
  },
  {
    id: "universe",
    actor: "system",
    actorLabel: "VCC · CapIQ",
    title: "Loading the VCC peer universe",
    description:
      "Deterministic pull from the CapIQ-sourced company universe. No model involved.",
    normalMs: 7000,
    fastMs: 2600,
    messages: [
      "Loading the VCC company universe...",
      "Matching sector and industry group...",
      "Screening on revenue scale and margin...",
      "Assembling the internal candidate set...",
    ],
  },
  {
    id: "search",
    actor: "agent",
    actorLabel: "Agent",
    title: "Searching for peers beyond the universe",
    description:
      "The agent runs its own web searches to find comparable companies the internal set does not hold.",
    /* The only window where both lanes pulse at once, so it gets the most
       room in both modes. Live, the real discovery loop runs far longer than
       this anyway; cached, this is where the fork gets explained. */
    normalMs: 12000,
    fastMs: 6500,
    messages: [
      "Searching for comparable public companies...",
      "Reading investor relations pages...",
      "Opening the latest annual filings...",
      "Collecting candidate tickers...",
      "Discarding candidates that are not publicly listed...",
    ],
  },
  {
    id: "metrics",
    actor: "agent",
    actorLabel: "Agent",
    /* Only the agent's candidates are researched here. Our own rows already
       carry audited figures, and replacing one with a scraped number would
       make the answer worse, not better. */
    title: "Researching the agent's candidates",
    description:
      "A targeted search per agent-found candidate for revenue, margin and growth, every figure kept with the page it came from.",
    /* Where the internal lane shows as already finished while this one is
       still going. That contrast is the point of the whole band, so cached
       runs hold on it long enough to be pointed at. */
    normalMs: 8000,
    fastMs: 5500,
    hold: true,
    messages: [
      "Pulling revenue and margin figures...",
      "Cross-checking each figure against its source...",
      "Normalising currencies and fiscal years...",
      "Recording the URL behind every number...",
      "Still searching: some filings are slow to return...",
      "Reconciling figures that disagree across sources...",
    ],
  },
  {
    id: "rank",
    actor: "agent",
    actorLabel: "Agent",
    title: "Merging and ranking both sets",
    /* The criteria scores now arrive from both tracks rather than being
       invented here, so this step merges and ranks; it only scores a factor
       where one is genuinely missing. */
    description:
      "Both candidate sets arrive already scored against the chosen criteria. This pass merges them, ranks them, and says why each one placed where it did.",
    normalMs: 7000,
    fastMs: 3200,
    messages: [
      "Merging internal and agent candidates...",
      "Reusing the criteria scores from both tracks...",
      "Weighing comparability concerns...",
      "Ranking the strongest matches...",
    ],
  },
];

/** Everything that runs beside the spine.
 *
 * One entry today. The shape is a list because the fork is the point: a
 * second track added later should widen the band, not reopen the layout. */
export const parallelTracks: ParallelTrack[] = [
  {
    id: "grounding",
    actor: "agent",
    actorLabel: "Agent",
    title: "Grounding the internal peers",
    /* Deliberately says what it does NOT do. Our figures are audited and the
       web is a worse source for them; what our rows lack is evidence of
       comparability, and that is all this pass supplies. */
    description:
      "One web search per internal peer, then a single scoring pass on the same criteria. Evidence only: their figures are already audited and are never overwritten.",
    alongside: ["search", "metrics"],
    completesWith: "search",
    messages: [
      "Searching what each internal peer actually does...",
      "Reading business model and end-market pages...",
      "Scoring the internal peers on the same criteria...",
      "Attaching a cited page to every rating...",
    ],
  },
];
