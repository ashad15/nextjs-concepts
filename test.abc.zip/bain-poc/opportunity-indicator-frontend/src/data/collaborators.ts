export type CollaboratorRole = "Contributor" | "Viewer";

export interface Collaborator {
  id: string;
  name: string;
  title: string;
  role: CollaboratorRole;

  /* Last activity, already phrased. Sharing has no backend, so there is no
     timestamp to age. */
  lastSeen: string;

  online: boolean;
}

/* Sharing is out of scope for the PoC: there is no invite flow, no presence
   channel and no permission check behind these rows. The list is fixed, taken
   from the client mockup, and only ever renders.
*/
export const collaborators: Collaborator[] = [
  {
    id: "raema-grover",
    name: "Raema Grover",
    title: "Design lead",
    role: "Contributor",
    lastSeen: "Active now",
    online: true,
  },
  {
    id: "jo-soh",
    name: "Jo Soh",
    title: "Design manager",
    role: "Contributor",
    lastSeen: "6 min ago",
    online: true,
  },
  {
    id: "noah-wells",
    name: "Noah Wells",
    title: "Product owner",
    role: "Viewer",
    lastSeen: "Yesterday",
    online: false,
  },
  {
    id: "kasia-mrowca",
    name: "Kasia Mrowca",
    title: "Stakeholder",
    role: "Viewer",
    lastSeen: "2 days ago",
    online: false,
  },
];

/** First letter of the first and last word: "Kasia Mrowca" gives "KM". */
export const collaboratorInitials = (name: string) => {
  const words = name.trim().split(/\s+/);

  if (words.length === 0) {
    return "?";
  }

  const first = words[0][0] ?? "";
  const last = words.length > 1 ? (words[words.length - 1][0] ?? "") : "";

  return `${first}${last}`.toUpperCase();
};
