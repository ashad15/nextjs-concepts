export interface Company {
  capId: string;
  name: string;
  ticker: string;
  sector: string;
  industry: string;
  isPublic: boolean;
}

export const companies: Company[] = [
  {
    capId: "IQ409095732",
    name: "Zelluna ASA",
    ticker: "ZLNA",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ34816993",
    name: "Celyad Oncology SA",
    ticker: "CYAD",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ7406282",
    name: "DBV Technologies SA",
    ticker: "DBV",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ36632718",
    name: "Faron Pharmaceuticals Oy",
    ticker: "FARN",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ224193775",
    name: "ProQR Therapeutics NV",
    ticker: "PRQR",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ20786046",
    name: "CureVac NV",
    ticker: "CVAC",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: true,
  },
  {
    capId: "IQ1716658",
    name: "Lakefront Biotherapeutics NV",
    ticker: "LKFT",
    sector: "Healthcare",
    industry: "Pharma & Biotech Products",
    isPublic: false,
  },
];