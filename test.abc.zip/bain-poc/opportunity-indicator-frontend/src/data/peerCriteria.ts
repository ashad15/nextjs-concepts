/*
 * The comparability criteria offered in the Peer set card.
 *
 * `label` is what the user sees and what we send to the API as basic_metrics.
 * The backend slugifies that text into the key it scores on and returns under
 * selection_criteria (agents/search_peers.py, criterion_key), so `id` mirrors
 * that derivation: lowercase, non-alphanumerics collapsed to underscores.
 * Change a label and the id has to follow.
 */

export interface PeerCriterion {
  id: string;
  label: string;
}

export const peerCriteria: PeerCriterion[] = [
  {
    id: "business_model",
    label: "Business model",
  },
  {
    id: "revenue_scale",
    label: "Revenue scale",
  },
  {
    id: "regional_exposure",
    label: "Regional exposure",
  },
  {
    id: "end_market_customers",
    label: "End market & customers",
  },
  {
    id: "product_mix",
    label: "Product mix",
  },
  {
    id: "growth_profile",
    label: "Growth profile",
  },
];

/** Pre-ticked on load: the three the Standard set is described as matching on. */
export const defaultPeerCriteriaIds = [
  "business_model",
  "revenue_scale",
  "regional_exposure",
];

/**
 * Ids → the labels the API expects, in card order rather than click order, so
 * the same tick-set always produces the same request (and the same cache key).
 */
export const criteriaLabels = (ids: string[]) =>
  peerCriteria
    .filter((criterion) =>
      ids.includes(criterion.id),
    )
    .map((criterion) => criterion.label);

/**
 * One criterion key from a response back into display text. Falls back to
 * un-slugifying, so a criterion we did not send still reads properly.
 */
export const criterionLabel = (id: string) => {
  const known = peerCriteria.find(
    (criterion) => criterion.id === id,
  );

  if (known) {
    return known.label;
  }

  const words = id.split("_").join(" ").trim();

  return words
    ? words.charAt(0).toUpperCase() +
        words.slice(1)
    : id;
};
