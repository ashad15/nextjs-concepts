import { useCallback, useMemo, useState } from "react";

import type { ActivityActor, ActivityEntry } from "../types/activity";

export interface ActivityLog {
  /* Oldest first, the way the panel reads. */
  entries: ActivityEntry[];

  logHuman: (text: string) => void;
  logSystem: (text: string) => void;
  logAgent: (text: string, detail?: ActivityEntry["detail"]) => void;
}

/** The activity log for one analysis, seeded with a system entry.
 *
 * Held by the workflow layout rather than the assistant panel, because the
 * actions worth logging happen on the left of the screen: the panel is only
 * one of its readers. Every writer is a plain callback, so entries are always
 * appended from an event handler and never from a render or an effect.
 *
 * `seed` is read once. Changing it later does not rewrite the first entry.
 */
export const useActivityLog = (seed: string): ActivityLog => {
  const [entries, setEntries] = useState<ActivityEntry[]>(() => [
    {
      id: crypto.randomUUID(),
      actor: "system",
      text: seed,
      at: Date.now(),
    },
  ]);

  const append = useCallback(
    (
      actor: ActivityActor,
      text: string,
      detail?: ActivityEntry["detail"],
    ) => {
      setEntries((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          actor,
          text,
          at: Date.now(),
          detail,
        },
      ]);
    },
    [],
  );

  const logHuman = useCallback(
    (text: string) => append("human", text),
    [append],
  );

  const logSystem = useCallback(
    (text: string) => append("system", text),
    [append],
  );

  const logAgent = useCallback(
    (text: string, detail?: ActivityEntry["detail"]) =>
      append("agent", text, detail),
    [append],
  );

  return useMemo(
    () => ({ entries, logHuman, logSystem, logAgent }),
    [entries, logHuman, logSystem, logAgent],
  );
};
