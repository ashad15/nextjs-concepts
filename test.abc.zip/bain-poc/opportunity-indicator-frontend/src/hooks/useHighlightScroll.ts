import { useEffect, useRef } from "react";

/**
 * Bring the group matching the hovered peer into view.
 *
 * Several peers' worth of evidence does not fit the panel, so a highlight below
 * the fold would be a highlight nobody sees. "nearest" leaves the list alone
 * when the group is already visible, which keeps a sweep down the peer grid
 * from scrolling the panel on every tile.
 *
 * Returns the ref for the scrolling container. Groups inside it are found by
 * `data-group`, which every evidence tab sets to the same peer key the grid
 * hovers with; matching on that one attribute is what keeps the sources and
 * filings tabs behaving identically without either knowing about the other.
 */
export const useHighlightScroll = (
  highlightedPeerId: string | null,
) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!highlightedPeerId) {
      return;
    }

    const group = scrollRef.current?.querySelector(
      `[data-group="${CSS.escape(highlightedPeerId)}"]`,
    );

    group?.scrollIntoView({
      block: "nearest",

      behavior: window.matchMedia(
        "(prefers-reduced-motion: reduce)",
      ).matches
        ? "auto"
        : "smooth",
    });
  }, [highlightedPeerId]);

  return scrollRef;
};
