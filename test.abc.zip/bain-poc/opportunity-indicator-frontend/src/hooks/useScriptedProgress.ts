import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import type { AnalysisStage } from "../data/analysisStages";

/** Whether the thing being narrated has come back yet. */
export type ProgressStatus = "pending" | "ready" | "failed";

/* How long the screen lingers after a failure before handing back. Long
   enough not to flash, short enough that an operator sees the error fast. */
const FAILURE_TAIL_MS = 600;

/* A beat between the answer landing and the screen moving, so the last step
   is seen to complete rather than the screen cutting away mid-sentence. */
const FINISH_TAIL_MS = 900;

/* Presenter control. A cached run answers in under a second, so the script
   is the only thing giving anyone time to say what the screen is showing,
   and no fixed duration is right for every room.

   The split maps onto a presentation remote, which is the point: "back"
   waits, "forward" moves on, and clicking a remote is invisible in a way
   that reaching for a laptop is not.

   Deliberately nothing changes on screen when the run is held. The status
   line keeps cycling, so a hold reads as the system still working rather
   than as someone having stopped it. */
const HOLD_KEYS = new Set(["ArrowLeft", "PageUp"]);

const ADVANCE_KEYS = new Set([
  "ArrowRight",
  "PageDown",
]);

// "Spacebar" is the pre-standard name; some remotes still send it.
const TOGGLE_KEYS = new Set([" ", "Spacebar"]);

/** Whether a keypress belongs to the page rather than to a field. */
const isTypingTarget = (
  target: EventTarget | null,
): boolean => {
  const element = target as HTMLElement | null;

  return Boolean(
    element?.isContentEditable ||
      (element?.tagName &&
        /^(INPUT|TEXTAREA|SELECT)$/.test(
          element.tagName,
        )),
  );
};

interface ScriptedProgress {
  /** Index of the stage currently running. */
  stage: number;

  /** Advances once per interval, for cycling the status line. */
  tick: number;

  /* Whether the presenter is holding the run. Returned for a caller that
     wants an operator-facing cue; the loader deliberately shows none. */
  held: boolean;
}

/** Walks a scripted stage list, paced by whether the answer has arrived.
 *
 * Three behaviours, and the demo depends on all of them:
 *
 * - Still waiting: stages run at their normal length and the last one holds.
 *   A slow agent run never outruns the narration.
 * - Answer in hand: the remaining stages run compressed. A cached response
 *   comes back in under a second, and snapping straight to the peer screen
 *   would tell the room it was cached; the compressed run still takes about
 *   twelve seconds and reads as work.
 * - Failed: cut the narration short. Nobody needs theatre in front of an
 *   error, and the operator needs to see it.
 *
 * On top of that the presenter can hold the run wherever it is and let it go
 * again, because the right pause is however long it takes to finish a
 * sentence. Holding does not burn the current step's remaining time: the
 * stage clock is shifted forward by exactly the time held, so a step that
 * had two seconds left still has two seconds left afterwards.
 *
 * `onComplete` is read from a ref so a new identity, which happens on every
 * log entry the parent writes, cannot restart a running timer.
 */
export const useScriptedProgress = (
  stages: AnalysisStage[],
  status: ProgressStatus,
  onComplete: () => void,
  messageIntervalMs = 2200,
): ScriptedProgress => {
  const [stage, setStage] = useState(0);
  const [tick, setTick] = useState(0);

  /** Presenter is holding the run where it is. */
  const [held, setHeld] = useState(false);

  const completeRef = useRef(onComplete);

  // After every render, not during one: a timer can only fire post-commit,
  // so the ref is always current by the time it is read.
  useEffect(() => {
    completeRef.current = onComplete;
  });

  /* onComplete must fire once. Effects run twice under StrictMode, and the
     parent navigates from it. */
  const finishedRef = useRef(false);

  /* When the running stage began, so that the answer arriving part-way
     through shortens what is left rather than restarting it. Declared before
     the timer effect so it is already updated when that one runs. */
  const stageStartedRef = useRef<number | null>(null);

  useEffect(() => {
    stageStartedRef.current = Date.now();
  }, [stage]);

  /* When the hold began, so releasing can give the step back the time it had
     left rather than treating the pause as time spent working. */
  const heldAtRef = useRef<number | null>(null);

  const finish = useCallback(() => {
    if (finishedRef.current) {
      return;
    }

    finishedRef.current = true;
    completeRef.current();
  }, []);

  const hold = useCallback(() => {
    if (heldAtRef.current === null) {
      heldAtRef.current = Date.now();
    }

    setHeld(true);
  }, []);

  const release = useCallback(() => {
    /* Push the stage's start forward by however long it was held. The timer
       effect credits elapsed time against the step's duration, so without
       this a hold of any length would spend the whole step and the run would
       jump the moment it resumed. */
    if (heldAtRef.current !== null) {
      if (stageStartedRef.current !== null) {
        stageStartedRef.current +=
          Date.now() - heldAtRef.current;
      }

      heldAtRef.current = null;
    }

    setHeld(false);
  }, []);

  const advance = useCallback(() => {
    release();

    if (stage >= stages.length - 1) {
      finish();

      return;
    }

    setStage((index) => index + 1);
  }, [finish, release, stage, stages.length]);

  useEffect(() => {
    const onKeyDown = (
      event: KeyboardEvent,
    ) => {
      if (isTypingTarget(event.target)) {
        return;
      }

      if (TOGGLE_KEYS.has(event.key)) {
        // Space scrolls the page otherwise.
        event.preventDefault();

        if (held) {
          release();
        } else {
          hold();
        }

        return;
      }

      if (HOLD_KEYS.has(event.key)) {
        event.preventDefault();
        hold();

        return;
      }

      if (ADVANCE_KEYS.has(event.key)) {
        event.preventDefault();
        advance();
      }
    };

    window.addEventListener(
      "keydown",
      onKeyDown,
    );

    return () =>
      window.removeEventListener(
        "keydown",
        onKeyDown,
      );
  }, [advance, held, hold, release]);

  useEffect(() => {
    if (finishedRef.current) {
      return;
    }

    if (status === "failed") {
      const timer = window.setTimeout(finish, FAILURE_TAIL_MS);

      return () => window.clearTimeout(timer);
    }

    /* Checked after the failure branch on purpose: an error still has to
       reach the operator, whether or not the run was being held. */
    if (held) {
      return;
    }

    const isLast = stage >= stages.length - 1;

    const current = stages[stage];

    /* Wait out a slow run on the stage marked for it, so the closing steps
       still play once the answer lands. The last stage holds too, as a
       backstop: the script must never run past its end while waiting. */
    if (status === "pending" && (current.hold || isLast)) {
      return;
    }

    const duration =
      status === "ready" ? current.fastMs : current.normalMs;

    /* Credit the time this stage has already been on screen. Without it, an
       answer landing just before a stage was due to end would restart that
       stage and make the whole run longer than waiting would have been. */
    const startedAt = stageStartedRef.current;

    const elapsed =
      startedAt === null ? 0 : Date.now() - startedAt;

    const remaining = Math.max(0, duration - elapsed);

    const wait = isLast
      ? Math.max(remaining, FINISH_TAIL_MS)
      : remaining;

    const timer = window.setTimeout(
      () => (isLast ? finish() : setStage((index) => index + 1)),
      wait,
    );

    return () => window.clearTimeout(timer);
  }, [finish, held, stage, stages, status]);

  /* One free-running counter rather than a per-stage reset: each stage has
     its own message list, so the line changes when the stage does anyway. */
  useEffect(() => {
    const timer = window.setInterval(
      () => setTick((current) => current + 1),
      messageIntervalMs,
    );

    return () => window.clearInterval(timer);
  }, [messageIntervalMs]);

  return { stage, tick, held };
};
