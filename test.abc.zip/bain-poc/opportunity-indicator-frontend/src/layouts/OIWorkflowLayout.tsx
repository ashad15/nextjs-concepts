import { useCallback, useMemo, useRef, useState } from "react";
import {
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";

import AssistantPanel from "../components/OISetup/AssistantPanel";
import AssistantResizer from "../components/OISetup/AssistantResizer";

import { clamp } from "../utils/clamp";
import {
  useActivityLog,
  type ActivityLog,
} from "../hooks/useActivityLog";

import { companies, type Company } from "../data/companies";
import {
  criteriaLabels,
  defaultPeerCriteriaIds,
  peerCriteria,
} from "../data/peerCriteria";
import { peerKey } from "../utils/peerKey";
import { cleanCompanyName } from "../utils/companyName";

import type { PeerRecommendationResponse } from "../types/peer";
import type { PeerSetType } from "../components/OISetup/PeerSetCard";

import { useAgentSync } from "../copilot/useAgentSync";
import {
  useNavigationTools,
  useSetupTools,
} from "../copilot/useWorkflowTools";
import type { AgentCompany } from "../copilot/agent";

/* Assistant panel width, as a percentage of the workflow body. */
const ASSISTANT_MIN_WIDTH = 20;
const ASSISTANT_MAX_WIDTH = 55;
const ASSISTANT_DEFAULT_WIDTH = 30;

const ASSISTANT_WIDTH_KEY =
  "oi3.assistant-panel-width";

const readStoredWidth = () => {
  try {
    const stored =
      window.localStorage.getItem(
        ASSISTANT_WIDTH_KEY,
      );

    if (!stored) {
      return ASSISTANT_DEFAULT_WIDTH;
    }

    const parsed = Number.parseFloat(stored);

    return Number.isFinite(parsed)
      ? clamp(
          parsed,
          ASSISTANT_MIN_WIDTH,
          ASSISTANT_MAX_WIDTH,
        )
      : ASSISTANT_DEFAULT_WIDTH;
  } catch {
    // Private browsing can refuse storage; the default is fine.
    return ASSISTANT_DEFAULT_WIDTH;
  }
};

/* Who caused a change. The activity log has always distinguished these, but
   until the assistant could operate the form there was only ever one answer, so
   the callers hardcoded it. Now a target can be named by either party and the
   log has to say which, so every action the assistant can also perform takes
   this and logs accordingly. */
export type Actor = "human" | "agent";

/* The company list, in the shape the agent reads it. Built once: it is a
   static import, and rebuilding it per render would re-send agent state. */
const agentCompanies: AgentCompany[] = companies.map(
  (company) => ({
    capId: company.capId,
    name: company.name,
    ticker: company.ticker,
    sector: company.sector,
  }),
);

/* Every chip the peer-set card offers. Static, so built once. */
const allCriteriaLabels = peerCriteria.map(
  (criterion) => criterion.label,
);

export interface OIWorkflowContext {
  selectedTarget: Company | null;

  setSelectedTarget: React.Dispatch<
    React.SetStateAction<Company | null>
  >;

  targetResolved: boolean;

  setTargetResolved: React.Dispatch<
    React.SetStateAction<boolean>
  >;

  /* Name a target and log it against whoever did it. Shared by the setup card
     and the assistant's own tool, so the two cannot diverge on what naming a
     target means. */
  resolveTarget: (
    company: Company,
    actor?: Actor,
  ) => void;

  peerRecommendation: PeerRecommendationResponse | null;

  setPeerRecommendation: React.Dispatch<
    React.SetStateAction<PeerRecommendationResponse | null>
  >;

  /* How broad a peer set to ask for, and what to score comparability on.
     Held here rather than in the setup page because the assistant can set both
     from any screen, and the setup page unmounts when it navigates away. */
  peerSet: PeerSetType;

  setPeerSet: React.Dispatch<
    React.SetStateAction<PeerSetType>
  >;

  criteriaIds: string[];

  setCriteriaIds: React.Dispatch<
    React.SetStateAction<string[]>
  >;

  /* Write to the Log tab. Every step of the workflow shares one log, so it
     lives here rather than in any one page. */
  activity: ActivityLog;

  /* The peer the cursor is on, so the Sources tab can pick out its group.
     Held here because the peer grid and the assistant panel are siblings. */
  hoveredPeerId: string | null;

  setHoveredPeerId: React.Dispatch<
    React.SetStateAction<string | null>
  >;

  /* The peer whose detail view is open, if any. Distinct from the hovered one:
     opening a peer deliberately clears the hover, and the assistant needs to
     know which peer "this one" refers to in both cases. */
  openPeerId: string | null;

  setOpenPeerId: React.Dispatch<
    React.SetStateAction<string | null>
  >;

  /* Open a group in the Sources tab. A rejected candidate can carry pages the
     run read for it, and the only useful thing to do with that count is to go
     and read them, which means switching a tab this page does not own. */
  showSources: (groupId: string) => void;
}

const OIWorkflowLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [selectedTarget, setSelectedTarget] =
    useState<Company | null>(null);

  const [targetResolved, setTargetResolved] =
    useState(false);

  const [peerRecommendation, setPeerRecommendation] =
    useState<PeerRecommendationResponse | null>(null);

  const [peerSet, setPeerSet] =
    useState<PeerSetType>("standard");

  const [criteriaIds, setCriteriaIds] = useState<string[]>(
    defaultPeerCriteriaIds,
  );

  const [hoveredPeerId, setHoveredPeerId] =
    useState<string | null>(null);

  const [openPeerId, setOpenPeerId] =
    useState<string | null>(null);

  /* Carries a counter as well as the group, so asking for the same group twice
     still reaches the panel. Without it the second request would be an
     identical value and change nothing. */
  const [sourcesFocus, setSourcesFocus] =
    useState<{
      groupId: string;
      request: number;
    } | null>(null);

  const showSources = useCallback(
    (groupId: string) =>
      setSourcesFocus((current) => ({
        groupId,
        request: (current?.request ?? 0) + 1,
      })),
    [],
  );

  /* One log per analysis: leaving the workflow unmounts the layout, and coming
     back in starts a fresh one. */
  const activity = useActivityLog("New analysis started");

  const resolveTarget = useCallback(
    (company: Company, actor: Actor = "human") => {
      setSelectedTarget(company);
      setTargetResolved(true);

      /* A new target invalidates the old proposal. Without this the peer step
         would keep showing the previous company's peers. */
      setPeerRecommendation(null);

      const line = `Named target: **${company.name}**`;

      if (actor === "agent") {
        activity.logAgent(line);
      } else {
        activity.logHuman(line);
      }
    },
    [activity],
  );

  /* What the assistant should treat as "this peer". An open detail view wins
     over a hover, because opening one is deliberate and hovering is not. */
  const focusedPeer = useMemo(() => {
    const id = openPeerId ?? hoveredPeerId;

    if (!id || !peerRecommendation) {
      return null;
    }

    const peer = peerRecommendation.rankedPeers.find(
      (candidate) => peerKey(candidate) === id,
    );

    return peer ? cleanCompanyName(peer.companyName) : null;
  }, [openPeerId, hoveredPeerId, peerRecommendation]);

  const agentPage = useMemo(
    () => ({ route: location.pathname, focusedPeer }),
    [location.pathname, focusedPeer],
  );

  const agentSetup = useMemo(
    () => ({
      target: selectedTarget?.name ?? null,
      targetCapId: selectedTarget?.capId ?? null,
      peerSet,
      criteria: criteriaLabels(criteriaIds),
      availableCriteria: allCriteriaLabels,
    }),
    [selectedTarget, peerSet, criteriaIds],
  );

  /* Mirror the screen into the agent. Everything the assistant can answer from
     is put there by this one call. */
  useAgentSync({
    recommendation: peerRecommendation,
    page: agentPage,
    setup: agentSetup,
    activityLog: activity.entries,
    companies: agentCompanies,
  });

  useNavigationTools({ navigate });

  /* The set-up tools stay registered on every screen and refuse once the
     set-up step is behind us. Registering them only on the set-up page was the
     obvious approach and it is worse: the assistant then finds no tool, has no
     result to report, and tells the user it changed the target while the
     screen still shows the old one. A refusal it can read is what stops that. */
  useSetupTools({
    resolveTarget,
    setPeerSet,
    setCriteriaIds,
    activity,
    canEdit: location.pathname === "/oi/setup",
  });

  const bodyRef = useRef<HTMLDivElement>(null);

  const [assistantWidth, setAssistantWidth] =
    useState(readStoredWidth);

  const commitAssistantWidth = useCallback(
    (next: number) => {
      try {
        window.localStorage.setItem(
          ASSISTANT_WIDTH_KEY,
          String(Math.round(next * 10) / 10),
        );
      } catch {
        // Width still applies for this session.
      }
    },
    [],
  );

  const workflowContext: OIWorkflowContext = {
    selectedTarget,
    setSelectedTarget,
    targetResolved,
    setTargetResolved,
    resolveTarget,
    peerRecommendation,
    setPeerRecommendation,
    peerSet,
    setPeerSet,
    criteriaIds,
    setCriteriaIds,
    activity,
    hoveredPeerId,
    setHoveredPeerId,
    openPeerId,
    setOpenPeerId,
    showSources,
  };

  return (
    <div className="oi-setup-shell">
      <header className="oi-setup-topbar">
        <button
          type="button"
          className="oi-dashboard-button"
          onClick={() => navigate("/")}
        >
          <span>←</span>
          Dashboard
        </button>

        <div className="oi-setup-brand">
          <div className="oi-setup-brand-mark">
            OI
          </div>

          <span className="oi-setup-brand-name">
            OI 3.0
          </span>
        </div>

        <div className="oi-setup-case-name">
          {selectedTarget
            ? selectedTarget.name
            : "New analysis"}
        </div>

        {selectedTarget && (
          <div className="oi-setup-sector">
            {/* Inherits the chip's colour: the star is part of the label,
                not a separate accent. */}
            <span aria-hidden="true">★</span>{" "}
            Sector: {selectedTarget.sector}
          </div>
        )}

        <div className="oi-setup-topbar-right">
          <button
            type="button"
            className="oi-share-button"
          >
            Share
          </button>

          <div className="oi-setup-avatar">
            AU
          </div>
        </div>
      </header>

      <div
        className="oi-setup-body"
        ref={bodyRef}
        style={
          {
            "--oi-assistant-width": `${assistantWidth}%`,
          } as React.CSSProperties
        }
      >
        <Outlet context={workflowContext} />

        <AssistantResizer
          containerRef={bodyRef}
          width={assistantWidth}
          min={ASSISTANT_MIN_WIDTH}
          max={ASSISTANT_MAX_WIDTH}
          onWidthChange={setAssistantWidth}
          onCommit={commitAssistantWidth}
        />

        <AssistantPanel
          activity={activity}
          recommendation={peerRecommendation}
          highlightedPeerId={hoveredPeerId}
          sourcesFocus={sourcesFocus}
        />
      </div>
    </div>
  );
};

export default OIWorkflowLayout;
