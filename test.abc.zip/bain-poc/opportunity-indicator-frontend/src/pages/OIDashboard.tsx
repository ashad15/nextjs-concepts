import { useMemo, useState } from "react";

import { useNavigate } from "react-router-dom";

import Header from "../components/Header";
import OICard from "../components/OICard";
import CreateOICard from "../components/CreateOICard";
import type { OpportunityIndicator } from "../types/oi";
import "../styles/OIDashboard.css";

const OIDashboard = () => {
  const [search, setSearch] = useState("");
  const [ois, setOis] = useState<OpportunityIndicator[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  const navigate = useNavigate();

  const filteredOIs = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return ois;
    }

    return ois.filter((oi) =>
      `${oi.name} ${oi.sector}`.toLowerCase().includes(query)
    );
  }, [ois, search]);

  const showMessage = (text: string) => {
    setMessage(text);

    window.setTimeout(() => {
      setMessage(null);
    }, 2500);
  };

  // Straight into the workflow: the OI is only real once a target is chosen,
  // so setup is where it gets created rather than here.
  const createOI = () => {
    navigate("/oi/setup");
  };

  const deleteOI = (id: string) => {
    setOis((current) =>
      current.filter((oi) => oi.id !== id)
    );

    showMessage("OI deleted.");
  };

  const openOI = (oi: OpportunityIndicator) => {
    showMessage(`Opening ${oi.name}...`);
  };

  return (
    <>
      <Header />

      <main className="dashboard-wrapper">
        <section className="dashboard-heading">
          <div>
            <h1>Opportunity Indicators</h1>

            <p>
              Every OI you and your team are building.
              Open one to pick up where you left off,
              or spin up a new one for any target in minutes.
            </p>
          </div>

          <button
            type="button"
            className="primary-create-button"
            onClick={createOI}
          >
            <span>+</span>
            Create new OI
          </button>
        </section>

        <div className="search-container">
          <span className="search-icon">⌕</span>

          <input
            type="text"
            value={search}
            onChange={(event) =>
              setSearch(event.target.value)
            }
            placeholder="Search by company or sector…"
          />

          {search && (
            <button
              type="button"
              className="clear-search"
              onClick={() => setSearch("")}
            >
              ×
            </button>
          )}
        </div>

        <div className="section-label">
          Your OIs · {ois.length}
        </div>

        <div className="oi-grid">
          {filteredOIs.map((oi) => (
            <OICard
              key={oi.id}
              oi={oi}
              onDelete={deleteOI}
              onOpen={openOI}
            />
          ))}

          {!search && (
            <CreateOICard onCreate={createOI} />
          )}
        </div>

        {search && filteredOIs.length === 0 && (
          <div className="empty-state">
            <h3>No OIs match your search</h3>
            <p>Try a different company or sector.</p>
          </div>
        )}

        {!search && ois.length === 0 && (
          <div className="initial-hint">
            No Opportunity Indicators have been created yet.
          </div>
        )}
      </main>

      {message && (
        <div className="toast-message">
          {message}
        </div>
      )}
    </>
  );
};

export default OIDashboard;