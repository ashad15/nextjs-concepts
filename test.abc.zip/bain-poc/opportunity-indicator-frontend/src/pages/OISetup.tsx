import { useCallback, useRef, useState } from "react";

import {
  useNavigate,
  useOutletContext,
} from "react-router-dom";

import { useHumanInTheLoop } from "@copilotkit/react-core/v2";
import { z } from "zod";

import SetupStepper from "../components/OISetup/SetupStepper";
import TargetSetupCard from "../components/OISetup/TargetSetupCard";
import ContextSetupCard from "../components/OISetup/ContextSetupCard";
import FramingSetupCard from "../components/OISetup/FramingSetupCard";
import PeerSetCard, {
  type PeerSetType,
} from "../components/OISetup/PeerSetCard";
import DocumentsCard from "../components/OISetup/DocumentsCard";
import PeerAnalysisLoader from "../components/OISetup/PeerAnalysisLoader";

import ConfirmRunCard from "../copilot/ConfirmRunCard";
import { OI_AGENT_ID } from "../copilot/agent";

import type { Actor, OIWorkflowContext } from "../layouts/OIWorkflowLayout";
import { auditRun } from "../utils/metricAudit";

import type { PeerRecommendationResponse } from "../types/peer";

import { criteriaLabels } from "../data/peerCriteria";

import { getPeerRecommendations } from "../services/peerApi";

import type { ProgressStatus } from "../hooks/useScriptedProgress";

import "../styles/OISetup.css";

/* What the recommendation call left behind for the analysis screen to hand
   on once it has finished narrating. */
type Outcome =
  | { ok: true; recommendation: PeerRecommendationResponse }
  | { ok: false; message: string }
  | null;

/* What the agent did, in one line.
   No "flagged for review": the only signal available is the concerns list, and
   the model writes concerns for nearly every peer, so flagging on it would
   flag the whole set. Review flagging needs a rule of its own first. */
/* "Proposed 7 peers" says nothing about the work behind it, and the work is
   the reason to trust the answer. This says what was actually compared, over
   how much material, so the entry stands on its own before anyone opens it. */
const describeProposal = (
  recommendation: PeerRecommendationResponse,
) => {
  const count = recommendation.rankedPeers.length;

  const audit = auditRun(
    recommendation.rankedPeers,
    recommendation.sources,
  );

  const parts = [
    `Proposed **${count} ${count === 1 ? "peer" : "peers"}**`,
  ];

  if (audit.metricsCompared > 0) {
    parts.push(
      `compared **${audit.metricsCompared} figures** across ${audit.researched} of them`,
    );
  }

  if (audit.sourcesSearched > 0) {
    parts.push(
      `read **${audit.sourcesSearched} pages**`,
    );
  }

  if (audit.documentsRetrieved > 0) {
    parts.push(
      `found **${audit.documentsRetrieved} filings**`,
    );
  }

  return parts.join(", ");
};

const OISetup = () => {
  const navigate = useNavigate();

  const {
    selectedTarget,
    setSelectedTarget,
    targetResolved,
    setTargetResolved,
    resolveTarget,
    peerRecommendation,
    setPeerRecommendation,
    peerSet: selectedPeerSet,
    setPeerSet: setSelectedPeerSet,
    criteriaIds: selectedCriteria,
    setCriteriaIds: setSelectedCriteria,
    activity,
  } =
    useOutletContext<OIWorkflowContext>();

  /* Null until a proposal exists, which is what keeps the step's own
     sub-line ("Unlocks after target") in place until then. */
  const proposedPeers =
    peerRecommendation?.rankedPeers
      .length ?? null;

  const [loadingPeers, setLoadingPeers] =
    useState(false);

  const [peerError, setPeerError] =
    useState<string | null>(null);

  /* The call's outcome, parked until the analysis screen has finished
     narrating. A ref, not state: the screen reads it from a callback whose
     identity changes on every log entry, and a ref cannot go stale. */
  const outcomeRef = useRef<Outcome>(null);

  const [analysisStatus, setAnalysisStatus] =
    useState<ProgressStatus>("pending");

  /* What the user decided on the confirmation card, so it can say so after the
     buttons are gone. Read from the card's own render, which by then is past
     "executing" and has no other way of knowing which button was pressed. */
  const [runDecision, setRunDecision] = useState<
    "confirmed" | "cancelled" | null
  >(null);

  const getMaxPeers = (
    peerSet: PeerSetType
  ) => {
    switch (peerSet) {
      case "tight":
        return 4;

      case "broad":
        return 10;

      case "standard":
      default:
        return 7;
    }
  };

  const handleProceedToPeers = async (
    actor: Actor = "human",
  ) => {
    if (
      !selectedTarget ||
      selectedCriteria.length === 0
    ) {
      return;
    }

    const criteria = criteriaLabels(
      selectedCriteria
    );

    const maxPeers = getMaxPeers(
      selectedPeerSet
    );

    setPeerError(null);

    outcomeRef.current = null;

    setAnalysisStatus("pending");

    setLoadingPeers(true);

    /* Same sentence either way, filed against whoever started the run. This is
       the line the requirement is about: a run the assistant kicked off has to
       read as Agent, so that reviewing the log afterwards shows who decided
       what. */
    const line = `Asked for **up to ${maxPeers} peers** on ${criteria.length} criteria: ${criteria.join(
      ", "
    )}`;

    if (actor === "agent") {
      activity.logAgent(line);
    } else {
      activity.logHuman(line);
    }

    /*
     * No minimum delay here any more. The analysis screen owns the pacing:
     * it narrates the backend's real steps, waits out a slow call on the
     * research step, and compresses what is left once the answer is in hand.
     * A cached response therefore still takes about twelve seconds to land,
     * rather than announcing itself by returning instantly.
     */
    try {
      const recommendation =
        await getPeerRecommendations({
          capId:
            selectedTarget.capId,

          companyName:
            selectedTarget.name,

          ticker:
            selectedTarget.ticker,

          basicMetrics: criteria,

          maxPeers,
        });

      outcomeRef.current = {
        ok: true,
        recommendation,
      };

      setAnalysisStatus("ready");
    } catch (error) {
      console.error(
        "Peer recommendation API error:",
        error
      );

      outcomeRef.current = {
        ok: false,
        message:
          "Unable to generate peer recommendations. Please try again.",
      };

      setAnalysisStatus("failed");
    }
  };

  /* The one action the assistant cannot take on its own.

     Everything else it can do is cheap and reversible: naming a target or
     ticking a criterion can be undone with a click. This spends money, takes a
     couple of minutes of live search, and throws away whatever peer set is
     already on screen, so it goes through the user.

     The handler is synthesized from `respond`, so every branch has to call it,
     including the refusal. A branch that does not leaves the agent's run open
     and the chat stuck mid-turn.

     The dependency array is not optional here, and leaving it off is a quiet
     failure rather than a loud one. Without it the tool is registered once and
     `render` keeps the closure it had at mount, so the card reports whatever
     the form held when the page loaded: no target, the three default criteria.
     It then reads its own stale values as "nothing to run" and answers itself,
     so the user never sees a button. */
  useHumanInTheLoop(
    {
      agentId: OI_AGENT_ID,
      name: "run_peer_analysis",
      description:
        "Ask the user to confirm starting the peer analysis, and start it if " +
        "they agree. Calling this does NOT start the run on its own: it shows " +
        "a confirmation card in the chat with the current settings, and the " +
        "user decides there. So call it as soon as the user wants the analysis " +
        "run. Do not ask for confirmation in a message first, that would ask " +
        "twice. Set the target and the criteria before calling it.",
      parameters: z.object({}),
      render: ({ status, respond }) => {
        const missing = !selectedTarget
          ? "no target company has been named yet"
          : selectedCriteria.length === 0
            ? "no comparability criteria are ticked"
            : null;

        return (
          <ConfirmRunCard
            target={selectedTarget?.name ?? null}
            peerSet={selectedPeerSet}
            criteriaIds={selectedCriteria}
            maxPeers={getMaxPeers(selectedPeerSet)}
            blockedBecause={missing}
            outcome={
              status === "complete" ? runDecision : null
            }
            /* Nothing is answered from inside render. Responding there would
               be a side effect during a render pass, and it would fire again
               on every re-render until the state caught up. The user's click
               is the only thing that answers. */
            onConfirm={
              status === "executing" && !missing
                ? () => {
                    setRunDecision("confirmed");
                    respond?.(
                      "The user confirmed. The analysis is running now.",
                    );
                    void handleProceedToPeers("agent");
                  }
                : undefined
            }
            onCancel={
              status === "executing"
                ? () => {
                    setRunDecision("cancelled");
                    respond?.(
                      missing
                        ? `Cannot run: ${missing}. Fix that first, then ask again.`
                        : "The user declined. Do not start the analysis. Ask " +
                          "what they would like to change first.",
                    );
                  }
                : undefined
            }
          />
        );
      },
    },
    [
      selectedTarget,
      selectedPeerSet,
      selectedCriteria,
      runDecision,
      handleProceedToPeers,
    ],
  );

  /* Runs once the analysis screen has finished, whatever finished it. */
  const handleAnalysisComplete = useCallback(() => {
    const outcome = outcomeRef.current;

    setLoadingPeers(false);

    if (!outcome) {
      return;
    }

    if (!outcome.ok) {
      setPeerError(outcome.message);

      activity.logSystem(
        "Peer proposal failed. No peers were returned."
      );

      return;
    }

    setPeerRecommendation(
      outcome.recommendation
    );

    activity.logAgent(
      describeProposal(outcome.recommendation),
      "peer-audit",
    );

    navigate("/oi/peers");
  }, [
    activity,
    navigate,
    setPeerRecommendation,
  ]);

  if (
    loadingPeers &&
    selectedTarget
  ) {
    return (
      <section className="oi-setup-workspace">
        <SetupStepper
          currentStep={0}
          proposedPeers={proposedPeers}
        />

        <PeerAnalysisLoader
          company={
            selectedTarget
          }
          status={analysisStatus}
          onComplete={
            handleAnalysisComplete
          }
        />
      </section>
    );
  }

  return (
    <section className="oi-setup-workspace">
      <SetupStepper
        currentStep={0}
        proposedPeers={proposedPeers}
      />

      <div className="oi-setup-scroll">
        <div className="oi-setup-inner">
          <div className="oi-setup-heading">
            Set up the analysis
          </div>

          <div className="oi-setup-lede">
            Start with a company name, then add the
            context, framing, peer preferences and
            supporting documents needed for the analysis.
          </div>

          <TargetSetupCard
            resolved={
              targetResolved
                ? selectedTarget
                : null
            }
            onResolved={(company) => {
              setPeerError(null);
              resolveTarget(company);
            }}
            onRemove={() => {
              setSelectedTarget(null);
              setTargetResolved(false);
              setPeerRecommendation(null);
              setPeerError(null);
            }}
          />

          <ContextSetupCard
            visible={
              targetResolved
            }
          />

          <FramingSetupCard
            visible={
              targetResolved
            }
          />

          <PeerSetCard
            visible={
              targetResolved
            }
            selectedPeerSet={
              selectedPeerSet
            }
            selectedCriteria={
              selectedCriteria
            }
            onPeerSetChange={
              setSelectedPeerSet
            }
            onCriteriaChange={
              setSelectedCriteria
            }
          />

          <DocumentsCard
            visible={
              targetResolved
            }
          />

          {peerError && (
            <div className="peer-api-error">
              {peerError}
            </div>
          )}
        </div>
      </div>

      <div className="oi-setup-proceed">
        <div className="oi-setup-proceed-left">
          {selectedTarget ? (
            <>
              <strong>
                {
                  selectedTarget.name
                }
              </strong>

              <span>
                {" "}
                is ready for peer proposal.
              </span>
            </>
          ) : (
            <span>
              Name a target to begin.
            </span>
          )}
        </div>

        <div className="oi-setup-proceed-right">
          <span className="oi-autosave">
            ✓ Auto-saved
          </span>

          <button
            type="button"
            className="oi-propose-peers-button"
            disabled={
              !selectedTarget ||
              loadingPeers ||
              selectedCriteria.length === 0
            }
            onClick={() =>
              handleProceedToPeers("human")
            }
          >
            Propose peers
            <span>→</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default OISetup;