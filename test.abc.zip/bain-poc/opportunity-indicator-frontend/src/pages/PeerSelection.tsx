import { useEffect, useMemo, useState } from "react";

import {
  useNavigate,
  useOutletContext,
} from "react-router-dom";

import SetupStepper from "../components/OISetup/SetupStepper";
import PeerSummary from "../components/Peers/PeerSummary";
import PeerFilters from "../components/Peers/PeerFilters";

import PeerTable, {
  type Peer,
} from "../components/Peers/PeerTable";

import AIRecommendations from "../components/Peers/AIRecommendations";
import SourceCard from "../components/Peers/SourceCard";
import PeerDocuments from "../components/Peers/PeerDocuments";

import AddPeerSheet, {
  type AddCandidate,
} from "../components/Peers/AddPeerSheet";

import type { OIWorkflowContext } from "../layouts/OIWorkflowLayout";

import { companies } from "../data/companies";

import { getCompany } from "../services/peerApi";

import { peerConfidenceLevel } from "../utils/peerConfidence";
import { peerKey } from "../utils/peerKey";
import { peerSourceLabel } from "../utils/peerSource";
import { rejectedPeers } from "../utils/excludedPeers";
import { internalFigures } from "../utils/internalMetrics";
import {
  cleanCompanyName,
  sameCompany,
} from "../utils/companyName";

import "../styles/PeerSelection.css";

const matchesQuery = (
  candidate: AddCandidate,
  query: string,
) =>
  !query ||
  candidate.name
    .toLowerCase()
    .includes(query) ||
  candidate.ticker
    .toLowerCase()
    .includes(query) ||
  candidate.id
    .toLowerCase()
    .includes(query);

/* =========================================================
   RADAR / SPIDER CHART
========================================================= */

interface RadarCriterion {
  label: string;
  value: number;
}

interface PeerRadarChartProps {
  criteria: RadarCriterion[];
}

const PeerRadarChart = ({
  criteria,
}: PeerRadarChartProps) => {
  const size = 420;

  const centerX = 210;
  const centerY = 205;

  const radius = 118;

  const levels = [0.25, 0.5, 0.75, 1];

  const getPoint = (
    index: number,
    normalizedValue: number
  ) => {
    const angle =
      -Math.PI / 2 +
      (index * 2 * Math.PI) /
        criteria.length;

    return {
      x:
        centerX +
        Math.cos(angle) *
          radius *
          normalizedValue,

      y:
        centerY +
        Math.sin(angle) *
          radius *
          normalizedValue,
    };
  };

  const getPolygonPoints = (
    normalizedValue: number
  ) => {
    return criteria
      .map((_, index) => {
        const point = getPoint(
          index,
          normalizedValue
        );

        return `${point.x},${point.y}`;
      })
      .join(" ");
  };

  const dataPolygonPoints = criteria
    .map((criterion, index) => {
      const normalized =
        Math.max(
          0,
          Math.min(
            criterion.value,
            100
          )
        ) / 100;

      const point = getPoint(
        index,
        normalized
      );

      return `${point.x},${point.y}`;
    })
    .join(" ");

  const labelPoints = criteria.map(
    (criterion, index) => {
      const angle =
        -Math.PI / 2 +
        (index * 2 * Math.PI) /
          criteria.length;

      const labelRadius = radius + 46;

      return {
        label: criterion.label,

        x:
          centerX +
          Math.cos(angle) *
            labelRadius,

        y:
          centerY +
          Math.sin(angle) *
            labelRadius,
      };
    }
  );

  return (
    <div className="peer-radar-wrapper">
      <svg
        className="peer-radar-chart"
        viewBox={`0 0 ${size} ${size}`}
        role="img"
        aria-label="Peer selection criteria radar chart"
      >
        {/* GRID POLYGONS */}

        {levels.map((level) => (
          <polygon
            key={level}
            points={getPolygonPoints(
              level
            )}
            className="peer-radar-grid"
          />
        ))}

        {/* AXES */}

        {criteria.map(
          (_, index) => {
            const point = getPoint(
              index,
              1
            );

            return (
              <line
                key={index}
                x1={centerX}
                y1={centerY}
                x2={point.x}
                y2={point.y}
                className="peer-radar-axis"
              />
            );
          }
        )}

        {/* DATA AREA */}

        <polygon
          points={dataPolygonPoints}
          className="peer-radar-data"
        />

        {/* DATA POINTS */}

        {criteria.map(
          (criterion, index) => {
            const point = getPoint(
              index,
              Math.max(
                0,
                Math.min(
                  criterion.value,
                  100
                )
              ) / 100
            );

            return (
              <circle
                key={
                  criterion.label
                }
                cx={point.x}
                cy={point.y}
                r="4.5"
                className="peer-radar-point"
              />
            );
          }
        )}

        {/* LABELS */}

        {labelPoints.map(
          (point, index) => (
            <text
              key={point.label}
              x={point.x}
              y={point.y}
              className="peer-radar-label"
              textAnchor={
                point.x <
                centerX - 10
                  ? "end"
                  : point.x >
                      centerX +
                        10
                    ? "start"
                    : "middle"
              }
              dominantBaseline="middle"
            >
              {
                criteria[index]
                  .label
              }
            </text>
          )
        )}
      </svg>
    </div>
  );
};

/* =========================================================
   PAGE
========================================================= */

const PeerSelection = () => {
  const navigate = useNavigate();

  const {
    selectedTarget,
    peerRecommendation,
    activity,
    setHoveredPeerId,
    setOpenPeerId,
    showSources,
  } =
    useOutletContext<OIWorkflowContext>();

  /* A tile can be unmounted mid-hover, by opening a peer or leaving the step,
     and mouseleave does not fire when the element goes away underneath the
     cursor. Without this the panel would keep a group lit for a peer that is
     no longer on screen. */
  useEffect(
    () => () => setHoveredPeerId(null),
    [setHoveredPeerId],
  );

  /* What the agent proposed, which is what the stepper shows. Not the
     current selection: dropping a peer does not un-propose it. */
  const proposedPeers =
    peerRecommendation?.rankedPeers
      .length ?? null;

  const apiPeers = useMemo<
    Peer[]
  >(() => {
    if (!peerRecommendation) {
      return [];
    }

    return peerRecommendation.rankedPeers.map(
      (peer) => ({
        id: peerKey(peer),

        name: cleanCompanyName(
          peer.companyName
        ),

        ticker: peer.ticker,

        reason:
          peer.reasons.length > 0
            ? peer.reasons[0]
            : "Recommended by the peer selection service.",

        confidence:
          peerConfidenceLevel(peer),

        confidenceScore:
          peer.confidence?.score,

        recommendedBy:
          peer.recommendedBy,

        selected: true,

        flagged:
          peer.concerns.length >
          0,

        manuallyAdded: false,
      })
    );
  }, [peerRecommendation]);

  const [peers, setPeers] =
    useState<Peer[]>(apiPeers);

  const [
    selectedFilter,
    setSelectedFilter,
  ] = useState("All");

  const [
    selectedPeerId,
    setSelectedPeerId,
  ] =
    useState<string | null>(
      null
    );

  /* Tell the workflow which peer is open, so the assistant can resolve "this
     one" to it. Mirrored through an effect rather than pushed from each call
     site: the detail view is opened from more than one place, and one of them
     forgetting would leave the assistant talking about the wrong company.
     Cleared on the way out so a stale peer does not outlive the view. */
  useEffect(() => {
    setOpenPeerId(selectedPeerId);

    return () => setOpenPeerId(null);
  }, [selectedPeerId, setOpenPeerId]);

  const [
    addPeerOpen,
    setAddPeerOpen,
  ] = useState(false);

  const [
    newPeerName,
    setNewPeerName,
  ] = useState("");

  /* Candidates the agent ranked against this target and left out, with its
     own reason for each. They were assessed on the same criteria as the peers
     on screen, so they belong above the untouched company list rather than
     mixed into it. */
  const consideredCandidates =
    useMemo<AddCandidate[]>(() => {
      const query =
        newPeerName.trim().toLowerCase();

      return rejectedPeers(
        peerRecommendation,
      )
        .map((candidate) => ({
          id: `considered-${candidate.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")}`,

          name: candidate.name,

          /* The rerank reports an excluded peer by name alone. The ticker and
             sector come from the internal set where we hold the company, and
             the page count from what the run actually read for it. */
          ticker: candidate.ticker,
          sector: candidate.sector,
          capId: candidate.capId,

          finalScore: candidate.finalScore,
          recommendedBy: candidate.recommendedBy,

          pageCount: candidate.pageCount,
          sourceGroupId: candidate.sourceGroupId,

          reason: candidate.reason,

          origin: "considered" as const,
        }))
        .filter(
          (candidate) =>
            !peers.some((peer) =>
              sameCompany(
                peer.name,
                candidate.name
              )
            ) && matchesQuery(candidate, query)
        )
        /* Closest call first. The rerank returns these in no particular
           order, and the one worth arguing about is the one it scored highest
           and still left out, not whichever it happened to name first. A
           candidate it did not score sinks to the bottom rather than sorting
           as a zero. */
        .sort(
          (left, right) =>
            (right.finalScore ?? -1) -
            (left.finalScore ?? -1)
        );
    }, [
      newPeerName,
      peerRecommendation,
      peers,
    ]);

  const availablePeerCompanies =
    useMemo<AddCandidate[]>(() => {
      const query =
        newPeerName.trim().toLowerCase();

      return companies
        .filter((company) => {
          const isTarget =
            selectedTarget?.capId ===
              company.capId ||
            (!!selectedTarget &&
              sameCompany(
                selectedTarget.name,
                company.name
              ));

          const alreadyAdded =
            peers.some(
              (peer) =>
                peer.id === company.capId ||
                sameCompany(
                  peer.name,
                  company.name
                )
            );

          /* Most of the internal set was assessed for this target and turned
             down, and those are listed above with the reason. Repeating them
             here under "never assessed" would contradict the section it sits
             in and offer the same company twice. */
          const alreadyConsidered =
            consideredCandidates.some(
              (candidate) =>
                sameCompany(
                  candidate.name,
                  company.name
                )
            );

          return (
            !isTarget &&
            !alreadyAdded &&
            !alreadyConsidered
          );
        })
        .map((company) => ({
          id: company.capId,
          name: company.name,
          ticker: company.ticker,
          reason: "",
          origin: "list" as const,

          /* Not a recommendation, but it is where the company came from, and
             that is what the chip reports. */
          recommendedBy: "vcc",
        }))
        .filter((candidate) =>
          matchesQuery(candidate, query)
        );
    }, [
      consideredCandidates,
      newPeerName,
      peers,
      selectedTarget,
    ]);

  const selectedCount =
    useMemo(
      () =>
        peers.filter(
          (peer) =>
            peer.selected
        ).length,
      [peers]
    );

  const filteredPeers =
    useMemo(() => {
      if (
        selectedFilter ===
        "All"
      ) {
        return peers;
      }

      if (
        selectedFilter ===
        "High confidence"
      ) {
        return peers.filter(
          (peer) =>
            peer.confidence ===
            "high"
        );
      }

      if (
        selectedFilter ===
        "Review"
      ) {
        return peers.filter(
          (peer) =>
            peer.flagged
        );
      }

      if (
        selectedFilter ===
        "Manually added"
      ) {
        return peers.filter(
          (peer) =>
            peer.manuallyAdded
        );
      }

      return peers;
    }, [
      peers,
      selectedFilter,
    ]);

  const selectedPeer =
    useMemo(() => {
      if (!selectedPeerId) {
        return null;
      }

      return (
        peers.find(
          (peer) =>
            peer.id ===
            selectedPeerId
        ) ?? null
      );
    }, [
      peers,
      selectedPeerId,
    ]);

  const selectedPeerApiData =
    useMemo(() => {
      if (
        !selectedPeer ||
        !peerRecommendation
      ) {
        return null;
      }

      return (
        peerRecommendation.rankedPeers.find(
          (peer) =>
            (peer.capId &&
              peer.capId ===
                selectedPeer.id) ||
            peer.companyName ===
              selectedPeer.name
        ) ?? null
      );
    }, [
      selectedPeer,
      peerRecommendation,
    ]);

  /* =========================================================
     SELECTION CRITERIA FROM API
  ========================================================= */

  const selectionCriteria =
    useMemo(() => {
      if (
        !selectedPeerApiData
      ) {
        return [];
      }

      return [
        {
          label:
            "Business model",

          value:
            selectedPeerApiData
              .selectionCriteria
              .businessModel,
        },
        {
          label:
            "Revenue scale",

          value:
            selectedPeerApiData
              .selectionCriteria
              .revenueScale,
        },
        {
          label:
            "Regional",

          value:
            selectedPeerApiData
              .selectionCriteria
              .regionalExposure,
        },
        {
          label:
            "End market",

          value:
            selectedPeerApiData
              .selectionCriteria
              .endMarket,
        },
        {
          label:
            "Product mix",

          value:
            selectedPeerApiData
              .selectionCriteria
              .productMix,
        },
        {
          label:
            "Growth",

          value:
            selectedPeerApiData
              .selectionCriteria
              .growthProfile,
        },
      ].filter(
        (
          criterion
        ): criterion is {
          label: string;
          value: number;
        } =>
          typeof criterion.value ===
          "number"
      );
    }, [selectedPeerApiData]);

  const averageComparability =
    useMemo(() => {
      if (
        selectionCriteria.length ===
        0
      ) {
        return 0;
      }

      const total =
        selectionCriteria.reduce(
          (
            sum,
            criterion
          ) =>
            sum +
            criterion.value,
          0
        );

      return (
        total /
        selectionCriteria.length
      );
    }, [selectionCriteria]);

  /* One derivation for the wording and the colour. They used to be computed
     from different thresholds, 60 for the label and 75 for the class, so a
     peer scoring in between was labelled "High comparability" in the amber
     style meant for medium. */
  const comparability =
    averageComparability >= 75
      ? {
          tone: "high",
          label: "High comparability",
        }
      : averageComparability >= 55
        ? {
            tone: "medium",
            label: "Medium comparability",
          }
        : {
            tone: "low",
            label: "Lower comparability",
          };

  /* =========================================================
     PEER SELECTION
  ========================================================= */

  const togglePeer = (
    id: string
  ) => {
    setPeers((current) =>
      current.map(
        (peer) =>
          peer.id === id
            ? {
                ...peer,

                selected:
                  !peer.selected,
              }
            : peer
      )
    );

    // Read from the list before the update rather than inside the updater:
    // the updater can run twice under StrictMode, and a log entry must not.
    const peer = peers.find(
      (candidate) => candidate.id === id
    );

    if (peer) {
      activity.logHuman(
        peer.selected
          ? `Dropped **${peer.name}** from the peer set`
          : `Put **${peer.name}** back in the peer set`
      );
    }
  };

  const closeAddPeerModal = () => {
    setAddPeerOpen(false);
    setNewPeerName("");
  };

  /* Takes the candidate rather than reading a selection: the sheet adds in one
     action, so there is no selected row to consult. */
  const addPeer = (
    candidate: AddCandidate
  ) => {
    const alreadyAdded = peers.some(
      (peer) =>
        peer.id === candidate.id ||
        sameCompany(
          peer.name,
          candidate.name
        )
    );

    if (alreadyAdded) {
      return;
    }

    const considered =
      candidate.origin === "considered";

    const newPeer: Peer = {
      id: candidate.id,

      name:
        candidate.name,

      ticker:
        candidate.ticker,

      /* An agent-considered peer keeps the rerank's own words for why it was
         left out. Overwriting that with "manually added" would throw away the
         one thing that makes putting it back an informed decision. */
      reason: considered
        ? candidate.reason
        : "Manually added from the available company list for this PoC.",

      confidence: "low",

      selected: true,

      manuallyAdded: true,

      addedFrom: candidate.origin,

      recommendedBy: candidate.recommendedBy,
    };

    setPeers((current) => [
      ...current,
      newPeer,
    ]);

    /* A company we hold has a full internal row, and a peer added by hand used
       to arrive with nothing on it. Fetched after the peer is in the set, so
       the tile appears at once and the figures follow. */
    if (candidate.capId) {
      getCompany(candidate.capId)
        .then((row) =>
          setPeers((current) =>
            current.map((peer) =>
              peer.id === newPeer.id
                ? { ...peer, internalRow: row }
                : peer
            )
          )
        )
        .catch(() => {
          // The peer is still in the set; only its figures are missing.
        });
    }

    activity.logHuman(
      considered
        ? `Added **${newPeer.name}** back to the peer set, which the agent had left out`
        : `Added **${newPeer.name}** to the peer set`
    );

    closeAddPeerModal();
  };

  /* =========================================================
     NO RECOMMENDATION
  ========================================================= */

  if (!peerRecommendation) {
    return (
      <section className="peer-workspace">
        <SetupStepper
          currentStep={1}
          proposedPeers={proposedPeers}
        />

        <div className="peer-page-content">
          <div className="peer-page-heading">
            No peer recommendation
            available
          </div>

          <div className="peer-page-subtitle">
            Please return to
            Target setup and
            generate peer
            recommendations first.
          </div>

          <button
            type="button"
            className="peer-back-button"
            onClick={() =>
              navigate(
                "/oi/setup"
              )
            }
          >
            ← Back to Target
          </button>
        </div>
      </section>
    );
  }

  /* =========================================================
     SINGLE PEER DETAIL
  ========================================================= */

  if (selectedPeer) {
    const confidence =
      selectedPeerApiData
        ?.confidence;

    return (
      <section className="peer-workspace">
        <SetupStepper
          currentStep={1}
          proposedPeers={proposedPeers}
        />

        <div className="peer-detail-header">
          <button
            type="button"
            className="peer-detail-back"
            onClick={() =>
              setSelectedPeerId(
                null
              )
            }
          >
            ← Peers
          </button>

          <span className="peer-detail-separator">
            ›
          </span>

          <strong>
            {selectedPeer.name}
          </strong>
        </div>

        <div className="peer-detail-scroll peer-detail-v3">
          {/* =====================================
              COMPANY HEADER
          ====================================== */}

          <div className="peer-v3-company-header">
            <div>
              <h1>
                {selectedPeer.name}
              </h1>

              <div className="peer-v3-company-ticker">
                {
                  selectedPeer.ticker
                }
              </div>
            </div>

            {selectedPeerApiData && (
              <div className="peer-v3-match-score">
                <span>
                  Peer match score
                </span>

                <strong>
                  {selectedPeerApiData.finalScore.toFixed(
                    1
                  )}{" "}
                  / 10
                </strong>
              </div>
            )}
          </div>

          {/* =====================================
              WHY INCLUDED
          ====================================== */}

          <section className="peer-v3-section">
            <div className="peer-v3-section-title">
              Why included
            </div>

            {selectedPeerApiData ? (
              <ul className="peer-v3-insight-list">
                {selectedPeerApiData.reasons.map(
                  (reason) => (
                    <li
                      key={
                        reason
                      }
                    >
                      {reason}
                    </li>
                  )
                )}
              </ul>
            ) : (
              <p className="peer-v3-body-copy">
                {
                  selectedPeer.reason
                }
              </p>
            )}
          </section>

          {/* =====================================
              CONCERNS
          ====================================== */}

          {selectedPeerApiData &&
            selectedPeerApiData
              .concerns.length >
              0 && (
              <section className="peer-v3-section">
                <div className="peer-v3-section-title">
                  Concerns
                </div>

                <ul className="peer-v3-insight-list peer-v3-concern-list">
                  {selectedPeerApiData.concerns.map(
                    (concern) => (
                      <li
                        key={
                          concern
                        }
                      >
                        {concern}
                      </li>
                    )
                  )}
                </ul>
              </section>
            )}

          {/* =====================================
              SELECTION CRITERIA + RADAR
          ====================================== */}

          {selectionCriteria.length >
            0 && (
            <section className="peer-v3-section peer-v3-radar-section">
              <div className="peer-v3-section-heading-row">
                <div>
                  <span className="peer-v3-section-title peer-v3-section-title-inline">
                    Selection criteria
                  </span>

                  <span className="peer-v3-section-explanation">
                    {" "}
                    — how this peer
                    scores on the
                    factors we chose
                    the set on
                  </span>
                </div>
              </div>

              <div className="peer-v3-comparability-row">
                <span
                  className={`peer-v3-comparability-badge ${comparability.tone}`}
                >
                  {comparability.label}
                </span>

                <span className="peer-v3-factor-count">
                  across{" "}
                  {
                    selectionCriteria.length
                  }{" "}
                  factors
                </span>
              </div>

              <PeerRadarChart
                criteria={
                  selectionCriteria
                }
              />
            </section>
          )}

          {/* =====================================
              KEY METRICS
          ====================================== */}

          {selectedPeerApiData &&
            selectedPeerApiData
              .keyMetrics.length >
              0 && (
              <section className="peer-v3-section">
                <div className="peer-v3-section-title">
                  Key metrics
                </div>

                <div className="peer-v3-metric-grid">
                  {selectedPeerApiData.keyMetrics.map(
                    (metric) => (
                      <div
                        key={
                          metric.metric
                        }
                        className="peer-v3-metric-card"
                      >
                        <strong>
                          {
                            metric.value
                          }
                        </strong>

                        <span>
                          {
                            metric.label
                          }
                        </span>
                      </div>
                    )
                  )}
                </div>
              </section>
            )}

          {/* =====================================
              INTERNAL FIGURES
              For a peer added by hand: it was never researched, so the
              Capital IQ row we already hold is all there is to show.
          ====================================== */}

          {!selectedPeerApiData &&
            internalFigures(
              selectedPeer?.internalRow ?? null
            ).length > 0 && (
              <section className="peer-v3-section">
                <div className="peer-v3-section-title">
                  Key metrics
                  <span className="peer-v3-section-explanation">
                    {" "}
                    — from the internal company
                    set, not research
                  </span>
                </div>

                <div className="peer-v3-metric-grid">
                  {internalFigures(
                    selectedPeer?.internalRow ??
                      null
                  ).map((figure) => (
                    <div
                      key={figure.column}
                      className="peer-v3-metric-card"
                    >
                      <strong>
                        {figure.display}
                      </strong>

                      <span>
                        {figure.label}
                      </span>
                    </div>
                  ))}
                </div>
              </section>
            )}

          {/* =====================================
              CONFIDENCE
          ====================================== */}

          {confidence && (
            <section className="peer-v3-section peer-v3-confidence-section">
              <div className="peer-v3-section-title">
                Confidence
              </div>

              <div className="peer-v3-confidence-score-row">
                <div className="peer-v3-confidence-track">
                  <div
                    className="peer-v3-confidence-fill"
                    style={{
                      width: `${Math.max(
                        0,
                        Math.min(
                          confidence.score,
                          100
                        )
                      )}%`,
                    }}
                  />
                </div>

                <strong className="peer-v3-confidence-score">
                  {
                    confidence.score
                  }
                  %
                </strong>
              </div>

              <p className="peer-v3-confidence-summary">
                {
                  confidence.summary
                }
              </p>

              {confidence.factors
                .length > 0 && (
                <div className="peer-v3-confidence-factors">
                  {confidence.factors.map(
                    (factor) => (
                      <div
                        key={
                          factor.label
                        }
                        className="peer-v3-confidence-factor"
                      >
                        <span>
                          {
                            factor.label
                          }
                        </span>

                        <strong>
                          {String(
                            factor.value
                          )}
                        </strong>
                      </div>
                    )
                  )}
                </div>
              )}
            </section>
          )}

          {/* =====================================
              RECOMMENDATION SOURCE
          ====================================== */}

          <section className="peer-v3-section peer-v3-source-section">
            <div className="peer-v3-section-title">
              Recommendation source
            </div>

            {/* <p className="peer-v3-body-copy">
              {selectedPeerApiData
                ? `Source list ${selectedPeerApiData.sourceList}`
                : "Manual"}
            </p> */}

            {selectedPeerApiData && (
              <p className="peer-v3-body-copy">
                Recommended by:{" "}
                <strong>
                  {peerSourceLabel(
                    selectedPeerApiData.recommendedBy,
                  )?.label ?? "Unknown"}
                </strong>
              </p>
            )}

            {/* Two routes reaching the same company independently is the one
                provenance claim worth stating outright: our universe is a
                curated shortlist and the search is unconstrained, so agreement
                between them is not a coincidence of method. */}
            {selectedPeerApiData?.inBoth && (
              <p className="peer-v3-both-routes">
                Found in the internal set <em>and</em> proposed independently by
                the agent's own search.
              </p>
            )}

            {selectedPeerApiData &&
              (selectedPeerApiData
                .sources.length >
              0 ? (
                <div className="peer-v3-source-list">
                  <div className="peer-v3-source-list-title">
                    Sources
                    <span className="peer-v3-source-count">
                      {
                        selectedPeerApiData
                          .sources
                          .length
                      }
                    </span>
                  </div>

                  {selectedPeerApiData.sources.map(
                    (source) => (
                      <SourceCard
                        key={source.url}
                        source={source}
                      />
                    )
                  )}
                </div>
              ) : (
                <p className="peer-v3-source-empty">
                  No external sources cited
                  for this peer.
                </p>
              ))}

            {selectedPeerApiData && (
              <PeerDocuments
                documents={
                  selectedPeerApiData
                    .documents
                }
              />
            )}
          </section>
        </div>
      </section>
    );
  }

  /* =========================================================
     PEER GRID
  ========================================================= */

  return (
    <section className="peer-workspace">
      <SetupStepper
        currentStep={1}
        proposedPeers={proposedPeers}
      />

      <div className="peer-page-content">
        <PeerSummary
          targetCompany={
            selectedTarget
              ?.name ??
            peerRecommendation
              .target.name
          }
          selectedCount={
            selectedCount
          }
          onAddPeer={() =>
            setAddPeerOpen(
              true
            )
          }
        />

        <PeerFilters
          selectedFilter={
            selectedFilter
          }
          onFilterChange={
            setSelectedFilter
          }
        />

        <AIRecommendations />

        <div className="peer-grid-scroll">
          <PeerTable
            peers={
              filteredPeers
            }
            onToggle={
              togglePeer
            }
            onOpen={(peer) => {
              // The grid is replaced by the detail view, so the tile leaves
              // without a mouseleave of its own.
              setHoveredPeerId(null);

              setSelectedPeerId(
                peer.id
              );
            }}
            onHover={
              setHoveredPeerId
            }
          />
        </div>
      </div>

      <div className="peer-proceed-bar">
        <div className="peer-proceed-count">
          <strong>
            {selectedCount}
          </strong>{" "}
          peers selected
        </div>

        <div className="peer-proceed-actions">
          <button
            type="button"
            className="peer-back-button"
            onClick={() =>
              navigate(
                "/oi/setup"
              )
            }
          >
            Back
          </button>

          <button
            type="button"
            className="peer-confirm-button"
            disabled={
              selectedCount === 0
            }
            onClick={() => {
              activity.logHuman(
                `Confirmed a peer set of **${selectedCount} ${
                  selectedCount === 1
                    ? "peer"
                    : "peers"
                }**`
              );

              window.alert(
                "Peer set confirmed. Case for change will be connected next."
              );
            }}
          >
            Confirm peers
            <span>→</span>
          </button>
        </div>
      </div>

      {/* =====================================
          ADD PEER MODAL
      ====================================== */}

      {addPeerOpen && (
        <AddPeerSheet
          query={newPeerName}
          onQueryChange={setNewPeerName}
          considered={consideredCandidates}
          available={availablePeerCompanies}
          onShowSources={(groupId) => {
            /* The pages are in the panel behind this sheet, so reading them
               means getting out of the way first. */
            closeAddPeerModal();
            showSources(groupId);
          }}
          onAdd={addPeer}
          onClose={closeAddPeerModal}
        />
      )}

    </section>
  );
};

export default PeerSelection;