export interface LinkPreview {
  url: string;
  image: string | null;
  title: string | null;
  siteName: string | null;
  favicon: string | null;
}

/*
 * Served by the Vite dev server (vite-plugins/linkPreview.ts), not the API.
 * A relative path keeps it correct through an ngrok tunnel as well as locally.
 */
const ENDPOINT = "/__link-preview";

const cache = new Map<string, LinkPreview>();

/** Two cards citing the same page must not both fetch it. */
const inFlight = new Map<
  string,
  Promise<LinkPreview | null>
>();

export const getLinkPreview = (
  url: string,
): Promise<LinkPreview | null> => {
  const cached = cache.get(url);

  if (cached) {
    return Promise.resolve(cached);
  }

  const pending = inFlight.get(url);

  if (pending) {
    return pending;
  }

  const request = (async () => {
    try {
      const response = await fetch(
        `${ENDPOINT}?url=${encodeURIComponent(url)}`,
      );

      if (!response.ok) {
        return null;
      }

      const preview: LinkPreview =
        await response.json();

      cache.set(url, preview);

      return preview;
    } catch {
      // No preview is a fine outcome; the card falls back to a monogram.
      return null;
    } finally {
      inFlight.delete(url);
    }
  })();

  inFlight.set(url, request);

  return request;
};
