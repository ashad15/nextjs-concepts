import type {
  PeerRecommendationResponse,
  RecommendedPeer,
  ExcludedPeer,
  PeerRecommendationTarget,
  PeerSource,
  PeerMetric,
  PeerDocument,
  MetricOrigin,
} from "../types/peer";

const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

/* Keys are slugified from the criteria labels we send: see data/peerCriteria.ts. */
interface BackendSelectionCriteria {
  business_model?: number;
  revenue_scale?: number;
  regional_exposure?: number;
  end_market_customers?: number;
  end_market?: number;
  product_mix?: number;
  growth_profile?: number;
  custom_1?: number;
}

interface BackendKeyMetric {
  label: string;
  metric: string;
  value: string;
}

interface BackendConfidenceFactor {
  label: string;
  value: string;
}

interface BackendConfidence {
  score: number;
  summary: string;
  factors: BackendConfidenceFactor[];
}

interface BackendFigure {
  metric: string;
  value: number | null;
  unit?: string | null;
  period?: string | null;
  origin?: string | null;
}

interface BackendEvidence {
  criterion: string;
  score: number;
  evidence: string;
}

interface BackendSource {
  url: string;
  name?: string | null;
  title?: string | null;
  summary?: string | null;
  used_for?: string[];
  figures?: BackendFigure[];
  evidence?: BackendEvidence[];
}

interface BackendMetric {
  value: number | null;
  unit?: string | null;
  period?: string | null;
  origin?: string | null;
  source_url?: string | null;
  source_name?: string | null;
  formula?: string | null;
  formula_latex?: string | null;
  inputs?: string[];
  method?: string | null;
}

interface BackendDocument {
  url: string;
  title?: string | null;
  publisher?: string | null;
  used_for_metrics?: boolean;
  note?: string | null;
}

interface BackendRecommendedPeer {
  rank: number;
  company_name: string;
  ticker: string;
  cap_id: string | null;

  source_list: string;
  in_both: boolean;

  final_score: number;

  reasons: string[];
  concerns: string[];

  selection_criteria?: BackendSelectionCriteria;

  key_metrics?: BackendKeyMetric[];

  business_units?: unknown[];

  confidence?: BackendConfidence;

  recommended_by?: string;

  sources?: BackendSource[];

  metrics?: Record<string, BackendMetric | null>;

  documents?: BackendDocument[];
}

interface BackendResponse {
  target: {
    cap_id: string;

    Ticker: string;
    Name: string;

    SECTOR: string;
    INDUSTRY_GROUP: string;
    INDUSTRY: string;

    REVENUE: number | null;
    EBITDA_MARGIN: number | null;
    MARKET_CAP: number | null;
  };

  best_peer: {
    company_name: string;
    ticker: string;
    cap_id: string | null;
    final_score: number;
    why_best: string;
    recommended_by?: string;
  } | null;

  ranked_peers: BackendRecommendedPeer[];

  excluded: {
    company_name: string;
    why_excluded: string;

    ticker?: string | null;
    source_list?: string | null;
    final_score?: number | null;
  }[];

  counts: {
    vcc: number;
    model: number;
    ranked: number;
  };

  sources: BackendSource[];
}

/* Only these three are meaningful origins. Anything else is treated as sourced,
   which is the conservative reading: it keeps the URL visible. */
const toOrigin = (origin?: string | null): MetricOrigin =>
  origin === "computed" || origin === "modelled" ? origin : "web";

/** One backend source into the shape the cards and the modal read.
 *
 * Shared by the per-peer list and the run-wide list so the two can never drift
 * into showing different things about the same page.
 */
const toSource = (source: BackendSource): PeerSource => ({
  url: source.url,

  name: source.name ?? null,

  title: source.title ?? null,

  summary: source.summary ?? null,

  usedFor: source.used_for ?? [],

  figures: (source.figures ?? []).map((figure) => ({
    metric: figure.metric,
    value: figure.value ?? null,
    unit: figure.unit ?? null,
    period: figure.period ?? null,
    origin: toOrigin(figure.origin),
  })),

  evidence: source.evidence ?? [],
});

const toMetrics = (
  metrics?: Record<string, BackendMetric | null>,
): Record<string, PeerMetric | null> =>
  Object.fromEntries(
    Object.entries(metrics ?? {}).map(([name, entry]) => [
      name,

      entry == null || entry.value == null
        ? null
        : {
            value: entry.value,
            unit: entry.unit ?? null,
            period: entry.period ?? null,
            origin: toOrigin(entry.origin),
            sourceUrl: entry.source_url ?? null,
            sourceName: entry.source_name ?? null,
            formula: entry.formula ?? null,
            formulaLatex: entry.formula_latex ?? null,
            inputs: entry.inputs ?? [],
            method: entry.method ?? null,
          },
    ]),
  );

const toDocuments = (documents?: BackendDocument[]): PeerDocument[] =>
  (documents ?? []).map((document) => ({
    url: document.url,
    title: document.title ?? document.url,
    publisher: document.publisher ?? "",
    // Defaults to false: a document is reference material unless the backend
    // explicitly says otherwise, and it never does today.
    usedForMetrics: document.used_for_metrics ?? false,
    note: document.note ?? "",
  }));

interface GetPeerRecommendationsParams {
  capId: string;
  companyName: string;
  ticker: string;

  /** The comparability criteria ticked in the Peer set card, as labels. */
  basicMetrics: string[];

  maxPeers?: number;
}

export const getPeerRecommendations = async ({
  capId,
  companyName,
  ticker,
  basicMetrics,
  maxPeers = 4,
}: GetPeerRecommendationsParams): Promise<PeerRecommendationResponse> => {
  const queryParams = new URLSearchParams({
    // The backend splits this on commas into one criterion per entry.
    basic_metrics: basicMetrics.join(","),
    max_peers: String(maxPeers),

    company_name: `${companyName} (${ticker})`,

    use_agent: "true",
  });

  const url =
    `${API_BASE_URL}` +
    `/api/v1/peers/recommendation/${encodeURIComponent(capId)}` +
    `?${queryParams.toString()}`;

  const response = await fetch(url, {
    method: "GET",

    headers: {
      accept: "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(
      `Peer recommendation failed with status ${response.status}`,
    );
  }

  const data: BackendResponse = await response.json();

  const target: PeerRecommendationTarget = {
    capId: data.target.cap_id,

    ticker: data.target.Ticker,
    name: data.target.Name,

    sector: data.target.SECTOR,
    industryGroup: data.target.INDUSTRY_GROUP,
    industry: data.target.INDUSTRY,

    revenue: data.target.REVENUE,
    ebitdaMargin: data.target.EBITDA_MARGIN,
    marketCap: data.target.MARKET_CAP,
  };

  const rankedPeers: RecommendedPeer[] = data.ranked_peers.map((peer) => ({
    rank: peer.rank,

    companyName: peer.company_name,

    ticker: peer.ticker,

    capId: peer.cap_id,

    sourceList: peer.source_list,

    inBoth: peer.in_both,

    finalScore: peer.final_score,

    reasons: peer.reasons,

    concerns: peer.concerns,

    selectionCriteria: {
      businessModel: peer.selection_criteria?.business_model,

      revenueScale: peer.selection_criteria?.revenue_scale,

      regionalExposure: peer.selection_criteria?.regional_exposure,

      // The prompt asks for the exact key, but tolerate the shorter form.
      endMarket:
        peer.selection_criteria?.end_market_customers ??
        peer.selection_criteria?.end_market,

      productMix: peer.selection_criteria?.product_mix,

      growthProfile: peer.selection_criteria?.growth_profile,

      custom1: peer.selection_criteria?.custom_1,
    },

    keyMetrics: peer.key_metrics ?? [],

    businessUnits: peer.business_units ?? [],

    confidence: peer.confidence
      ? {
          score: peer.confidence.score,

          summary: peer.confidence.summary,

          factors: peer.confidence.factors,
        }
      : null,

    recommendedBy: peer.recommended_by ?? "unknown",

    sources: (peer.sources ?? []).map(toSource),

    metrics: toMetrics(peer.metrics),

    documents: toDocuments(peer.documents),
  }));

  const excluded: ExcludedPeer[] = data.excluded.map((peer) => ({
    companyName: peer.company_name,

    whyExcluded: peer.why_excluded,

    /* Null rather than absent, so a run from before these were reported reads
       the same as one where the model had nothing to say. */
    ticker: peer.ticker ?? null,
    sourceList: peer.source_list ?? null,
    finalScore: peer.final_score ?? null,
  }));

  return {
    target,

    bestPeer: data.best_peer
      ? {
          companyName: data.best_peer.company_name,

          ticker: data.best_peer.ticker,

          capId: data.best_peer.cap_id,

          finalScore: data.best_peer.final_score,

          whyBest: data.best_peer.why_best,

          recommendedBy: data.best_peer.recommended_by,
        }
      : null,

    rankedPeers,

    excluded,

    counts: data.counts,

    sources: (data.sources ?? []).map(toSource),
  };
};

/** One company's internal row: the Capital IQ figures we already hold.
 *
 * Used for a company the UI knows about but the run did not attach figures to,
 * which is every candidate the rerank assessed and turned down. No model call
 * and no search behind it, so it is cheap enough to fetch on selection.
 */
export const getCompany = async (
  capId: string,
): Promise<Record<string, unknown>> => {
  const response = await fetch(
    `${API_BASE_URL}/api/v1/peers/company/${encodeURIComponent(capId)}`,
    { method: "GET", headers: { accept: "application/json" } },
  );

  if (!response.ok) {
    throw new Error(
      `Company lookup failed with status ${response.status}`,
    );
  }

  const data: { company: Record<string, unknown> } =
    await response.json();

  return data.company;
};
