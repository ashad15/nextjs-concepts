/* The three voices in the activity log.

   human  — something the analyst did: named a target, dropped a peer.
   system — something the app did on its own: started the analysis, failed a call.
   agent  — something the assistant did. Chat is not built yet, so today this
            only covers the peer proposal coming back from the API.
*/
export type ActivityActor = "human" | "system" | "agent";

export interface ActivityEntry {
  id: string;

  actor: ActivityActor;

  /* Wrap the value that matters in ** to bold it in the panel, as in
     "Named target: **Nike, Inc.**". Nothing else in the string is parsed. */
  text: string;

  /* Epoch ms. Stored rather than pre-formatted so "Just now" can age into
     "6 min ago" while the panel is open. */
  at: number;

  /* An entry the reader can open. Today the only one is the data audit behind
     a peer proposal: the log says what was compared, and this is how you go
     and check it. The panel decides what to render; the entry only names it. */
  detail?: "peer-audit";
}
