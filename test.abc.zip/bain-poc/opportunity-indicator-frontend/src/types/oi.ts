export const OI_STAGES = [
  "Target",
  "Peers",
  "Case",
  "Analysis",
  "Output",
] as const;

export type OIStage = (typeof OI_STAGES)[number];

export type OIStatus = "active" | "done" | "draft";

export interface OpportunityIndicator {
  id: string;
  name: string;
  sector: string;
  initials: string;
  stage: number;
  status: OIStatus;
  prize?: string;
  year: number;
  updated: string;
  collaborators: string[];
}