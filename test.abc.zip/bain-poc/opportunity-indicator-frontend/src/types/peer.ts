export interface SelectionCriteria {
  businessModel?: number;
  revenueScale?: number;
  regionalExposure?: number;
  endMarket?: number;
  productMix?: number;
  growthProfile?: number;
  custom1?: number;
}

export interface PeerKeyMetric {
  label: string;
  metric: string;
  value: string;
}

export interface PeerConfidenceFactor {
  label: string;
  value: string;
}

export interface PeerConfidence {
  score: number;
  summary: string;
  factors: PeerConfidenceFactor[];
}

/** Where a figure came from. Sourced values carry a URL, the other two do not. */
export type MetricOrigin = "web" | "computed" | "modelled";

/** One figure read off a page, as the extractor recorded it. */
export interface SourceFigure {
  metric: string;
  value: number | null;

  /** e.g. "USD millions", "ratio", "days". Null when the backend omitted it. */
  unit: string | null;

  /** e.g. "FY2025", "LTM". Null when the page did not say. */
  period: string | null;

  origin: MetricOrigin;
}

/** A comparability rating this page backed, and the sentence justifying it. */
export interface SourceEvidence {
  criterion: string;
  score: number;
  evidence: string;
}

/** A page the agent read for one peer, and what it backed. */
export interface PeerSource {
  url: string;

  /** The publisher, when the agent names one. Falls back to the page title. */
  name: string | null;

  /** The retrieved page title. Null when the join missed. */
  title: string | null;

  /** Real text from the page, kept when it was retrieved. Null on a miss. */
  summary: string | null;

  /** Criterion keys and metric column names, e.g. "business_model", "REVENUE". */
  usedFor: string[];

  /** Figures actually read off this page. */
  figures: SourceFigure[];

  /** Criterion ratings this page justified. Agent route only. */
  evidence: SourceEvidence[];
}

/** One researched metric, carrying how it was arrived at. */
export interface PeerMetric {
  value: number | null;
  unit: string | null;
  period: string | null;

  origin: MetricOrigin;

  /** Sourced values only. */
  sourceUrl: string | null;
  sourceName: string | null;

  /** Computed values only: the arithmetic, in words, e.g. "EBITDA ÷ Revenue". */
  formula: string | null;

  /** The same arithmetic as LaTeX, for typesetting. Null if none was given. */
  formulaLatex: string | null;

  /** Computed values only: the columns it was derived from. */
  inputs: string[];

  /** Modelled values only: the method, spelled out. */
  method: string | null;
}

/** An annual report or filing found for a peer. Never read for a figure. */
export interface PeerDocument {
  url: string;
  title: string;
  publisher: string;
  usedForMetrics: boolean;
  note: string;
}

export interface RecommendedPeer {
  rank: number;
  companyName: string;
  ticker: string;
  capId: string | null;

  sourceList: string;
  inBoth: boolean;

  finalScore: number;

  reasons: string[];
  concerns: string[];

  selectionCriteria: SelectionCriteria;

  keyMetrics: PeerKeyMetric[];

  businessUnits: unknown[];

  confidence: PeerConfidence | null;

  recommendedBy: "agent" | "vcc" | "model" | string;

  /** Empty for peers matched from the internal set rather than researched. */
  sources: PeerSource[];

  /** Researched figures by column name. Empty for internally matched peers. */
  metrics: Record<string, PeerMetric | null>;

  /** Annual reports and filings found for this peer, for reference only. */
  documents: PeerDocument[];
}

export interface ExcludedPeer {
  companyName: string;
  whyExcluded: string;

  /* The rerank scored every candidate before deciding which ones to keep, so
     these are reported rather than recomputed. Optional because a run from
     before the schema carried them returns neither. */
  ticker: string | null;
  sourceList: string | null;
  finalScore: number | null;
}

export interface PeerRecommendationTarget {
  capId: string;

  ticker: string;
  name: string;

  sector: string;
  industryGroup: string;
  industry: string;

  revenue: number | null;
  ebitdaMargin: number | null;
  marketCap: number | null;
}

export interface PeerRecommendationResponse {
  target: PeerRecommendationTarget;

  bestPeer: {
    companyName: string;
    ticker: string;
    capId: string | null;
    finalScore: number;
    whyBest: string;
    recommendedBy?: string;
  } | null;

  rankedPeers: RecommendedPeer[];

  excluded: ExcludedPeer[];

  counts: {
    vcc: number;
    model: number;
    ranked: number;
  };

  /* Every page read during the run, including ones read for a candidate that
     did not survive the ranking. Same shape as a peer's own sources, except
     that usedFor entries are ticker-prefixed: "ALLO: revenue_scale". */
  sources: PeerSource[];
}