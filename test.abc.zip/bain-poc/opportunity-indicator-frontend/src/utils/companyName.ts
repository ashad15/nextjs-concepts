/* A trailing ticker in brackets, with or without its closing bracket, and any
   comma left behind by the source sheet. Our own rows read "Zelluna ASA
   (ZLNA)," and one of them is even unbalanced: "Lakefront Biotherapeutics NV
   (LKFT". */
const TRAILING_TICKER = /\s*\([^)]*\)?$/;
const TRAILING_PUNCTUATION = /[,;\s]+$/;

/**
 * A company name in the form a person would write it.
 *
 * The same company reaches the UI spelled two ways: cleanly from the internal
 * company list, and as the source sheet holds it wherever a name travels
 * through the rerank, which echoes back what it was given. Matching those two
 * as strings fails, which is how a company ended up listed twice in the
 * add-peer sheet, once as assessed and once as never looked at.
 *
 * So every comparison between names, and every name we display, goes through
 * here first.
 */
export const cleanCompanyName = (raw: string) =>
  raw
    .trim()
    .replace(TRAILING_PUNCTUATION, "")
    .replace(TRAILING_TICKER, "")
    .replace(TRAILING_PUNCTUATION, "")
    .trim();

/** True when two names refer to the same company, however each is spelled. */
export const sameCompany = (
  left: string,
  right: string,
) =>
  cleanCompanyName(left).toLowerCase() ===
  cleanCompanyName(right).toLowerCase();
