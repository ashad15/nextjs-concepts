import type {
  PeerDocument,
  PeerRecommendationResponse,
} from "../types/peer";

import {
  peerConfidenceLevel,
  type ConfidenceLevel,
} from "./peerConfidence";

import { peerKey } from "./peerKey";

export interface DocumentGroup {
  id: string;

  title: string;

  ticker: string;

  confidence: ConfidenceLevel | null;

  documents: PeerDocument[];
}

/** Filings for one run, grouped by the peer they were found for.
 *
 * Deliberately the same shape and the same ids as `groupSourcesByPeer`, so the
 * filings tab highlights on a hover from the peer grid exactly as the sources
 * tab does. Ranked peers only, in rank order: a filing is discovered per peer
 * and there is no run-wide list to fold in.
 *
 * A peer with no filings produces no group. Peers matched from the internal set
 * are never researched, so there is nothing to find for them, and an empty
 * group would only say so at the cost of a screenful.
 *
 * The same document can be found for more than one peer, which is why the
 * caller counts distinct URLs rather than summing the groups.
 */
export const groupDocumentsByPeer = (
  recommendation: PeerRecommendationResponse,
): DocumentGroup[] =>
  recommendation.rankedPeers
    .filter((peer) => peer.documents.length > 0)
    .map((peer) => ({
      id: peerKey(peer),
      title: peer.companyName,
      ticker: peer.ticker,
      confidence: peerConfidenceLevel(peer),
      documents: peer.documents,
    }));

/** Distinct documents across the groups, matching the audit panel's count. */
export const countDocuments = (
  groups: DocumentGroup[],
) =>
  new Set(
    groups.flatMap((group) =>
      group.documents.map(
        (document) => document.url,
      ),
    ),
  ).size;
