/** What kind of document a URL points at, inferred from the URL alone.
 *
 * The backend returns filings without classifying them, and the URL is a
 * reliable signal for this narrow case: EDGAR paths, filing form numbers and
 * PDF extensions all appear in it.
 */
export type DocumentKind =
  | "filing"
  | "report"
  | "pdf"
  | "data"
  | "other";

export const documentKind = (
  url: string,
): DocumentKind => {
  const lower = url.toLowerCase();

  if (
    lower.includes("10-k") ||
    lower.includes("20-f") ||
    lower.includes("6-k") ||
    lower.includes("/archives/edgar")
  ) {
    return "filing";
  }

  if (
    lower.includes("annual") ||
    lower.includes("financial-statements")
  ) {
    return "report";
  }

  if (lower.endsWith(".pdf")) {
    return "pdf";
  }

  if (
    lower.includes("stockanalysis") ||
    lower.includes("marketscreener") ||
    lower.includes("morningstar")
  ) {
    return "data";
  }

  return "other";
};

/** Short label a reader recognises, e.g. "10-K". */
export const documentLabel = (
  url: string,
): string => {
  const lower = url.toLowerCase();

  if (lower.includes("10-k")) return "10-K";
  if (lower.includes("20-f")) return "20-F";
  if (lower.includes("6-k")) return "6-K";
  if (lower.includes("/archives/edgar")) return "SEC filing";
  if (lower.includes("annual")) return "Annual report";
  if (lower.endsWith(".pdf")) return "PDF";

  return "Document";
};
