import { companies } from "../data/companies";

import type { PeerRecommendationResponse } from "../types/peer";

import {
  cleanCompanyName,
  sameCompany,
} from "./companyName";

import { groupSourcesByPeer } from "./sourceGroups";

/** A candidate the rerank ranked and left out, with whatever else we hold. */
export interface RejectedPeer {
  name: string;
  reason: string;

  /** From the internal set where we hold the company, otherwise blank. */
  ticker: string;
  sector: string;

  /** Set only where we hold the company, and what the figures are fetched by. */
  capId: string | null;

  /** The rerank's own score for this candidate, where the run reported one. */
  finalScore: number | null;

  /** "vcc", "agent" or "vcc+agent", from the list the rerank ranked it under. */
  recommendedBy: string;

  /** Pages read for this company during the run. */
  pageCount: number;

  /** The group to open in the Sources tab, when there is one. */
  sourceGroupId: string | null;
}

/* A leftover group is titled by the ticker its pages were read for, and the
   rerank reports an excluded peer by name alone. Where the internal set does
   not give us the ticker, this is the only bridge left: SANA against "Sana
   Biotechnology". Kept to a whole-prefix match on a ticker of at least three
   characters, so it cannot pair two different companies by coincidence, and
   it simply finds nothing where it does not apply, as with ARGX and argenx. */
const looksLikeTicker = (
  ticker: string,
  name: string,
) =>
  ticker.length >= 3 &&
  name.toLowerCase().startsWith(ticker.toLowerCase());

/**
 * Everything we already hold about the peers the agent turned down.
 *
 * The rerank returns each one as a name and a sentence, but the run knows more
 * than that and throws none of it away: the internal set carries the ticker and
 * sector for the companies we hold, and the run-wide source list carries the
 * pages read for a candidate that was researched and then dropped. Joining them
 * here means a rejected peer can be argued with rather than only read about.
 */
/* The rerank labels a candidate A, B or BOTH. A company we hold is ours
   whether or not the run said so, which is what covers a run from before the
   label was reported. */
const ROUTES: Record<string, string> = {
  A: "vcc",
  B: "agent",
  BOTH: "vcc+agent",
};

export const rejectedPeers = (
  recommendation: PeerRecommendationResponse | null,
): RejectedPeer[] => {
  if (!recommendation) {
    return [];
  }

  /* Reusing the grouping the Sources tab renders, so the id we hand back is
     always a group that exists there. Two separate derivations of the same id
     would drift, and the link would open on nothing. */
  const leftovers = groupSourcesByPeer(
    recommendation,
  ).filter((group) =>
    group.id.startsWith("unranked-"),
  );

  return recommendation.excluded.map(
    (candidate) => {
      /* The rerank echoes a name in the form it was given, so an internal
         candidate comes back as "Zelluna ASA (ZLNA)," where our own list holds
         "Zelluna ASA". Comparing them as strings is what listed the same
         company twice, once as assessed and once as never looked at. */
      const held = companies.find((company) =>
        sameCompany(
          company.name,
          candidate.companyName,
        ),
      );

      /* The rerank now reports the ticker it ranked the candidate under, which
         is the reliable join. The internal set covers a run from before that,
         and the prefix match is the last resort for a company we do not hold. */
      const ticker =
        candidate.ticker || held?.ticker || "";

      const group = leftovers.find(
        (leftover) =>
          (ticker &&
            leftover.ticker.toLowerCase() ===
              ticker.toLowerCase()) ||
          looksLikeTicker(
            leftover.ticker,
            cleanCompanyName(
              candidate.companyName,
            ),
          ),
      );

      return {
        name: cleanCompanyName(
          candidate.companyName,
        ),
        reason: candidate.whyExcluded,

        ticker: ticker || group?.ticker || "",

        sector: held?.industry ?? "",

        capId: held?.capId ?? null,

        finalScore: candidate.finalScore,

        recommendedBy:
          ROUTES[
            (candidate.sourceList ?? "").toUpperCase()
          ] ?? (held ? "vcc" : "agent"),

        pageCount: group?.sources.length ?? 0,
        sourceGroupId: group?.id ?? null,
      };
    },
  );
};
