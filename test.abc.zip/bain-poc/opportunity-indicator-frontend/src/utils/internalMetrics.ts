import { formatFigure } from "./metricFormat";

export interface InternalFigure {
  column: string;
  label: string;
  value: number;
  display: string;
}

/* What a company's internal row says about it, in the order an analyst reads
   it. The row is 29 metric columns; this is the part that answers "what kind
   of company is this" without becoming a screen of numbers.

   Units are declared here because the source sheet records none: the figures
   are Capital IQ style, amounts in USD millions and ratios as decimals. */
const HEADLINE: {
  column: string;
  label: string;
  unit: string;
}[] = [
  { column: "REVENUE", label: "Revenue", unit: "USD millions" },
  { column: "MARKET_CAP", label: "Market cap", unit: "USD millions" },
  { column: "EBITDA_MARGIN", label: "EBITDA margin", unit: "ratio" },
  { column: "GROSS_MARGIN", label: "Gross margin", unit: "ratio" },
  { column: "REVENUE_GROWTH_1YR", label: "Revenue growth", unit: "ratio" },
  { column: "CAPITAL_EMPLOYED", label: "Capital employed", unit: "USD millions" },
  { column: "LTM_EPS", label: "LTM EPS", unit: "USD per share" },
  { column: "NET_DEBT_EBITDA_1YR", label: "Net debt / EBITDA", unit: "multiple" },
];

/**
 * Readable figures from one internal company row.
 *
 * Columns that are absent or non-numeric are dropped rather than shown empty:
 * the internal set is complete for some companies and sparse for others, and a
 * blank beside a label reads as a value of zero.
 */
export const internalFigures = (
  row: Record<string, unknown> | null,
  limit = HEADLINE.length,
): InternalFigure[] => {
  if (!row) {
    return [];
  }

  return HEADLINE.slice(0, limit)
    .map((metric) => ({
      column: metric.column,
      label: metric.label,

      value:
        typeof row[metric.column] === "number"
          ? (row[metric.column] as number)
          : null,

      unit: metric.unit,
    }))
    .filter(
      (metric): metric is typeof metric & { value: number } =>
        metric.value !== null,
    )
    .map((metric) => ({
      column: metric.column,
      label: metric.label,
      value: metric.value,
      display: formatFigure(
        metric.value,
        metric.unit,
      ),
    }));
};
