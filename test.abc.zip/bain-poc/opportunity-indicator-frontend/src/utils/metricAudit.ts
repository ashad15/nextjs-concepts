import type {
  PeerMetric,
  RecommendedPeer,
} from "../types/peer";

export interface AuditedMetric {
  metric: string;
  entry: PeerMetric;
}

/** One peer's figures, split by where each one came from. */
export interface PeerAudit {
  peer: RecommendedPeer;

  sourced: AuditedMetric[];
  computed: AuditedMetric[];
  modelled: AuditedMetric[];

  /** Columns that were asked for and not found. Named, not hidden. */
  missing: string[];

  /** Distinct pages that supplied at least one figure. */
  pageCount: number;
}

export interface RunAudit {
  peers: PeerAudit[];

  /** Peers carrying researched figures. Internally matched peers have none. */
  researched: number;

  metricsCompared: number;
  sourcesSearched: number;
  documentsRetrieved: number;
}

/** Split one peer's metrics by origin, keeping the column order intact.
 *
 * The order matters: it is the order the backend declares its columns in, so
 * the same metric sits in the same place for every peer and a reader scanning
 * two peers side by side is not re-reading the list each time.
 */
export const auditPeer = (
  peer: RecommendedPeer,
): PeerAudit => {
  const sourced: AuditedMetric[] = [];
  const computed: AuditedMetric[] = [];
  const modelled: AuditedMetric[] = [];
  const missing: string[] = [];

  const pages = new Set<string>();

  for (const [metric, entry] of Object.entries(
    peer.metrics ?? {},
  )) {
    if (!entry || entry.value === null) {
      missing.push(metric);
      continue;
    }

    if (entry.origin === "computed") {
      computed.push({ metric, entry });
      continue;
    }

    if (entry.origin === "modelled") {
      modelled.push({ metric, entry });
      continue;
    }

    sourced.push({ metric, entry });

    if (entry.sourceUrl) {
      pages.add(entry.sourceUrl);
    }
  }

  return {
    peer,
    sourced,
    computed,
    modelled,
    missing,
    pageCount: pages.size,
  };
};

/** The whole run, for the headline counts and the audit panel.
 *
 * `metricsCompared` counts figures that actually carry a value, across every
 * peer. Counting the columns asked for would overstate it, and the number is
 * only worth showing if it is the number a reader can go and check.
 */
export const auditRun = (
  peers: RecommendedPeer[],
  runSources: { url: string }[],
  ): RunAudit => {
  const audits = peers.map(auditPeer);

  const withMetrics = audits.filter(
    (audit) =>
      audit.sourced.length +
        audit.computed.length +
        audit.modelled.length >
      0,
  );

  const metricsCompared = withMetrics.reduce(
    (total, audit) =>
      total +
      audit.sourced.length +
      audit.computed.length +
      audit.modelled.length,
    0,
  );

  /* Pages read for the whole run, deduped: the run-wide list already covers
     candidates that were researched and then dropped. */
  const pages = new Set(
    runSources.map((source) => source.url),
  );

  for (const audit of audits) {
    for (const source of audit.peer.sources) {
      pages.add(source.url);
    }
  }

  const documents = new Set(
    audits.flatMap((audit) =>
      audit.peer.documents.map(
        (document) => document.url,
      ),
    ),
  );

  return {
    peers: audits,
    researched: withMetrics.length,
    metricsCompared,
    sourcesSearched: pages.size,
    documentsRetrieved: documents.size,
  };
};
