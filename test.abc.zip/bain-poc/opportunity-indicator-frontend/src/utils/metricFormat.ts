import type { MetricOrigin } from "../types/peer";

/** How a figure is written, decided by the unit the backend reported.
 *
 * The backend never formats numbers, it reports a value and the unit it is in,
 * so the presentation rules live here rather than being split across the
 * components that happen to show a figure.
 */
export const formatFigure = (
  value: number | null,
  unit: string | null,
): string => {
  if (value === null || Number.isNaN(value)) {
    return "—";
  }

  const lower = (unit ?? "").toLowerCase();

  if (lower.includes("days")) {
    return `${Math.round(value)} days`;
  }

  /* A leverage figure is a multiple. Reading it as a percentage turns -2.2x
     into -221.7%, which reads as a catastrophe rather than a net cash
     position. */
  if (lower.includes("multiple") || lower === "x") {
    return `${value.toFixed(1)}x`;
  }

  /* Per-share amounts are money, just never scaled. */
  if (lower.includes("per share")) {
    const symbol = lower.startsWith("eur")
      ? "€"
      : lower.startsWith("gbp")
        ? "£"
        : "$";

    return `${value < 0 ? "-" : ""}${symbol}${Math.abs(value).toFixed(2)}`;
  }

  if (lower.includes("million")) {
    const currency = (unit ?? "").split(" ")[0] || "";
    const symbol =
      currency === "USD"
        ? "$"
        : currency === "EUR"
          ? "€"
          : currency === "GBP"
            ? "£"
            : `${currency} `;

    const magnitude = Math.abs(value);

    if (magnitude >= 1000) {
      return `${symbol}${(value / 1000).toFixed(1)}B`;
    }

    if (magnitude < 1 && magnitude > 0) {
      return `${symbol}${(value * 1000).toFixed(1)}K`;
    }

    return `${symbol}${value.toFixed(1)}M`;
  }

  /* A bare ratio. Margins really do reach -107, meaning -10700%, for a
     company with almost no revenue, so it is reported rather than rescaled. */
  if (lower.includes("ratio") || unit === null) {
    return `${(value * 100).toFixed(1)}%`;
  }

  return `${value} ${unit}`;
};

/** Whether a passage contains a GFM table, which needs room to be readable.
 *
 * A table is only a table if it has a separator row, so that is what this
 * looks for: a line of dashes and pipes. Prose about a range of years can
 * contain a stray pipe or dash, but not both in that arrangement.
 */
export const hasMarkdownTable = (text: string | null): boolean => {
  if (!text) {
    return false;
  }

  return text
    .split("\n")
    .some(
      (line) =>
        line.includes("---") &&
        (line.match(/\|/g) ?? []).length >= 2,
    );
};

/* Three columns are named for something they do not contain. The names come
   from the source Capital IQ extract and are documented in the backend's
   app/data/peersdata-sources.md, which verified each one against the data.
   Showing the raw name here would put "Fcf sales 3yr" next to a figure that is
   EBITDA, on the one screen whose whole job is being trustworthy. */
const TRUE_NAMES: Record<string, string> = {
  FCF_SALES_3YR: "EBITDA",
  FCF_SALES_2YR: "Net debt",
  NET_DEBT_EBITDA_1YR: "Net debt / EBITDA",
};

/** "REVENUE_GROWTH_1YR" reads as "Revenue growth 1yr". */
export const metricLabel = (metric: string): string => {
  const known = TRUE_NAMES[metric];

  if (known) {
    return known;
  }

  const words = metric.toLowerCase().split("_").join(" ");

  return words.charAt(0).toUpperCase() + words.slice(1);
};

export const originLabel: Record<MetricOrigin, string> = {
  web: "Sourced",
  computed: "Computed",
  modelled: "Modelled",
};

export const originHint: Record<MetricOrigin, string> = {
  web: "Read directly off this page",
  computed: "Calculated from other sourced figures",
  modelled: "No published figure exists; derived from a stated method",
};
