import type { RecommendedPeer } from "../types/peer";

export type ConfidenceLevel = "high" | "medium" | "low";

/** How confident the service is in a peer, as a band.
 *
 * The confidence block is what the agent path returns; peers matched from the
 * internal set arrive without one, so those fall back to the merged ranking
 * score. Shared by the peer table and the Sources panel: two copies of these
 * thresholds would eventually disagree on the same peer.
 */
export const peerConfidenceLevel = (
  peer: Pick<RecommendedPeer, "confidence" | "finalScore">,
): ConfidenceLevel => {
  if (peer.confidence) {
    if (peer.confidence.score >= 70) {
      return "high";
    }

    return peer.confidence.score >= 50 ? "medium" : "low";
  }

  if (peer.finalScore >= 8) {
    return "high";
  }

  return peer.finalScore >= 6 ? "medium" : "low";
};

export const confidenceLabel: Record<ConfidenceLevel, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
};
