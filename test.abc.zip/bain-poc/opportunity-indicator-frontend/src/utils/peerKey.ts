import type { RecommendedPeer } from "../types/peer";

/** Stable id for one recommended peer.
 *
 * Most peers carry a cap_id; ones the model proposed that are not in our
 * universe do not, so rank keeps those distinct. Shared by the peer grid and
 * the source groups: hovering a peer highlights its sources by matching these,
 * which only works while both sides derive the id the same way.
 */
export const peerKey = (
  peer: Pick<RecommendedPeer, "capId" | "ticker" | "rank">,
) => peer.capId ?? `${peer.ticker}-${peer.rank}`;
