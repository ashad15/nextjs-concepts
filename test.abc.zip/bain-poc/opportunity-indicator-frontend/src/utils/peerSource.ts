export type PeerSourceKind = "vcc" | "agent" | "both";

export interface PeerSourceLabel {
  kind: PeerSourceKind;
  label: string;
}

/** What `recommended_by` means, for a chip and for prose.
 *
 * The backend sends "vcc", "agent", "model", or the pair as "vcc+agent" when
 * both routes found the same company. That last case is the strongest
 * provenance a peer has, and it used to fall through every exact-match check
 * and render as nothing at all.
 *
 * Returns null for a value we do not recognise, including "unknown". A peer
 * with no established provenance should show no claim about it.
 */
export const peerSourceLabel = (
  value?: string,
): PeerSourceLabel | null => {
  const parts = (value ?? "")
    .toLowerCase()
    .split("+")
    .map((part) => part.trim())
    .filter(Boolean);

  const ours = parts.includes("vcc");

  /* "model" is the single-prompt path and "agent" the search loop. The
     difference is how the peer was found, not how much it can be trusted, so
     the chip names the engine and stops there. */
  const engine = parts.find(
    (part) => part === "agent" || part === "model",
  );

  if (ours && engine) {
    return {
      kind: "both",
      label:
        engine === "model"
          ? "VCC + Model"
          : "VCC + Agent",
    };
  }

  if (ours) {
    return { kind: "vcc", label: "VCC" };
  }

  if (engine) {
    return {
      kind: "agent",
      label: engine === "model" ? "Model" : "Agent",
    };
  }

  return null;
};
