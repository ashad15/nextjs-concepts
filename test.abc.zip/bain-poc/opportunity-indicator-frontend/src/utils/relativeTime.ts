const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/** How long ago, phrased the way the log shows it: "Just now", "6 min ago".
 *
 * Elapsed time, not calendar days, so "Yesterday" means 24 to 48 hours back.
 * The log is per analysis and clears when the workflow is left, so in practice
 * nothing in it ever ages past a few minutes.
 */
export const relativeTime = (at: number, now: number = Date.now()) => {
  // A clock that jumped backwards should still read "Just now", not a negative.
  const elapsed = Math.max(0, now - at);

  if (elapsed < MINUTE) {
    return "Just now";
  }

  if (elapsed < HOUR) {
    return `${Math.floor(elapsed / MINUTE)} min ago`;
  }

  if (elapsed < DAY) {
    const hours = Math.floor(elapsed / HOUR);

    return hours === 1 ? "1 hour ago" : `${hours} hours ago`;
  }

  const days = Math.floor(elapsed / DAY);

  return days === 1 ? "Yesterday" : `${days} days ago`;
};
