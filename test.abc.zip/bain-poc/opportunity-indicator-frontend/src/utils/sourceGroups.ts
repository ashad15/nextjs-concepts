import type {
  PeerRecommendationResponse,
  PeerSource,
} from "../types/peer";

import {
  peerConfidenceLevel,
  type ConfidenceLevel,
} from "./peerConfidence";

import { peerKey } from "./peerKey";

export interface SourceGroup {
  id: string;

  /** Company name for a ranked peer, ticker for anything else. */
  title: string;

  ticker: string;

  /** Null when the group is not a ranked peer, so no chip is shown. */
  confidence: ConfidenceLevel | null;

  /** Why the group exists at all, when that is not obvious. */
  note?: string;

  sources: PeerSource[];
}

/* The run-wide list tags each criterion with the ticker it was read for, as in
   "ALLO: revenue_scale". A peer's own list carries the bare key. */
const TICKER_PREFIX = /^([A-Z0-9.-]{1,8}):\s*(.+)$/;

const splitPrefix = (usedFor: string) => {
  const match = TICKER_PREFIX.exec(usedFor);

  return match
    ? { ticker: match[1], criterion: match[2] }
    : { ticker: null, criterion: usedFor };
};

/** Sources for one run, grouped by the peer they were read for.
 *
 * Ranked peers come first, in rank order, each with its confidence band. Pages
 * read for a candidate that did not survive the ranking are grouped after,
 * under their ticker: they are part of the research behind the answer, and
 * dropping them would leave the count in the panel header understating what
 * the agent actually read.
 *
 * Peers with no sources produce no group. Peers matched from the internal set
 * are researched by name only, so an empty group would say nothing.
 */
export const groupSourcesByPeer = (
  recommendation: PeerRecommendationResponse,
): SourceGroup[] => {
  const groups: SourceGroup[] = [];

  const claimed = new Set<string>();

  for (const peer of recommendation.rankedPeers) {
    if (peer.sources.length === 0) {
      continue;
    }

    for (const source of peer.sources) {
      claimed.add(source.url);
    }

    groups.push({
      id: peerKey(peer),
      title: peer.companyName,
      ticker: peer.ticker,
      confidence: peerConfidenceLevel(peer),
      sources: peer.sources,
    });
  }

  /* Whatever the run-wide list has that no ranked peer claimed. */
  const leftovers = new Map<string, PeerSource[]>();

  for (const source of recommendation.sources) {
    if (claimed.has(source.url)) {
      continue;
    }

    const criteria = source.usedFor.map(splitPrefix);

    const ticker =
      criteria.find((entry) => entry.ticker)?.ticker ?? "Other";

    const bucket = leftovers.get(ticker) ?? [];

    bucket.push({
      ...source,
      // Strip the prefix so the tags read the same as a peer's own.
      usedFor: criteria.map((entry) => entry.criterion),
    });

    leftovers.set(ticker, bucket);
  }

  for (const [ticker, sources] of leftovers) {
    groups.push({
      id: `unranked-${ticker}`,
      title: ticker,
      ticker,
      confidence: null,
      note: "Researched, not in the final peer set",
      sources,
    });
  }

  return groups;
};

export const countSources = (groups: SourceGroup[]) =>
  groups.reduce((total, group) => total + group.sources.length, 0);
