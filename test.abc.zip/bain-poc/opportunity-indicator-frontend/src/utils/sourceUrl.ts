/** "https://ir.nkartatx.com/news/x" → "ir.nkartatx.com". */
export const sourceHost = (url: string) => {
  try {
    return new URL(url).hostname.replace(
      /^www\./,
      "",
    );
  } catch {
    return url;
  }
};

/* Subdomains that name the section, not the organisation. */
const GENERIC_LABELS = [
  "ir",
  "investor",
  "investors",
  "news",
  "www",
  "web",
  "media",
];

/** The letter shown when a page offers neither an og:image nor a favicon. */
export const sourceMonogram = (host: string) => {
  const meaningful = host
    .split(".")
    .filter(
      (label) =>
        !GENERIC_LABELS.includes(label),
    );

  const word = meaningful[0] ?? host;

  return (word.charAt(0) || "?").toUpperCase();
};

/** The part after the host, for a second line under the publisher. */
export const sourcePath = (url: string) => {
  try {
    const { pathname, search } = new URL(url);

    const path = `${pathname}${search}`;

    return path === "/" ? "" : path;
  } catch {
    return "";
  }
};
