import type { Plugin } from "vite";

/*
 * Dev-server endpoint that reads Open Graph tags off a source page.
 *
 * The browser cannot do this itself: the IR and SEC pages we cite send no
 * Access-Control-Allow-Origin, so a client-side fetch is blocked no matter what
 * origin the app is served from. The Vite dev server is plain Node, so it can
 * make the request and hand back just the bits the card needs.
 *
 * This lives in the dev server only. A production build has no such endpoint,
 * so the same route would need to move to the API before deploying.
 */

const ENDPOINT = "/__link-preview";

/** Long enough for slow IR sites, short enough that a card is not left hanging. */
const FETCH_TIMEOUT_MS = 6000;

/** og:image sits in <head>, so there is no reason to scan a whole document. */
const MAX_HTML_CHARS = 250_000;

/* Several of these hosts serve a default page or a 403 to unknown agents. */
const USER_AGENT =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36";

export interface LinkPreview {
  url: string;
  image: string | null;
  title: string | null;
  siteName: string | null;
  favicon: string | null;
}

const cache = new Map<string, LinkPreview>();

/** Hosts that resolve inside the network the dev server runs on. */
const isPrivateHost = (hostname: string) => {
  const host = hostname.toLowerCase();

  if (
    host === "localhost" ||
    host === "::1" ||
    host.endsWith(".localhost") ||
    host.endsWith(".internal") ||
    host.endsWith(".local")
  ) {
    return true;
  }

  return (
    /^127\./.test(host) ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^169\.254\./.test(host) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    /^0\./.test(host)
  );
};

/**
 * The endpoint is reachable by anyone who can reach the dev server, which
 * includes the whole internet while an ngrok tunnel is open. Keep it to public
 * web pages so it cannot be used to probe the machine or the local network.
 */
const isFetchable = (raw: string) => {
  try {
    const url = new URL(raw);

    return (
      (url.protocol === "http:" ||
        url.protocol === "https:") &&
      !isPrivateHost(url.hostname)
    );
  } catch {
    return false;
  }
};

/** <meta property="og:image" content="..."> in either attribute order. */
const readMeta = (html: string, key: string) => {
  const patterns = [
    new RegExp(
      `<meta[^>]+(?:property|name)=["']${key}["'][^>]*content=["']([^"']+)["']`,
      "i",
    ),
    new RegExp(
      `<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']${key}["']`,
      "i",
    ),
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);

    if (match?.[1]) {
      return decodeEntities(match[1].trim());
    }
  }

  return null;
};

const readFavicon = (html: string) => {
  const match = html.match(
    /<link[^>]+rel=["'][^"']*icon[^"']*["'][^>]*href=["']([^"']+)["']/i,
  );

  return match?.[1]
    ? decodeEntities(match[1].trim())
    : null;
};

const decodeEntities = (value: string) =>
  value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");

/** og:image is often a path, and must be resolved against the page it came from. */
const absolute = (
  value: string | null,
  base: string,
) => {
  if (!value) {
    return null;
  }

  try {
    return new URL(value, base).toString();
  } catch {
    return null;
  }
};

const emptyPreview = (
  url: string,
): LinkPreview => ({
  url,
  image: null,
  title: null,
  siteName: null,
  favicon: null,
});

/*
 * Most of the pages we cite are IR releases and SEC filings, and those carry no
 * og:image — in a sample of the sources one run produced, 2 of 14 had one. When
 * the markup declares no icon either, try the conventional root location so the
 * thumbnail still has something to show.
 */
const probeRootFavicon = async (base: string) => {
  try {
    const { origin } = new URL(base);

    const candidate = `${origin}/favicon.ico`;

    const response = await fetch(candidate, {
      method: "HEAD",

      redirect: "follow",

      signal: AbortSignal.timeout(2500),

      headers: { "user-agent": USER_AGENT },
    });

    return response.ok ? candidate : null;
  } catch {
    return null;
  }
};

const loadPreview = async (
  target: string,
): Promise<LinkPreview> => {
  const response = await fetch(target, {
    redirect: "follow",

    signal: AbortSignal.timeout(
      FETCH_TIMEOUT_MS,
    ),

    headers: {
      "user-agent": USER_AGENT,
      accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "accept-language": "en-US,en;q=0.9",
    },
  });

  if (!response.ok) {
    return emptyPreview(target);
  }

  const contentType =
    response.headers.get("content-type") ?? "";

  if (!contentType.includes("html")) {
    return emptyPreview(target);
  }

  // response.url reflects redirects, so relative paths resolve correctly.
  const base = response.url || target;

  const html = (await response.text()).slice(
    0,
    MAX_HTML_CHARS,
  );

  const declaredFavicon = absolute(
    readFavicon(html),
    base,
  );

  return {
    url: target,

    image: absolute(
      readMeta(html, "og:image:secure_url") ??
        readMeta(html, "og:image") ??
        readMeta(html, "twitter:image") ??
        readMeta(html, "twitter:image:src"),
      base,
    ),

    title:
      readMeta(html, "og:title") ??
      readMeta(html, "twitter:title"),

    siteName: readMeta(html, "og:site_name"),

    favicon:
      declaredFavicon ??
      (await probeRootFavicon(base)),
  };
};

export const linkPreviewPlugin = (): Plugin => ({
  name: "oi-link-preview",

  configureServer(server) {
    server.middlewares.use(
      ENDPOINT,
      async (req, res) => {
        const respond = (
          status: number,
          body: unknown,
        ) => {
          res.statusCode = status;

          res.setHeader(
            "content-type",
            "application/json",
          );

          // Re-reading a page on every card open is pointless; it rarely changes.
          res.setHeader(
            "cache-control",
            "public, max-age=3600",
          );

          res.end(JSON.stringify(body));
        };

        const target = new URL(
          req.url ?? "",
          "http://localhost",
        ).searchParams.get("url");

        if (!target || !isFetchable(target)) {
          respond(400, {
            error:
              "Provide a public http(s) url.",
          });

          return;
        }

        const cached = cache.get(target);

        if (cached) {
          respond(200, cached);

          return;
        }

        try {
          const preview =
            await loadPreview(target);

          cache.set(target, preview);

          respond(200, preview);
        } catch {
          // A dead or slow link must not break the card; it falls back.
          const preview =
            emptyPreview(target);

          cache.set(target, preview);

          respond(200, preview);
        }
      },
    );
  },
});
