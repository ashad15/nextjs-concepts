import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

import { linkPreviewPlugin } from "./vite-plugins/linkPreview.ts";

export default defineConfig({
  plugins: [react(), linkPreviewPlugin()],

  server: {
    allowedHosts: [".ngrok-free.dev"],

    proxy: {
      /* Order matters: these are matched by prefix in declaration order, so the
         CopilotKit runtime has to be listed before the catch-all "/api" or the
         peers API would swallow it and every chat request would 404. */
      "/api/copilotkit": {
        target: "http://127.0.0.1:4000",
        changeOrigin: true,
      },

      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
      },
    },
  },
});