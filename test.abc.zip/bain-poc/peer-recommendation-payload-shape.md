# Peer Recommendation API — Payload Structure

Structural pattern only. No business data, no company names, no figures. Extracted from one cached response (`app/data/cache/recommendations/<md5>.json`, 212 KB) plus the route that produces it.

## Where it comes from

`GET /peers/recommendation/{cap_id}` (also `GET /peers/recommendation?company_name=...`), defined in `oi3-backend/app/routers/peers.py`. The route is wrapped in a `@json_disk_cache` decorator that writes the returned dict verbatim to a JSON file named for the md5 of the five query params (`basic_metrics`, `max_peers`, `cap_id`, `company_name`, `use_agent`). So the cached file **is** the response body byte for byte: there is no serializer, no envelope, no `data`/`status` wrapper added on the way out.

The payload is assembled by an LLM pipeline (a LangGraph search agent or a single-prompt path) that researches peer companies on the web, then a rerank pass merges those with internally held peers. That origin explains the two dominant traits below: **every quantitative field carries its own provenance**, and **most fields are nullable because research can come back empty**.

## Top-level envelope

Exactly 6 keys, always present.

```
{
  target:       object   // the company being compared against
  best_peer:    object   // === ranked_peers[0], re-shaped (see below)
  ranked_peers: array    // ordered, length bounded by the max_peers param
  excluded:     array    // candidates considered and dropped, with a reason
  counts:       { vcc: int, model: int, ranked: int }
  sources:      array    // flat, deduped union of every page read in the run
}
```

`counts` is a provenance tally, not a length index: `vcc` is how many peers came from the internal list, `model` how many the LLM proposed, `ranked` the length of `ranked_peers`. The first two do not have to sum to the third.

## 1. `target` — polymorphic, two shapes

This is the one genuinely awkward part of the contract for a consumer.

- **Queried by `cap_id`:** a flat passthrough of an internal company row. 35 keys, no nesting, no provenance. 6 string keys (`cap_id`, `Ticker`, `Name`, `SECTOR`, `INDUSTRY_GROUP`, `INDUSTRY`) and 29 float keys in `SCREAMING_SNAKE_CASE` (`REVENUE`, `EBITDA_MARGIN`, `CAPEX`, `DSO`, `DPO`, `CCC`, `WACC`, and so on). Note the casing is mixed: `Ticker` and `Name` are TitleCase while the rest are upper snake.
- **Queried by `company_name`:** a single-key object, `{"Name": "<string>"}`, because there is no internal row to pass through.

So `target` is *not* the same type as a peer, and its own shape depends on which query param was used. Peers carry structured, provenanced metrics; the target carries bare floats.

## 2. `ranked_peers[]` — the primary entity, 17 keys

Every element had all 17 keys present in the sample. This is the richest object in the payload and the one a UI is built around.

```
{
  // identity
  rank:                int          // 1..N, dense, matches array order
  company_name:        string
  ticker:              string
  cap_id:              string|null  // null unless the peer is in the internal universe (4 of 7 null)

  // provenance of the recommendation itself
  source_list:         "A" | "B"    // which candidate list it came off
  in_both:             boolean      // appeared in both lists
  recommended_by:      "agent" | "vcc"
  final_score:         float        // 0..10, one decimal, monotonically decreasing with rank

  // narrative, LLM-authored, display-ready
  reasons:             string[]     // 3 in every peer, one sentence each
  concerns:            string[]     // 1..2, one sentence each

  // structured scoring, 0..100 ints, fixed key set
  selection_criteria: {
    business_model, revenue_scale, regional_exposure,
    end_market_customers, product_mix, growth_profile: int
  }

  confidence: {
    score:   int                    // 0..100
    summary: string                 // one sentence
    factors: [{ label: string, value: string }]   // always 4, fixed labels:
                                    // "Data completeness" | "Adjustments required"
                                    // | "Sources cross-checked" | "Comparable model"
                                    // values are display strings ("High", "Low", "Yes (10)")
  }

  // display-formatted highlights, PRE-RENDERED as strings
  key_metrics: [{ label: string, metric: string, value: string }]
                                    // always 4; `metric` is the machine key into `metrics`,
                                    // `label` the human one, `value` already formatted:
                                    // "$82.0M", "-76.0%"

  business_units: [{ segment: string, revenue_share: string,
                     comparable: "Yes"|"Partial", estimated: boolean }]
                                    // 0..3, EMPTY for most peers; revenue_share is
                                    // an approximate display string ("~60%")

  // provenance, three parallel layers (see section 4)
  metrics:   object                 // fixed 29-key map, see section 3
  sources:   array                  // 2..11 per peer, see section 4
  documents: array                  // 0..5 per peer, see section 4
}
```

**Two scoring scales coexist.** `final_score` is 0–10; `selection_criteria.*` and `confidence.score` are 0–100. Nothing in the payload flags the difference.

**`key_metrics` values are pre-formatted strings, not numbers.** The same underlying figure is available as a float under `metrics[<metric>].value`. A consumer that wants to re-format or chart must go through `metrics` and treat `key_metrics` as a display hint (which 4 to feature, in what order, under what label).

## 3. `metrics` — the notable pattern: a fixed map of discriminated, self-provenancing values

Present on every peer and on `best_peer`. Always the **same 29 keys in the same order**, mirroring the target's numeric columns:

```
REVENUE, TOTAL_REVENUE, COGS, CAPEX, ACCOUNTS_RECEIVABLE, ACCOUNTS_PAYABLE,
ADJUSTED_EBITDA, ADJUSTED_EBIT, LTM_EPS, MARKET_CAP, ADJUSTED_STOCK_PRICE,
CAPITAL_EMPLOYED, REVENUE_GROWTH_1YR, FCF_SALES_3YR, FCF_SALES_2YR,
EBITDA_MARGIN, EBIT_MARGIN, ADJUSTED_EBIT_MARGIN, GROSS_MARGIN, DSO, DPO,
CCC, CCC_ADJ, ADJUSTED_CCC, ACTUAL_EPS, REVENUE_CAGR_1YR,
NET_DEBT_EBITDA_1YR, COST_OF_EQUITY, WACC
```

The key is **always present**; the value is **either `null` or one of three object shapes discriminated by an `origin` field**. Sparsity is high and uneven: in the sample, `REVENUE`, `MARKET_CAP`, `LTM_EPS` and `ACTUAL_EPS` resolved for all 8 entities, while `WACC`, `DPO`, `ADJUSTED_EBITDA` and `NET_DEBT_EBITDA_1YR` were null for 5 of 8. A grid built off this must render "not found" as a first-class state, not as zero.

```
// origin: "web"  — scraped from a page. 48 of 89 in the sample.
{ value: float, unit: string, period: string, origin: "web",
  source_url: string, source_name: string }

// origin: "computed"  — derived from other metrics in this same map. 36 of 89.
{ value: float, unit: string, origin: "computed",
  formula: string,         // human readable, e.g. "DSO + Days inventory - DPO"
  formula_latex: string,   // LaTeX, ready for MathJax/KaTeX rendering
  inputs: string[] }       // 1..2 metric KEYS from this same 29-key map

// origin: "modelled"  — an assumption, not an observation. 5 of 89.
{ value: float, unit: string, origin: "modelled",
  method: string }         // prose describing the model and its assumptions,
                           // e.g. "CAPM: 4.20% risk free + 2.270 x 5.50% ERP (beta 2.27)"
```

Three consequences worth calling out to whoever consumes this:

- **`value` is always a float**, never a formatted string, and always in the units named by `unit`. `unit` is a small vocabulary: `"USD millions"`, `"EUR millions"`, `"USD per share"`, `"ratio"`, `"days"`. **Currency is not normalized** — some peers report EUR, some USD, in the same response, and nothing converts them. Any cross-peer comparison has to handle that.
- **`period` is free text, not a date.** Observed values include `"TTM"`, `"FY2025"`, `"TTM (ended Jun 30, 2026)"`, `"Q1 2026 (Three Months Ended March 31, 2026)"`, `"03-2026"`, `"intraday"`, `"Previous Close"`, `"At close Aug 17, 2026"`. It is a label to display beside the number, not something to parse or sort on. It exists only on the `web` shape.
- **`inputs` makes the map self-referentially traversable.** A computed metric names the keys it was derived from, so a UI can expand a derived value into its own operands and their provenance, recursively, without any lookup table. That is the interesting bit of this design: the derivation graph travels inside the payload.

## 4. Provenance layers — three of them, at two levels

The payload attaches evidence three different ways, and they do not overlap in role.

**(a) Per-peer `sources[]`** — pages actually used for that peer, 2 to 11 each. Six keys, but the array is a **partition into two variants** by which of two mutually exclusive keys is present (no element had both or neither):

```
// figures variant — the page supplied numbers
{ url, name, title, summary,
  used_for: string[],        // metric KEYS, e.g. ["REVENUE", "REVENUE_GROWTH_1YR"]
  figures: [{ metric: string, value: float, unit: string,
              period: string, origin: "web" }] }

// evidence variant — the page supported a qualitative judgment
{ url, name, title, summary,
  used_for: string[],        // selection_criteria KEYS, e.g. ["business_model", "product_mix"]
  evidence: [{ criterion: string,   // a selection_criteria key
               score: int,          // 0..100, the contribution to that criterion
               evidence: string }] } // verbatim supporting quote, ~150-250 chars
```

Note `used_for` is polymorphic across the two variants: metric keys in one, `selection_criteria` keys in the other. And `evidence[].evidence` shadows its parent key name.

`summary` is a long LLM-written page summary, 615 to 1002 chars in the sample, and there is one per source. Across 66 top-level sources that alone is a large share of the 212 KB.

**(b) Per-peer `documents[]`** — 0 to 5 per peer, uniform 5 keys. These are documents *found* during research, distinct from sources *used*:

```
{ url, title, publisher, used_for_metrics: boolean, note: string }
```

In the sample `used_for_metrics` was `false` for all 19 and `note` read as a stock string about the document not being used for any figure. So this is a discovery trail, currently near-inert but shaped to carry a used/unused distinction.

**(c) Top-level `sources[]`** — 66 in the sample, the flat deduped union of every page read across all peers, merged on URL by the route. Five keys, always the same shape, and **narrower than the per-peer variant**: it keeps `url`, `name`, `title`, `summary`, `used_for` but drops both `figures` and `evidence`. Its `used_for` is namespaced by ticker instead of bare: `"ARCT: business_model"`, `"ARCT: REVENUE"` — a string join, not a structured pair, so a consumer wanting per-ticker grouping has to split on `": "`.

The same page therefore appears twice in one response with different shapes and different `used_for` conventions: once inside the peer that used it, once in the global list. That is the main redundancy driving payload size.

## 5. `best_peer` — a re-shaped duplicate, not a reference

Identically the same company as `ranked_peers[0]` (verified: same ticker), but **carrying a different key set**. 9 keys:

```
{ company_name, ticker, cap_id, final_score, recommended_by,
  why_best,              // string, ~400 chars, LLM prose. UNIQUE to best_peer.
  metrics, sources, documents }   // identical in shape to the peer versions
```

It **drops** the 9 ranking-specific keys (`rank`, `source_list`, `in_both`, `reasons`, `concerns`, `selection_criteria`, `key_metrics`, `business_units`, `confidence`) and **adds** `why_best`. Because it duplicates the heavy `metrics` + `sources` + `documents` blocks rather than pointing at index 0, the top peer's payload is transmitted twice.

## 6. `excluded[]` — flat, 5 keys, no provenance

Candidates considered and rejected. Nothing structured, just the identity and a prose justification.

```
{ company_name: string, ticker: string, source_list: "A"|"B",
  final_score: float,      // 0..10, and can be far below the ranked floor
  why_excluded: string }   // ~200-250 chars of LLM prose
```

## Cardinalities observed in this one response

| Path | Count |
| --- | --- |
| `ranked_peers` | 7 (bounded by the `max_peers` param) |
| `excluded` | 4 |
| `sources` (top level) | 66 |
| `sources` per peer | 2, 3, 4, 8, 9, 10, 11 (+11 on `best_peer`) |
| `documents` per peer | 0, 0, 0, 3, 4, 4, 5 (+3 on `best_peer`) |
| `key_metrics` per peer | 4, always |
| `reasons` / `concerns` per peer | 3 / 1..2 |
| `business_units` per peer | 0 for 4 of 7; else 2..3 |
| `metrics` keys per entity | 29, always, ~11 of them null |
| non-null metric objects, all entities | 89 (48 web, 36 computed, 5 modelled) |

## Summary of the pattern, in one paragraph

This is a **research-result payload, not a database projection**. The organising idea is that no number travels without its origin: every metric is a tagged union discriminated on `origin` that carries either the URL it was scraped from, the formula and operand keys it was derived from, or the modelling assumption behind it, and every qualitative score carries the quoted page text that supports it. Around that core sit three conventions a consumer has to know about: fixed-key maps with nullable values rather than sparse maps (so "we looked and found nothing" is representable), pre-formatted display strings sitting beside the machine-readable floats they were rendered from (`key_metrics` beside `metrics`), and deliberate duplication for read convenience (`best_peer` copying `ranked_peers[0]`, per-peer sources copied into a global list). Volatility is confined to what research produced: which metrics resolved, how many sources each peer got, whether business units were found. The key sets themselves are stable.
