#!/usr/bin/env bash
#
# Start everything the assistant needs, in one command.
#
# Four processes, because the chat path adds two to the two that already
# existed:
#
#   :8000  peers API          existing FastAPI app (peer recommendations)
#   :8123  chat agent         LangGraph agent, speaks AG-UI over SSE
#   :4000  CopilotKit runtime Node, holds thread state, fans tools out
#   :5173  Vite               the SPA, proxies /api/copilotkit to :4000
#
# The chat agent has its own venv on purpose. It needs langgraph 1.x and
# pydantic 2.13, the peers API is pinned to langgraph 0.6 and pydantic 2.10, and
# upgrading the second to suit the first would land on the peer pipeline. See
# oi3-backend/chat_agent/requirements.txt.
#
# Ctrl-C stops all four.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

BACKEND="$ROOT/oi3-backend"
AGENT="$BACKEND/chat_agent"
FRONTEND="$ROOT/opportunity-indicator-frontend"

fail() { printf '\n[oi3] %s\n' "$1" >&2; exit 1; }

[ -x "$BACKEND/.venv/bin/python" ] ||
  fail "No backend venv. Run: cd oi3-backend && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"

[ -x "$AGENT/.venv/bin/python" ] ||
  fail "No chat-agent venv. Run: cd oi3-backend/chat_agent && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"

[ -d "$FRONTEND/node_modules" ] ||
  fail "No node_modules. Run: cd opportunity-indicator-frontend && npm install"

grep -q '^OPENAI_API_KEY=.\+' "$BACKEND/.env" 2>/dev/null ||
  fail "OPENAI_API_KEY is not set in oi3-backend/.env. The chat agent cannot start without it."

pids=()

# Kill the whole process group on the way out. Vite and tsx both spawn children,
# and killing only the parent leaves the ports held.
cleanup() {
  trap - INT TERM EXIT
  printf '\n[oi3] stopping\n'
  for pid in "${pids[@]:-}"; do
    kill -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}
trap cleanup INT TERM EXIT

start() {
  local label="$1"; shift
  local dir="$1"; shift

  printf '[oi3] %s\n' "$label"

  # Own process group per service, so cleanup can take its children with it.
  ( cd "$dir" && set -m && exec "$@" ) &
  pids+=("$!")
}

# The peers API is often already running in another terminal. Starting a second
# one would only fail to bind, so skip it rather than adding noise.
if lsof -nP -iTCP:8000 -sTCP:LISTEN >/dev/null 2>&1; then
  printf '[oi3] peers API already on :8000, leaving it alone\n'
else
  start "peers API        :8000" "$BACKEND" \
    .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
fi

start "chat agent       :8123" "$AGENT"    .venv/bin/python main.py
start "copilot runtime  :4000" "$FRONTEND" npm run --silent runtime
start "vite             :5173" "$FRONTEND" npm run --silent dev

printf '\n[oi3] all up. open http://localhost:5173/oi/setup\n\n'

wait
